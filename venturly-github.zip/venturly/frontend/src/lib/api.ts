import axios from 'axios';

// Uses public tunnel URL when set, falls back to localhost for local dev
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001',
});

api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  // Required by localtunnel to bypass the browser warning page
  config.headers['bypass-tunnel-reminder'] = 'true';
  return config;
});

export default api;
