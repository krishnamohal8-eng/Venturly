'use client';
import { useEffect, useState, useMemo } from 'react';
import Navbar from '@/components/Navbar';
import LoanCard from '@/components/LoanCard';
import api from '@/lib/api';

type SortKey = 'newest' | 'amount_asc' | 'amount_desc' | 'rate_desc' | 'score_desc' | 'funded_desc';

export default function MarketplacePage() {
  const [loans, setLoans] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [grade, setGrade] = useState('all');
  const [esg, setEsg] = useState(false);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<SortKey>('newest');

  const load = async () => {
    try {
      const { data } = await api.get('/loans');
      // API now returns { data: [...], meta: {...} }
      setLoans(Array.isArray(data) ? data : (data.data ?? []));
    } catch { /* ignore */ }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    let list = [...loans];

    if (grade !== 'all') list = list.filter(l => l.riskGrade === grade);
    if (esg) list = list.filter(l => !!l.esgCategory);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(l =>
        l.businessDescription?.toLowerCase().includes(q) ||
        l.borrower?.name?.toLowerCase().includes(q) ||
        l.esgCategory?.toLowerCase().includes(q)
      );
    }

    switch (sort) {
      case 'amount_asc':   list.sort((a, b) => a.amount - b.amount); break;
      case 'amount_desc':  list.sort((a, b) => b.amount - a.amount); break;
      case 'rate_desc':    list.sort((a, b) => b.interestRatePercent - a.interestRatePercent); break;
      case 'score_desc':   list.sort((a, b) => b.quantumScore - a.quantumScore); break;
      case 'funded_desc':  list.sort((a, b) => (b.fundedTokens / b.totalTokens) - (a.fundedTokens / a.totalTokens)); break;
      default:             list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return list;
  }, [loans, grade, esg, search, sort]);

  return (
    <>
      <Navbar />
      <div className="page container">
        <h1 className="page-title">Loan Marketplace</h1>
        <p className="page-sub">Browse AI-scored loan opportunities. Each loan is tokenized into $25 micro-notes.</p>

        {/* Filters bar */}
        <div style={{ display: 'flex', gap: '0.8rem', marginBottom: '1.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
          {/* Search */}
          <input
            type="text"
            placeholder="Search by business, borrower, ESG..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{
              padding: '0.5rem 0.9rem', border: '1px solid var(--border)', borderRadius: '8px',
              fontSize: '0.9rem', outline: 'none', minWidth: '220px', flex: 1,
            }}
          />

          {/* Grade filter */}
          <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
            {['all', 'A', 'B', 'C', 'D', 'E'].map(g => (
              <button
                key={g}
                className={`btn btn-sm ${grade === g ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => setGrade(g)}
              >
                {g === 'all' ? 'All' : `Grade ${g}`}
              </button>
            ))}
          </div>

          {/* ESG toggle */}
          <button
            className={`btn btn-sm ${esg ? 'btn-primary' : 'btn-outline'}`}
            onClick={() => setEsg(!esg)}
            style={{ whiteSpace: 'nowrap' }}
          >
            🌱 ESG Only
          </button>

          {/* Sort */}
          <select
            value={sort}
            onChange={e => setSort(e.target.value as SortKey)}
            style={{
              padding: '0.5rem 0.8rem', border: '1px solid var(--border)',
              borderRadius: '8px', fontSize: '0.85rem', outline: 'none',
            }}
          >
            <option value="newest">Newest First</option>
            <option value="score_desc">Highest Score</option>
            <option value="rate_desc">Highest Rate</option>
            <option value="amount_desc">Largest Loan</option>
            <option value="amount_asc">Smallest Loan</option>
            <option value="funded_desc">Most Funded</option>
          </select>
        </div>

        {/* Results count */}
        {!loading && (
          <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginBottom: '1rem' }}>
            {filtered.length} loan{filtered.length !== 1 ? 's' : ''} found
          </p>
        )}

        {loading ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem' }}>
            {[1, 2, 3].map(i => (
              <div key={i} className="card" style={{ height: '220px', background: '#f3f4f6', border: 'none' }} />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
            <div style={{ fontSize: '2.5rem', marginBottom: '0.8rem' }}>🔍</div>
            <p style={{ color: 'var(--muted)', marginBottom: '0.5rem' }}>No loans match your filters.</p>
            <button className="btn btn-outline btn-sm" onClick={() => { setGrade('all'); setEsg(false); setSearch(''); }}>
              Clear filters
            </button>
          </div>
        ) : (
          <div className="card-grid">
            {filtered.map(loan => (
              <LoanCard key={loan.id} loan={loan} onFunded={load} />
            ))}
          </div>
        )}
      </div>
    </>
  );
}
