'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import api from '@/lib/api';
import { setAuth } from '@/lib/auth';
import { PasskeyLoginButton } from '@/components/PasskeyButton';
import { Toast } from '@/components/Toast';

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [tab, setTab] = useState<'password' | 'passkey'>('passkey');

  const redirect = (user: any) => {
    router.push(user.role === 'borrower' ? '/dashboard/borrower' : '/dashboard/investor');
  };

  const submitPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const { data } = await api.post('/auth/login', form);
      setAuth(data.token, data.user);
      redirect(data.user);
    } catch (e: any) {
      setError(e.response?.data?.message || 'Login failed.');
    } finally { setLoading(false); }
  };

  return (
    <>
      <Navbar />
      <div className="page container" style={{ maxWidth: 420 }}>
        <h1 className="page-title">Welcome back</h1>
        <p className="page-sub">Sign in to your Venturly account</p>

        {/* Tab switcher */}
        <div className="tabs" style={{ marginBottom: '1.5rem' }}>
          <div className={`tab ${tab === 'passkey' ? 'active' : ''}`} onClick={() => setTab('passkey')}>
            🔑 Passkey
          </div>
          <div className={`tab ${tab === 'password' ? 'active' : ''}`} onClick={() => setTab('password')}>
            🔒 Password
          </div>
        </div>

        {tab === 'passkey' && (
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ textAlign: 'center', padding: '0.5rem 0' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>🔑</div>
              <div style={{ fontWeight: 700, marginBottom: '0.3rem' }}>Sign in with your passkey</div>
              <div style={{ fontSize: '0.85rem', color: 'var(--muted)' }}>
                Use your fingerprint, face, or device PIN — no password needed
              </div>
            </div>

            <div className="form-group" style={{ marginBottom: 0 }}>
              <label>Email</label>
              <input
                type="email" required
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                placeholder="your@email.com"
              />
            </div>

            <PasskeyLoginButton
              email={form.email}
              onSuccess={(user) => {
                setToast({ msg: `Welcome back, ${user.name}!`, type: 'success' });
                setTimeout(() => redirect(user), 800);
              }}
              onError={(msg) => setError(msg)}
            />

            {error && <div className="alert alert-error">{error}</div>}

            <div style={{ textAlign: 'center', fontSize: '0.82rem', color: 'var(--muted)' }}>
              Don't have a passkey yet?{' '}
              <button onClick={() => setTab('password')} style={{ background: 'none', border: 'none', color: 'var(--teal)', cursor: 'pointer', fontWeight: 600 }}>
                Sign in with password
              </button>
              {' '}and add one in your profile.
            </div>
          </div>
        )}

        {tab === 'password' && (
          <form onSubmit={submitPassword} className="card">
            {error && <div className="alert alert-error" style={{ marginBottom: '1rem' }}>{error}</div>}
            <div className="form-group">
              <label>Email</label>
              <input type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input type="password" required value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
            </div>
            <button className="btn btn-primary" style={{ width: '100%' }} disabled={loading}>
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
            <p style={{ textAlign: 'center', marginTop: '1rem', fontSize: '0.9rem', color: 'var(--muted)' }}>
              No account? <Link href="/register" style={{ color: 'var(--teal)' }}>Register</Link>
            </p>
          </form>
        )}
      </div>

      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </>
  );
}
