'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Navbar from '@/components/Navbar';
import api from '@/lib/api';
import { getUser, setAuth, AuthUser } from '@/lib/auth';
import { Toast } from '@/components/Toast';
import { PasskeyRegisterButton } from '@/components/PasskeyButton';

export default function ProfilePage() {
  const router = useRouter();
  const [user, setUser] = useState<AuthUser | null>(null);
  const [name, setName] = useState('');
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [passkeys, setPasskeys] = useState<any[]>([]);

  const loadPasskeys = async () => {
    try {
      const { data } = await api.get('/passkeys');
      setPasskeys(data);
    } catch { /* ignore */ }
  };

  useEffect(() => {
    const u = getUser();
    if (!u) { router.push('/login'); return; }
    setUser(u);
    setName(u.name);

    // Load role-specific stats
    if (u.role === 'investor') {
      api.get('/investments/my/stats').then(r => setStats(r.data)).catch(() => {});
    } else {
      api.get('/loans/my/loans').then(r => setStats({ loanCount: r.data.length })).catch(() => {});
    }
    loadPasskeys();
  }, []);

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload: any = {};
      if (name !== user!.name) payload.name = name;
      if (newPw) payload.newPassword = newPw;

      if (Object.keys(payload).length === 0) {
        setToast({ msg: 'Nothing to update.', type: 'info' });
        setSaving(false);
        return;
      }

      // Verify current password first
      await api.post('/auth/login', { email: user!.email, password: currentPw });

      const { data } = await api.patch('/users/me', payload);
      const updated = { ...user!, name: data.name };
      setAuth(localStorage.getItem('token')!, updated);
      setUser(updated);
      setCurrentPw(''); setNewPw('');
      setToast({ msg: 'Profile updated successfully.', type: 'success' });
    } catch {
      setToast({ msg: 'Current password is incorrect.', type: 'error' });
    } finally { setSaving(false); }
  };

  if (!user) return null;

  const roleColor = user.role === 'investor' ? '#1d4ed8' : 'var(--teal)';

  return (
    <>
      <Navbar />
      <div className="page container" style={{ maxWidth: 600 }}>
        <h1 className="page-title">My Profile</h1>

        {/* Avatar + role card */}
        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', marginBottom: '1.5rem', padding: '1.5rem' }}>
          <div style={{
            width: 64, height: 64, borderRadius: '50%', background: roleColor,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1.6rem', fontWeight: 800, color: '#fff', flexShrink: 0,
          }}>
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: '1.1rem' }}>{user.name}</div>
            <div style={{ color: 'var(--muted)', fontSize: '0.9rem' }}>{user.email}</div>
            <span style={{
              display: 'inline-block', marginTop: '0.4rem', fontSize: '0.78rem',
              background: user.role === 'investor' ? '#dbeafe' : 'var(--teal-light)',
              color: roleColor, padding: '0.15rem 0.6rem', borderRadius: '999px', fontWeight: 700,
              textTransform: 'capitalize',
            }}>
              {user.role}
            </span>
          </div>

          {/* Quick stats */}
          {stats && (
            <div style={{ textAlign: 'right', fontSize: '0.85rem' }}>
              {user.role === 'investor' ? (
                <>
                  <div style={{ fontWeight: 700, color: 'var(--teal)', fontSize: '1.2rem' }}>
                    ${Number(stats.totalInvested || 0).toLocaleString()}
                  </div>
                  <div style={{ color: 'var(--muted)' }}>Total Invested</div>
                  <div style={{ marginTop: '0.3rem', color: 'var(--success)', fontWeight: 600 }}>
                    +${Number(stats.expectedReturn || 0).toFixed(0)} expected
                  </div>
                </>
              ) : (
                <>
                  <div style={{ fontWeight: 700, color: 'var(--teal)', fontSize: '1.2rem' }}>
                    {stats.loanCount}
                  </div>
                  <div style={{ color: 'var(--muted)' }}>Loan{stats.loanCount !== 1 ? 's' : ''} applied</div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Verify password to confirm identity */}
        <form onSubmit={saveProfile} className="card">
          <h3 style={{ fontWeight: 700, marginBottom: '1.2rem' }}>Account Settings</h3>

          <div className="form-group">
            <label>Display Name</label>
            <input value={name} onChange={e => setName(e.target.value)} required />
          </div>

          <div className="form-group">
            <label>Current Password (required to save changes)</label>
            <input type="password" value={currentPw} onChange={e => setCurrentPw(e.target.value)} required />
          </div>

          <div style={{ padding: '0.8rem', background: '#f9fafb', borderRadius: '8px', marginBottom: '1rem', fontSize: '0.85rem', color: 'var(--muted)' }}>
            <strong>Email:</strong> {user.email} &nbsp;·&nbsp;
            <strong>Role:</strong> {user.role} &nbsp;·&nbsp;
            <strong>KYC:</strong> Verified ✓
          </div>

          <button className="btn btn-primary" disabled={saving} style={{ width: '100%' }}>
            {saving ? 'Saving…' : 'Save Changes'}
          </button>
        </form>

        {/* Quick links */}
        <div className="card" style={{ marginTop: '1rem', padding: '1rem' }}>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
            {user.role === 'borrower' && (
              <a href="/dashboard/borrower" style={{ color: 'var(--teal)', fontSize: '0.9rem' }}>→ My Loans</a>
            )}
            {user.role === 'investor' && (
              <a href="/dashboard/investor" style={{ color: 'var(--teal)', fontSize: '0.9rem' }}>→ My Portfolio</a>
            )}
            <a href="/marketplace" style={{ color: 'var(--teal)', fontSize: '0.9rem' }}>→ Marketplace</a>
            <a href="/stats" style={{ color: 'var(--teal)', fontSize: '0.9rem' }}>→ Platform Impact</a>
          </div>
        </div>

        {/* Passkey management */}
        <div className="card" style={{ marginTop: '1rem' }}>
          <h3 style={{ fontWeight: 700, marginBottom: '0.4rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            🔑 Passkeys
            <span style={{ fontSize: '0.75rem', background: 'var(--teal-light)', color: 'var(--teal)', padding: '0.15rem 0.5rem', borderRadius: '999px', fontWeight: 600 }}>
              {passkeys.length} registered
            </span>
          </h3>
          <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginBottom: '1rem' }}>
            Sign in with your fingerprint, face, or device PIN — no password needed.
          </p>

          {passkeys.length > 0 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1rem' }}>
              {passkeys.map((pk: any) => (
                <div key={pk.id} style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '0.7rem 0.9rem', background: '#f9fafb', borderRadius: '8px',
                  border: '1px solid var(--border)',
                }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>
                      🔑 {pk.deviceName || 'Device'}
                    </div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>
                      Added {new Date(pk.createdAt).toLocaleDateString()} · Used {pk.counter} time{pk.counter !== 1 ? 's' : ''}
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        await api.delete(`/passkeys/${pk.id}`);
                        setToast({ msg: 'Passkey removed.', type: 'success' });
                        loadPasskeys();
                      } catch { setToast({ msg: 'Failed to remove passkey.', type: 'error' }); }
                    }}
                    style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '0.85rem', fontWeight: 600 }}
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}

          <PasskeyRegisterButton
            onSuccess={(name) => {
              setToast({ msg: `Passkey "${name}" added! You can now sign in without a password.`, type: 'success' });
              loadPasskeys();
            }}
            onError={(msg) => setToast({ msg, type: 'error' })}
          />
        </div>
      </div>

      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </>
  );
}
