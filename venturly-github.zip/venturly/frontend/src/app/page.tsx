import Link from 'next/link';
import Navbar from '@/components/Navbar';
import LiveStats from '@/components/LiveStats';

export default function Home() {
  return (
    <>
      <Navbar />
      <section className="hero">
        <div className="container">
          <h1>Capital in 48 Hours,<br />Not 48 Days.</h1>
          <p>Venturly is the AI-powered bridge connecting creditworthy small businesses directly with investors — bypassing traditional banking bureaucracy.</p>
          <div className="hero-btns">
            <Link href="/register?role=borrower" className="btn btn-outline" style={{ color: '#fff', borderColor: '#fff' }}>
              Apply for a Loan
            </Link>
            <Link href="/register?role=investor" className="btn" style={{ background: '#fff', color: 'var(--teal)' }}>
              Start Investing
            </Link>
          </div>
        </div>
      </section>

      <div className="container">
        <LiveStats />

        <div className="card-grid" style={{ margin: '3rem 0' }}>
          {[
            { icon: '🤖', title: 'AI Quantum Score', desc: 'Our engine analyzes 500+ real-time data points — cash flow, sales, sentiment — to assign a risk grade in minutes, not weeks.' },
            { icon: '🪙', title: 'Fractional Micro-Notes', desc: 'Every loan is tokenized into $25 units. Invest as little as $25 and diversify across dozens of businesses.' },
            { icon: '⚡', title: '48-Hour Capital', desc: 'Once fully funded, capital is released instantly via automated rails. No paperwork, no waiting rooms.' },
            { icon: '📊', title: 'Transparent Marketplace', desc: 'Browse loans with full AI risk scores, ESG alignment, and business stories before you commit a single dollar.' },
            { icon: '🔒', title: 'Zero-Trust Security', desc: 'Multi-sig escrow, biometric verification, and an immutable Hyperledger audit trail on every transaction.' },
            { icon: '🌍', title: 'Built to Scale', desc: 'Modular architecture supports global expansion — SEPA for Europe, UPI for India — without rebuilding from scratch.' },
          ].map(f => (
            <div className="card" key={f.title}>
              <div style={{ fontSize: '2rem', marginBottom: '0.8rem' }}>{f.icon}</div>
              <div style={{ fontWeight: 700, marginBottom: '0.4rem' }}>{f.title}</div>
              <div style={{ color: 'var(--muted)', fontSize: '0.9rem' }}>{f.desc}</div>
            </div>
          ))}
        </div>

        <div className="card" style={{ textAlign: 'center', padding: '3rem', marginBottom: '3rem', background: 'var(--teal-light)' }}>
          <h2 style={{ fontSize: '1.6rem', marginBottom: '0.8rem' }}>Ready to close the credit gap?</h2>
          <p style={{ color: 'var(--muted)', marginBottom: '1.5rem' }}>Join thousands of businesses and investors already on the platform.</p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/marketplace" className="btn btn-primary">Browse Marketplace</Link>
            <Link href="/stats" className="btn btn-outline">View Platform Impact</Link>
          </div>
        </div>
      </div>
    </>
  );
}
