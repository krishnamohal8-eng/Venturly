'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Navbar from '@/components/Navbar';
import api from '@/lib/api';
import { getUser } from '@/lib/auth';

export default function LoanDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [loan, setLoan] = useState<any>(null);
  const [schedule, setSchedule] = useState<any[]>([]);
  const [audit, setAudit] = useState<any[]>([]);
  const [tab, setTab] = useState<'schedule' | 'audit'>('schedule');
  const [paying, setPaying] = useState<number | null>(null);
  const [msg, setMsg] = useState('');
  const user = getUser();

  useEffect(() => {
    api.get(`/loans/${id}`).then(r => setLoan(r.data));
    api.get(`/repayments/${id}/schedule`).then(r => setSchedule(r.data)).catch(() => {});
    api.get(`/audit?loanId=${id}`).then(r => setAudit(r.data)).catch(() => {});
  }, [id]);

  const generateSchedule = async () => {
    try {
      const { data } = await api.post(`/repayments/${id}/generate`);
      setSchedule(data);
      setMsg('Repayment schedule generated.');
    } catch (e: any) { setMsg(e.response?.data?.message || 'Error'); }
  };

  const payInstallment = async (num: number) => {
    setPaying(num);
    try {
      await api.post(`/repayments/${id}/pay/${num}`);
      const { data } = await api.get(`/repayments/${id}/schedule`);
      setSchedule(data);
      setMsg(`Installment #${num} paid successfully.`);
    } catch (e: any) { setMsg(e.response?.data?.message || 'Error'); }
    finally { setPaying(null); }
  };

  const statusColor: Record<string, string> = {
    scheduled: 'var(--muted)', paid: 'var(--success)', late: 'var(--warn)', defaulted: 'var(--danger)',
  };

  if (!loan) return <><Navbar /><div className="page container"><p style={{ color: 'var(--muted)' }}>Loading...</p></div></>;

  return (
    <>
      <Navbar />
      <div className="page container">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
          <div>
            <h1 className="page-title">{loan.businessDescription?.slice(0, 60)}</h1>
            <p className="page-sub">by {loan.borrower?.name} · Grade <strong>{loan.riskGrade}</strong> · {loan.interestRatePercent}% APR · {loan.termMonths} months</p>
          </div>
          <span className={`badge badge-${loan.status}`} style={{ fontSize: '0.9rem', padding: '0.4rem 1rem' }}>{loan.status}</span>
        </div>

        <div className="stats-row" style={{ marginBottom: '2rem' }}>
          <div className="stat-card"><div className="stat-value">${Number(loan.amount).toLocaleString()}</div><div className="stat-label">Loan Amount</div></div>
          <div className="stat-card"><div className="stat-value">{loan.quantumScore}/100</div><div className="stat-label">Quantum Score</div></div>
          <div className="stat-card"><div className="stat-value">{Math.round((loan.fundedTokens / loan.totalTokens) * 100)}%</div><div className="stat-label">Funded</div></div>
          <div className="stat-card"><div className="stat-value">{loan.totalTokens - loan.fundedTokens}</div><div className="stat-label">Tokens Remaining</div></div>
        </div>

        {msg && <div className={`alert ${msg.includes('success') || msg.includes('generated') || msg.includes('paid') ? 'alert-success' : 'alert-error'}`}>{msg}</div>}

        {loan.status === 'funded' && schedule.length === 0 && user?.role === 'borrower' && (
          <button className="btn btn-primary" style={{ marginBottom: '1.5rem' }} onClick={generateSchedule}>
            Generate Repayment Schedule
          </button>
        )}

        <div className="tabs">
          <div className={`tab ${tab === 'schedule' ? 'active' : ''}`} onClick={() => setTab('schedule')}>Repayment Schedule</div>
          <div className={`tab ${tab === 'audit' ? 'active' : ''}`} onClick={() => setTab('audit')}>Audit Trail</div>
        </div>

        {tab === 'schedule' && (
          schedule.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: '2rem', color: 'var(--muted)' }}>
              No repayment schedule yet. Schedule is generated once the loan is fully funded.
            </div>
          ) : (
            <div className="card" style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
                <thead>
                  <tr style={{ borderBottom: '2px solid var(--border)', textAlign: 'left' }}>
                    {['#', 'Due Date', 'Principal', 'Interest', 'Total', 'Status', ''].map(h => (
                      <th key={h} style={{ padding: '0.6rem 0.8rem', color: 'var(--muted)', fontWeight: 600 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {schedule.map(r => (
                    <tr key={r.id} style={{ borderBottom: '1px solid var(--border)' }}>
                      <td style={{ padding: '0.6rem 0.8rem' }}>{r.installmentNumber}</td>
                      <td style={{ padding: '0.6rem 0.8rem' }}>{r.dueDate}</td>
                      <td style={{ padding: '0.6rem 0.8rem' }}>${Number(r.principalDue).toFixed(2)}</td>
                      <td style={{ padding: '0.6rem 0.8rem' }}>${Number(r.interestDue).toFixed(2)}</td>
                      <td style={{ padding: '0.6rem 0.8rem', fontWeight: 700 }}>${Number(r.totalDue).toFixed(2)}</td>
                      <td style={{ padding: '0.6rem 0.8rem', color: statusColor[r.status], fontWeight: 600, textTransform: 'capitalize' }}>{r.status}</td>
                      <td style={{ padding: '0.6rem 0.8rem' }}>
                        {r.status === 'scheduled' && user?.role === 'borrower' && (
                          <button
                            className="btn btn-primary btn-sm"
                            disabled={paying === r.installmentNumber}
                            onClick={() => payInstallment(r.installmentNumber)}
                          >
                            {paying === r.installmentNumber ? 'Paying...' : 'Pay'}
                          </button>
                        )}
                        {r.status === 'paid' && <span style={{ color: 'var(--success)' }}>✓ {r.paidDate}</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        )}

        {tab === 'audit' && (
          audit.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: '2rem', color: 'var(--muted)' }}>No audit entries yet.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              {audit.map(entry => (
                <div key={entry.id} className="card" style={{ padding: '1rem', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <div style={{ background: 'var(--teal-light)', color: 'var(--teal)', padding: '0.3rem 0.7rem', borderRadius: '6px', fontSize: '0.78rem', fontWeight: 700, whiteSpace: 'nowrap' }}>
                    {entry.action}
                  </div>
                  <div style={{ flex: 1 }}>
                    {entry.amount && <span style={{ fontWeight: 700 }}>${Number(entry.amount).toFixed(2)} · </span>}
                    <span style={{ fontSize: '0.85rem', color: 'var(--muted)' }}>{new Date(entry.createdAt).toLocaleString()}</span>
                    <div style={{ fontSize: '0.78rem', color: 'var(--muted)', marginTop: '0.2rem', fontFamily: 'monospace' }}>
                      hash: {entry.hash} · prev: {entry.previousHash?.slice(0, 8)}...
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
      </div>
    </>
  );
}
