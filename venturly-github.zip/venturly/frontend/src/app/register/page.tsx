'use client';
import { useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import api from '@/lib/api';
import { setAuth } from '@/lib/auth';

function RegisterForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [form, setForm] = useState({
    name: '', email: '', password: '',
    role: (params.get('role') as 'borrower' | 'investor') || 'borrower',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const { data } = await api.post('/auth/register', form);
      setAuth(data.token, data.user);
      router.push(data.user.role === 'borrower' ? '/dashboard/borrower' : '/dashboard/investor');
    } catch (e: any) {
      setError(e.response?.data?.message || 'Registration failed.');
    } finally { setLoading(false); }
  };

  return (
    <>
      <Navbar />
      <div className="page container" style={{ maxWidth: 440 }}>
        <h1 className="page-title">Create your account</h1>
        <p className="page-sub">Join Venturly as a borrower or investor</p>
        {error && <div className="alert alert-error">{error}</div>}
        <form onSubmit={submit} className="card">
          <div className="form-group">
            <label>I want to</label>
            <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value as any })}>
              <option value="borrower">Borrow capital for my business</option>
              <option value="investor">Invest and earn returns</option>
            </select>
          </div>
          <div className="form-group">
            <label>Full Name</label>
            <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="form-group">
            <label>Email</label>
            <input type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input type="password" required minLength={6} value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
          </div>
          <button className="btn btn-primary" style={{ width: '100%' }} disabled={loading}>
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
          <p style={{ textAlign: 'center', marginTop: '1rem', fontSize: '0.9rem', color: 'var(--muted)' }}>
            Already have an account? <Link href="/login" style={{ color: 'var(--teal)' }}>Sign in</Link>
          </p>
        </form>
      </div>
    </>
  );
}

export default function RegisterPage() {
  return <Suspense><RegisterForm /></Suspense>;
}
