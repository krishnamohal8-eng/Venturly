'use client';
import { useEffect, useState } from 'react';
import Navbar from '@/components/Navbar';
import api from '@/lib/api';

const GRADE_COLORS: Record<string, string> = {
  A: '#15803d', B: '#1d4ed8', C: '#a16207', D: '#c2410c', E: '#b91c1c',
};

export default function StatsPage() {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    api.get('/stats').then(r => setStats(r.data)).catch(() => {});
  }, []);

  if (!stats) return (
    <>
      <Navbar />
      <div className="page container"><p style={{ color: 'var(--muted)' }}>Loading platform stats...</p></div>
    </>
  );

  const grades = ['A', 'B', 'C', 'D', 'E'];
  const maxGradeCount = Math.max(...grades.map(g => stats.gradeDistribution[g] || 0), 1);

  return (
    <>
      <Navbar />
      <div className="page container">
        <h1 className="page-title">Platform Impact</h1>
        <p className="page-sub">Live stats on capital deployed, businesses funded, and investor returns.</p>

        <div className="stats-row">
          {[
            { value: `$${Number(stats.totalCapitalDeployed).toLocaleString()}`, label: 'Capital Deployed' },
            { value: `$${Number(stats.totalRepaid).toLocaleString()}`, label: 'Total Repaid' },
            { value: stats.totalLoans, label: 'Total Loans' },
            { value: stats.totalBorrowers, label: 'Borrowers' },
            { value: stats.totalInvestors, label: 'Investors' },
            { value: stats.totalInvestments, label: 'Investments Made' },
            { value: stats.paidInstallments, label: 'Installments Paid' },
            { value: stats.completedLoans, label: 'Loans Completed' },
          ].map(s => (
            <div className="stat-card" key={s.label}>
              <div className="stat-value">{s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Loan status breakdown */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginTop: '2rem' }}>
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: '1.2rem' }}>Loan Status Breakdown</h3>
            {[
              { label: 'Listed (seeking funding)', value: stats.listedLoans, color: 'var(--teal)' },
              { label: 'Funded (disbursed)', value: stats.fundedLoans, color: '#1d4ed8' },
              { label: 'Completed', value: stats.completedLoans, color: 'var(--success)' },
            ].map(item => (
              <div key={item.label} style={{ marginBottom: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.3rem' }}>
                  <span>{item.label}</span>
                  <strong>{item.value}</strong>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{
                    width: stats.totalLoans ? `${(item.value / stats.totalLoans) * 100}%` : '0%',
                    background: item.color,
                  }} />
                </div>
              </div>
            ))}
          </div>

          {/* Risk grade distribution */}
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: '1.2rem' }}>Risk Grade Distribution</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
              {grades.map(g => {
                const count = stats.gradeDistribution[g] || 0;
                const pct = Math.round((count / maxGradeCount) * 100);
                return (
                  <div key={g} style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span className={`badge badge-${g}`} style={{ width: '36px', textAlign: 'center' }}>{g}</span>
                    <div style={{ flex: 1 }}>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${pct}%`, background: GRADE_COLORS[g] }} />
                      </div>
                    </div>
                    <span style={{ fontSize: '0.85rem', fontWeight: 700, width: '24px', textAlign: 'right' }}>{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Impact statement */}
        <div className="card" style={{ marginTop: '1.5rem', background: 'var(--teal-light)', border: 'none' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.5rem', textAlign: 'center' }}>
            {[
              { icon: '🌍', stat: '330M', label: 'SMBs globally underserved' },
              { icon: '💸', stat: '$5.2T', label: 'Annual funding gap (World Bank)' },
              { icon: '⚡', stat: '48hrs', label: 'vs 3–6 weeks at banks' },
              { icon: '🪙', stat: '$25', label: 'Minimum investment per note' },
            ].map(i => (
              <div key={i.label}>
                <div style={{ fontSize: '2rem' }}>{i.icon}</div>
                <div style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--teal)' }}>{i.stat}</div>
                <div style={{ fontSize: '0.85rem', color: 'var(--muted)' }}>{i.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
