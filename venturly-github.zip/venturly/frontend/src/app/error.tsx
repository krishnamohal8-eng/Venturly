'use client';
import Link from 'next/link';

export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div className="page container" style={{ textAlign: 'center', paddingTop: '5rem' }}>
      <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>⚠️</div>
      <h1 style={{ fontSize: '2rem', fontWeight: 800, marginBottom: '0.5rem' }}>Something went wrong</h1>
      <p style={{ color: 'var(--muted)', marginBottom: '2rem' }}>{error.message || 'An unexpected error occurred.'}</p>
      <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
        <button className="btn btn-primary" onClick={reset}>Try Again</button>
        <Link href="/" className="btn btn-outline">Go Home</Link>
      </div>
    </div>
  );
}
