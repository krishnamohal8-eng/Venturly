'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Navbar from '@/components/Navbar';
import api from '@/lib/api';
import { getUser } from '@/lib/auth';

export default function AdminPage() {
  const router = useRouter();
  const [users, setUsers] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [audit, setAudit] = useState<any[]>([]);
  const [tab, setTab] = useState<'overview' | 'users' | 'audit'>('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const user = getUser();
    if (!user) { router.push('/login'); return; }

    Promise.all([
      api.get('/users/admin/users'),
      api.get('/stats'),
      api.get('/audit'),
    ]).then(([u, s, a]) => {
      setUsers(u.data);
      setStats(s.data);
      setAudit(a.data);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) return <><Navbar /><div className="page container"><p style={{ color: 'var(--muted)' }}>Loading admin data…</p></div></>;

  const ACTION_COLORS: Record<string, string> = {
    LOAN_LISTED:     '#1d4ed8',
    INVESTMENT_MADE: '#15803d',
    LOAN_FUNDED:     '#0d7a6e',
    REPAYMENT_PAID:  '#16a34a',
    REPAYMENT_LATE:  '#d97706',
    RISK_ALERT:      '#dc2626',
  };

  return (
    <>
      <Navbar />
      <div className="page container">
        <h1 className="page-title">Admin Dashboard</h1>
        <p className="page-sub">Platform overview, user management, and full audit trail.</p>

        {/* Stats row */}
        {stats && (
          <div className="stats-row" style={{ marginBottom: '2rem' }}>
            {[
              { v: stats.totalLoans,           l: 'Total Loans' },
              { v: stats.listedLoans,          l: 'Listed' },
              { v: stats.fundedLoans,          l: 'Funded' },
              { v: stats.completedLoans,       l: 'Completed' },
              { v: stats.totalBorrowers,       l: 'Borrowers' },
              { v: stats.totalInvestors,       l: 'Investors' },
              { v: `$${Number(stats.totalCapitalDeployed).toLocaleString()}`, l: 'Capital Deployed' },
              { v: `$${Number(stats.totalRepaid).toLocaleString()}`,          l: 'Total Repaid' },
            ].map(s => (
              <div className="stat-card" key={s.l}>
                <div className="stat-value" style={{ fontSize: '1.4rem' }}>{s.v}</div>
                <div className="stat-label">{s.l}</div>
              </div>
            ))}
          </div>
        )}

        <div className="tabs">
          <div className={`tab ${tab === 'overview' ? 'active' : ''}`} onClick={() => setTab('overview')}>Overview</div>
          <div className={`tab ${tab === 'users' ? 'active' : ''}`} onClick={() => setTab('users')}>Users ({users?.totalUsers || 0})</div>
          <div className={`tab ${tab === 'audit' ? 'active' : ''}`} onClick={() => setTab('audit')}>Audit Trail ({audit.length})</div>
        </div>

        {/* Overview — grade distribution */}
        {tab === 'overview' && stats && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
            <div className="card">
              <h3 style={{ fontWeight: 700, marginBottom: '1rem' }}>Risk Grade Distribution</h3>
              {['A','B','C','D','E'].map(g => {
                const count = stats.gradeDistribution[g] || 0;
                const max = Math.max(...Object.values(stats.gradeDistribution as Record<string,number>), 1);
                return (
                  <div key={g} style={{ display: 'flex', alignItems: 'center', gap: '0.8rem', marginBottom: '0.6rem' }}>
                    <span className={`badge badge-${g}`} style={{ width: 32, textAlign: 'center' }}>{g}</span>
                    <div style={{ flex: 1 }}>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${(count / max) * 100}%` }} />
                      </div>
                    </div>
                    <span style={{ fontSize: '0.85rem', fontWeight: 700, width: 20 }}>{count}</span>
                  </div>
                );
              })}
            </div>
            <div className="card">
              <h3 style={{ fontWeight: 700, marginBottom: '1rem' }}>Loan Status</h3>
              {[
                { l: 'Listed',    v: stats.listedLoans,    c: 'var(--teal)' },
                { l: 'Funded',    v: stats.fundedLoans,    c: '#1d4ed8' },
                { l: 'Completed', v: stats.completedLoans, c: 'var(--success)' },
              ].map(s => (
                <div key={s.l} style={{ marginBottom: '0.8rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.3rem' }}>
                    <span>{s.l}</span><strong>{s.v}</strong>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width: stats.totalLoans ? `${(s.v / stats.totalLoans) * 100}%` : '0%', background: s.c }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Users table */}
        {tab === 'users' && users && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {[
              { title: `Borrowers (${users.borrowers.length})`, data: users.borrowers, role: 'borrower' },
              { title: `Investors (${users.investors.length})`, data: users.investors, role: 'investor' },
            ].map(group => (
              <div key={group.role} className="card" style={{ overflowX: 'auto' }}>
                <h3 style={{ fontWeight: 700, marginBottom: '1rem' }}>{group.title}</h3>
                <table className="admin-table">
                  <thead>
                    <tr>
                      {['Name', 'Email', 'KYC', 'Joined'].map(h => <th key={h}>{h}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {group.data.map((u: any) => (
                      <tr key={u.id}>
                        <td style={{ fontWeight: 600 }}>{u.name}</td>
                        <td style={{ color: 'var(--muted)' }}>{u.email}</td>
                        <td>
                          <span style={{ color: u.kycVerified ? 'var(--success)' : 'var(--danger)', fontWeight: 600 }}>
                            {u.kycVerified ? '✓ Verified' : '✗ Pending'}
                          </span>
                        </td>
                        <td style={{ color: 'var(--muted)', fontSize: '0.82rem' }}>
                          {new Date(u.createdAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))}
          </div>
        )}

        {/* Audit trail */}
        {tab === 'audit' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {audit.map(entry => (
              <div key={entry.id} className="card" style={{ padding: '0.8rem 1rem', display: 'flex', gap: '0.8rem', alignItems: 'flex-start' }}>
                <span style={{
                  background: `${ACTION_COLORS[entry.action] || '#6b7280'}20`,
                  color: ACTION_COLORS[entry.action] || '#6b7280',
                  padding: '0.2rem 0.6rem', borderRadius: '6px',
                  fontSize: '0.72rem', fontWeight: 700, whiteSpace: 'nowrap', flexShrink: 0,
                }}>
                  {entry.action}
                </span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  {entry.amount && <span style={{ fontWeight: 700, marginRight: '0.5rem' }}>${Number(entry.amount).toFixed(2)}</span>}
                  <span style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>
                    {entry.loanId && `loan: ${entry.loanId.slice(0, 8)}…`}
                  </span>
                  <div style={{ fontSize: '0.72rem', color: 'var(--muted)', fontFamily: 'monospace', marginTop: '0.15rem' }}>
                    {new Date(entry.createdAt).toLocaleString()} · hash: {entry.hash}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
