import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Venturly – The Intelligent Bridge for Small Business Capital',
  description: 'AI-powered P2P micro-lending marketplace connecting small businesses with investors.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
