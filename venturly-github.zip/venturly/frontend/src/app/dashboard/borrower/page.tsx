'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import api from '@/lib/api';
import { getUser } from '@/lib/auth';

export default function BorrowerDashboard() {
  const router = useRouter();
  const [tab, setTab] = useState<'loans' | 'apply' | 'risk'>('loans');
  const [loans, setLoans] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState('');
  const [form, setForm] = useState({
    amount: 5000, termMonths: 12, businessDescription: '',
    monthlyRevenue: 2000, monthsInBusiness: 12,
    hasConnectedBank: true, hasConnectedSales: false,
    esgCategory: '',
  });

  useEffect(() => {
    const user = getUser();
    if (!user || user.role !== 'borrower') { router.push('/login'); return; }
    loadLoans();
  }, []);

  const loadLoans = async () => {
    try {
      const { data } = await api.get('/loans/my/loans');
      setLoans(data);
    } catch { /* ignore */ }
    finally { setLoading(false); }
  };

  const apply = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true); setMsg('');
    try {
      await api.post('/loans/apply', form);
      setMsg('Loan application submitted and listed on the marketplace!');
      setTab('loans');
      loadLoans();
    } catch (e: any) {
      setMsg(e.response?.data?.message || 'Application failed.');
    } finally { setSubmitting(false); }
  };

  return (
    <>
      <Navbar />
      <div className="page container">
        <h1 className="page-title">Borrower Dashboard</h1>
        <div className="tabs">
          <div className={`tab ${tab === 'loans' ? 'active' : ''}`} onClick={() => setTab('loans')}>My Loans</div>
          <div className={`tab ${tab === 'apply' ? 'active' : ''}`} onClick={() => setTab('apply')}>Apply for Capital</div>
          <div className={`tab ${tab === 'risk' ? 'active' : ''}`} onClick={() => setTab('risk')}>Risk Check</div>
        </div>

        {tab === 'loans' && (
          loading ? <p style={{ color: 'var(--muted)' }}>Loading...</p> :
          loans.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
              <p style={{ color: 'var(--muted)', marginBottom: '1rem' }}>No loans yet.</p>
              <button className="btn btn-primary" onClick={() => setTab('apply')}>Apply Now</button>
            </div>
          ) : (
            <div className="card-grid">
              {loans.map(loan => (
                <div className="card" key={loan.id}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.8rem' }}>
                    <span style={{ fontWeight: 700 }}>${Number(loan.amount).toLocaleString()}</span>
                    <span className={`badge badge-${loan.riskGrade}`}>Grade {loan.riskGrade}</span>
                  </div>
                  <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginBottom: '0.8rem' }}>{loan.businessDescription}</p>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.4rem', fontSize: '0.85rem' }}>
                    <span>Score: <strong style={{ color: 'var(--teal)' }}>{loan.quantumScore}/100</strong></span>
                    <span>Rate: <strong>{loan.interestRatePercent}% APR</strong></span>
                    <span>Term: <strong>{loan.termMonths} months</strong></span>
                    <span>Status: <strong style={{ color: loan.status === 'funded' ? 'var(--success)' : 'var(--teal)' }}>{loan.status}</strong></span>
                  </div>
                  <div style={{ marginTop: '0.8rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.3rem' }}>
                      <span>{Math.round((loan.fundedTokens / loan.totalTokens) * 100)}% funded</span>
                      <span>${loan.fundedTokens * 25} / ${loan.totalTokens * 25}</span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${(loan.fundedTokens / loan.totalTokens) * 100}%` }} />
                    </div>
                  </div>
                  <Link href={`/loans/${loan.id}`} style={{ fontSize: '0.85rem', color: 'var(--teal)', marginTop: '0.4rem', display: 'inline-block' }}>
                    View schedule & audit →
                  </Link>
                </div>
              ))}
            </div>
          )
        )}

        {tab === 'apply' && (
          <div style={{ maxWidth: 560 }}>
            {msg && <div className={`alert ${msg.includes('submitted') ? 'alert-success' : 'alert-error'}`}>{msg}</div>}
            <QuantumScorePreview form={form} />
            <form onSubmit={apply} className="card" style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
              <p style={{ marginBottom: '1.2rem', color: 'var(--muted)', fontSize: '0.9rem' }}>
                Connect your business data for the best Quantum Score. No manual paperwork required.
              </p>
              <div className="form-group">
                <label>Loan Amount ($)</label>
                <input type="number" min={500} max={50000} required value={form.amount}
                  onChange={e => setForm({ ...form, amount: Number(e.target.value) })} />
              </div>
              <div className="form-group">
                <label>Loan Term (months)</label>
                <select value={form.termMonths} onChange={e => setForm({ ...form, termMonths: Number(e.target.value) })}>
                  {[6, 12, 18, 24, 36].map(t => <option key={t} value={t}>{t} months</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Business Description</label>
                <textarea rows={3} required value={form.businessDescription}
                  onChange={e => setForm({ ...form, businessDescription: e.target.value })}
                  placeholder="What does your business do and how will you use this capital?" />
              </div>
              <div className="form-group">
                <label>Monthly Revenue ($)</label>
                <input type="number" min={0} required value={form.monthlyRevenue}
                  onChange={e => setForm({ ...form, monthlyRevenue: Number(e.target.value) })} />
              </div>
              <div className="form-group">
                <label>Months in Business</label>
                <input type="number" min={0} required value={form.monthsInBusiness}
                  onChange={e => setForm({ ...form, monthsInBusiness: Number(e.target.value) })} />
              </div>
              <div style={{ display: 'flex', gap: '1.5rem', marginBottom: '1rem' }}>
                <label style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', cursor: 'pointer', fontSize: '0.9rem' }}>
                  <input type="checkbox" checked={form.hasConnectedBank}
                    onChange={e => setForm({ ...form, hasConnectedBank: e.target.checked })} />
                  Bank account connected (via Plaid)
                </label>
                <label style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', cursor: 'pointer', fontSize: '0.9rem' }}>
                  <input type="checkbox" checked={form.hasConnectedSales}
                    onChange={e => setForm({ ...form, hasConnectedSales: e.target.checked })} />
                  Sales platform connected (Shopify/Amazon)
                </label>
              </div>
              <div className="form-group">
                <label>ESG / Impact Category (optional)</label>
                <select value={form.esgCategory} onChange={e => setForm({ ...form, esgCategory: e.target.value })}>
                  <option value="">None</option>
                  <option value="Women-Owned">Women-Owned Business</option>
                  <option value="Minority-Owned">Minority-Owned Business</option>
                  <option value="Green Business">Green / Sustainable Business</option>
                  <option value="Rural Business">Rural / Underserved Community</option>
                  <option value="Social Enterprise">Social Enterprise</option>
                </select>
                <span style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>ESG-tagged loans receive a +10 point boost to their Quantum Score.</span>
              </div>
              <button className="btn btn-primary" disabled={submitting}>
                {submitting ? 'Submitting...' : 'Submit Application'}
              </button>
            </form>
          </div>
        )}

        {tab === 'risk' && <RiskCheckPanel loans={loans} />}
      </div>
    </>
  );
}

function RiskCheckPanel({ loans }: { loans: any[] }) {
  const [loanId, setLoanId] = useState('');
  const [balance, setBalance] = useState(1000);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const check = async () => {
    setLoading(true); setResult(null);
    try {
      const { data } = await api.post(`/repayments/${loanId}/risk-check`, { currentBalance: balance });
      setResult(data);
    } catch (e: any) { setResult({ message: e.response?.data?.message || 'Error' }); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ maxWidth: 480 }}>
      <p style={{ color: 'var(--muted)', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
        Simulate the AI risk trigger — checks if your bank balance is below the safety threshold and alerts the collections module.
      </p>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <div className="form-group" style={{ marginBottom: 0 }}>
          <label>Select Loan</label>
          <select value={loanId} onChange={e => setLoanId(e.target.value)}>
            <option value="">-- choose a loan --</option>
            {loans.map(l => (
              <option key={l.id} value={l.id}>${Number(l.amount).toLocaleString()} · {l.businessDescription?.slice(0, 40)}</option>
            ))}
          </select>
        </div>
        <div className="form-group" style={{ marginBottom: 0 }}>
          <label>Current Bank Balance ($)</label>
          <input type="number" min={0} value={balance} onChange={e => setBalance(Number(e.target.value))} />
        </div>
        <button className="btn btn-primary" disabled={!loanId || loading} onClick={check}>
          {loading ? 'Checking...' : 'Run Risk Check'}
        </button>
        {result && (
          <div className={`alert ${result.isAtRisk ? 'alert-error' : 'alert-success'}`}>
            {result.isAtRisk ? '⚠️ ' : '✅ '}{result.message}
            {result.threshold && <div style={{ marginTop: '0.3rem', fontSize: '0.85rem' }}>Threshold: ${result.threshold} · Balance: ${result.currentBalance}</div>}
          </div>
        )}
      </div>
    </div>
  );
}

// Live Quantum Score preview — recalculates client-side as the form changes
function QuantumScorePreview({ form }: { form: any }) {
  const revenueRatio = form.amount > 0 ? (form.monthlyRevenue * 12) / form.amount : 0;
  let score = 0;
  score += Math.min(40, revenueRatio * 10);
  score += Math.min(20, form.monthsInBusiness * 0.5);
  if (form.hasConnectedBank)  score += 10;
  if (form.hasConnectedSales) score += 10;
  score += 20;
  if (form.esgCategory) score += 10;
  score = Math.round(Math.min(100, score));

  const grade = score >= 80 ? 'A' : score >= 65 ? 'B' : score >= 50 ? 'C' : score >= 40 ? 'D' : 'E';
  const rate  = { A: 8, B: 10, C: 13, D: 16, E: 20 }[grade];
  const approved = score >= 40;

  return (
    <div className="card" style={{
      marginBottom: '1rem', padding: '1rem',
      background: approved ? 'var(--teal-light)' : '#fee2e2',
      border: `1px solid ${approved ? 'var(--teal)' : 'var(--danger)'}`,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
        <div>
          <div style={{ fontSize: '0.8rem', color: 'var(--muted)', marginBottom: '0.2rem' }}>Live Quantum Score Preview</div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: approved ? 'var(--teal)' : 'var(--danger)' }}>
            {score}/100
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <span className={`badge badge-${grade}`} style={{ fontSize: '1rem', padding: '0.3rem 0.8rem' }}>Grade {grade}</span>
          <div style={{ fontSize: '0.82rem', marginTop: '0.3rem', color: 'var(--muted)' }}>
            {approved ? `${rate}% APR if approved` : 'Score too low — improve your data'}
          </div>
        </div>
      </div>
      <div style={{ marginTop: '0.8rem' }}>
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${score}%`, background: approved ? 'var(--teal)' : 'var(--danger)' }} />
        </div>
      </div>
    </div>
  );
}
