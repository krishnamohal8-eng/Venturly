'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import api from '@/lib/api';
import { getUser } from '@/lib/auth';

export default function InvestorAnalytics() {
  const router = useRouter();
  const [investments, setInvestments] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const user = getUser();
    if (!user || user.role !== 'investor') { router.push('/login'); return; }
    Promise.all([
      api.get('/investments/my'),
      api.get('/investments/my/stats'),
    ]).then(([inv, st]) => {
      setInvestments(inv.data);
      setStats(st.data);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return <><Navbar /><div className="page container"><p style={{ color: 'var(--muted)' }}>Loading analytics…</p></div></>;

  // Grade distribution
  const byGrade = investments.reduce((acc: Record<string, { count: number; amount: number }>, inv) => {
    const g = inv.loan?.riskGrade || '?';
    if (!acc[g]) acc[g] = { count: 0, amount: 0 };
    acc[g].count++;
    acc[g].amount += Number(inv.amount);
    return acc;
  }, {});

  // Status distribution
  const byStatus = investments.reduce((acc: Record<string, number>, inv) => {
    const s = inv.loan?.status || 'unknown';
    acc[s] = (acc[s] || 0) + 1;
    return acc;
  }, {});

  const totalInvested  = Number(stats?.totalInvested || 0);
  const totalRepaid    = Number(stats?.totalRepaid || 0);
  const expectedReturn = Number(stats?.expectedReturn || 0);
  const roi            = totalInvested > 0 ? ((totalRepaid / totalInvested) * 100).toFixed(1) : '0.0';
  const avgRate        = investments.length > 0
    ? (investments.reduce((s, i) => s + Number(i.loan?.interestRatePercent || 0), 0) / investments.length).toFixed(1)
    : '0';

  const GRADE_COLORS: Record<string, string> = { A: '#15803d', B: '#1d4ed8', C: '#a16207', D: '#c2410c', E: '#b91c1c' };
  const STATUS_COLORS: Record<string, string> = { listed: 'var(--teal)', funded: '#1d4ed8', repaying: '#15803d', completed: 'var(--success)', defaulted: '#dc2626' };

  const maxGradeAmount = Math.max(...Object.values(byGrade).map((v: any) => v.amount), 1);

  return (
    <>
      <Navbar />
      <div className="page container">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '0.5rem' }}>
          <h1 className="page-title" style={{ marginBottom: 0 }}>Portfolio Analytics</h1>
          <Link href="/dashboard/investor" className="btn btn-outline btn-sm">← Back to Portfolio</Link>
        </div>
        <p className="page-sub">Deep dive into your investment performance.</p>

        {/* KPI row */}
        <div className="stats-row">
          {[
            { v: `$${totalInvested.toLocaleString()}`,  l: 'Total Invested',       c: 'var(--teal)' },
            { v: `$${totalRepaid.toFixed(2)}`,          l: 'Repaid to You',        c: 'var(--success)' },
            { v: `$${expectedReturn.toFixed(0)}`,       l: 'Expected Annual',      c: '#1d4ed8' },
            { v: `${roi}%`,                             l: 'ROI So Far',           c: '#15803d' },
            { v: `${avgRate}%`,                         l: 'Avg Interest Rate',    c: '#a16207' },
            { v: investments.length,                    l: 'Active Investments',   c: 'var(--text)' },
          ].map(s => (
            <div className="stat-card" key={s.l}>
              <div className="stat-value" style={{ color: s.c, fontSize: '1.5rem' }}>{s.v}</div>
              <div className="stat-label">{s.l}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginTop: '1.5rem' }}>
          {/* Grade distribution */}
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: '1.2rem' }}>Portfolio by Risk Grade</h3>
            {Object.entries(byGrade).sort().map(([g, data]: [string, any]) => (
              <div key={g} style={{ marginBottom: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.3rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span className={`badge badge-${g}`}>{g}</span>
                    <span>{data.count} investment{data.count !== 1 ? 's' : ''}</span>
                  </div>
                  <strong>${data.amount.toLocaleString()}</strong>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{
                    width: `${(data.amount / maxGradeAmount) * 100}%`,
                    background: GRADE_COLORS[g] || 'var(--teal)',
                  }} />
                </div>
              </div>
            ))}
            {Object.keys(byGrade).length === 0 && (
              <p style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>No investments yet.</p>
            )}
          </div>

          {/* Status distribution */}
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: '1.2rem' }}>Portfolio by Loan Status</h3>
            {Object.entries(byStatus).map(([status, count]: [string, any]) => (
              <div key={status} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.6rem 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <div style={{ width: 10, height: 10, borderRadius: '50%', background: STATUS_COLORS[status] || 'var(--muted)' }} />
                  <span style={{ fontSize: '0.9rem', textTransform: 'capitalize' }}>{status}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                  <span style={{ fontWeight: 700 }}>{count}</span>
                  <span style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>
                    ({Math.round((count / investments.length) * 100)}%)
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Repayment progress */}
          <div className="card" style={{ gridColumn: '1 / -1' }}>
            <h3 style={{ fontWeight: 700, marginBottom: '1.2rem' }}>Repayment Progress by Investment</h3>
            {investments.length === 0 ? (
              <p style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>No investments yet.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
                {investments.map(inv => {
                  const repaidPct = Number(inv.amount) > 0
                    ? Math.min(100, Math.round((Number(inv.repaidAmount) / Number(inv.amount)) * 100))
                    : 0;
                  return (
                    <div key={inv.id}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', marginBottom: '0.3rem' }}>
                        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                          <span className={`badge badge-${inv.loan?.riskGrade}`}>{inv.loan?.riskGrade}</span>
                          <span style={{ color: 'var(--muted)' }}>{inv.loan?.businessDescription?.slice(0, 40)}…</span>
                        </div>
                        <span>
                          <strong style={{ color: 'var(--success)' }}>${Number(inv.repaidAmount).toFixed(2)}</strong>
                          <span style={{ color: 'var(--muted)' }}> / ${Number(inv.amount).toFixed(2)}</span>
                        </span>
                      </div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{
                          width: `${repaidPct}%`,
                          background: repaidPct === 100 ? 'var(--success)' : 'var(--teal)',
                        }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Top performers */}
          <div className="card" style={{ gridColumn: '1 / -1' }}>
            <h3 style={{ fontWeight: 700, marginBottom: '1rem' }}>All Investments</h3>
            <div style={{ overflowX: 'auto' }}>
              <table className="admin-table">
                <thead>
                  <tr>
                    {['Business', 'Grade', 'Invested', 'Rate', 'Repaid', 'Status', ''].map(h => <th key={h}>{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {investments.map(inv => (
                    <tr key={inv.id}>
                      <td style={{ maxWidth: 200 }}>{inv.loan?.businessDescription?.slice(0, 35)}…</td>
                      <td><span className={`badge badge-${inv.loan?.riskGrade}`}>{inv.loan?.riskGrade}</span></td>
                      <td style={{ fontWeight: 600 }}>${Number(inv.amount).toLocaleString()}</td>
                      <td style={{ color: 'var(--teal)' }}>{inv.loan?.interestRatePercent}%</td>
                      <td style={{ color: 'var(--success)', fontWeight: 600 }}>${Number(inv.repaidAmount).toFixed(2)}</td>
                      <td style={{ textTransform: 'capitalize', color: STATUS_COLORS[inv.loan?.status] || 'var(--muted)' }}>
                        {inv.loan?.status}
                      </td>
                      <td>
                        <Link href={`/loans/${inv.loan?.id}`} style={{ color: 'var(--teal)', fontSize: '0.82rem' }}>
                          View →
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
