'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import api from '@/lib/api';
import { getUser } from '@/lib/auth';

export default function InvestorDashboard() {
  const router = useRouter();
  const [investments, setInvestments] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [schedules, setSchedules] = useState<Record<string, any[]>>({});

  useEffect(() => {
    const user = getUser();
    if (!user || user.role !== 'investor') { router.push('/login'); return; }
    Promise.all([
      api.get('/investments/my'),
      api.get('/investments/my/stats'),
    ]).then(([inv, st]) => {
      setInvestments(inv.data);
      setStats(st.data);
    }).finally(() => setLoading(false));
  }, []);

  const toggleSchedule = async (inv: any) => {
    const loanId = inv.loan?.id;
    if (!loanId) return;
    if (expanded === inv.id) { setExpanded(null); return; }
    setExpanded(inv.id);
    if (!schedules[loanId]) {
      try {
        const { data } = await api.get(`/repayments/${loanId}/schedule`);
        setSchedules(prev => ({ ...prev, [loanId]: data }));
      } catch { setSchedules(prev => ({ ...prev, [loanId]: [] })); }
    }
  };

  const statusColor: Record<string, string> = {
    scheduled: 'var(--muted)', paid: 'var(--success)', late: '#d97706', defaulted: 'var(--danger)',
  };

  // Yield calculation per investment
  const calcYield = (inv: any) => {
    const rate = inv.loan?.interestRatePercent || 0;
    return ((Number(inv.amount) * rate) / 100).toFixed(2);
  };

  return (
    <>
      <Navbar />
      <div className="page container">
        <h1 className="page-title">Investor Portfolio</h1>
        <p className="page-sub">Track your micro-note investments, repayment schedules, and returns.</p>

        {stats && (
          <div className="stats-row">
            <div className="stat-card">
              <div className="stat-value">${Number(stats.totalInvested).toLocaleString()}</div>
              <div className="stat-label">Total Invested</div>
            </div>
            <div className="stat-card">
              <div className="stat-value" style={{ color: 'var(--success)' }}>${Number(stats.expectedReturn).toFixed(0)}</div>
              <div className="stat-label">Expected Annual Return</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{stats.activeInvestments}</div>
              <div className="stat-label">Active Investments</div>
            </div>
            <div className="stat-card">
              <div className="stat-value" style={{ color: 'var(--success)' }}>${Number(stats.totalRepaid).toFixed(2)}</div>
              <div className="stat-label">Repaid to You</div>
            </div>
          </div>
        )}

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '1.5rem 0 1rem' }}>
          <h2 style={{ fontSize: '1.2rem', fontWeight: 700 }}>My Investments</h2>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <Link href="/dashboard/investor/analytics" className="btn btn-outline btn-sm">📊 Analytics</Link>
            <Link href="/marketplace" className="btn btn-primary btn-sm">+ Fund More Loans</Link>
          </div>
        </div>

        {loading ? (
          <p style={{ color: 'var(--muted)' }}>Loading...</p>
        ) : investments.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
            <p style={{ color: 'var(--muted)', marginBottom: '1rem' }}>No investments yet.</p>
            <Link href="/marketplace" className="btn btn-primary">Browse Marketplace</Link>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {investments.map(inv => {
              const loanId = inv.loan?.id;
              const schedule = schedules[loanId] || [];
              const paidCount = schedule.filter((r: any) => r.status === 'paid').length;
              const isOpen = expanded === inv.id;

              return (
                <div className="card" key={inv.id} style={{ padding: '1.2rem' }}>
                  {/* Header row */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, marginBottom: '0.2rem' }}>
                        {inv.loan?.businessDescription?.slice(0, 55) || 'Business Loan'}
                        {inv.loan?.esgCategory && (
                          <span style={{ marginLeft: '0.5rem', fontSize: '0.75rem', background: '#dcfce7', color: '#15803d', padding: '0.15rem 0.5rem', borderRadius: '999px' }}>
                            🌱 {inv.loan.esgCategory}
                          </span>
                        )}
                      </div>
                      <div style={{ fontSize: '0.82rem', color: 'var(--muted)' }}>
                        {inv.tokens} tokens · ${Number(inv.amount).toLocaleString()} invested · {inv.loan?.interestRatePercent}% APR
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                      <span className={`badge badge-${inv.loan?.riskGrade}`}>Grade {inv.loan?.riskGrade}</span>
                      <span style={{
                        fontSize: '0.8rem', padding: '0.2rem 0.6rem', borderRadius: '6px',
                        background: inv.loan?.status === 'completed' ? '#dcfce7' : 'var(--teal-light)',
                        color: inv.loan?.status === 'completed' ? 'var(--success)' : 'var(--teal)',
                        fontWeight: 600, textTransform: 'capitalize',
                      }}>{inv.loan?.status}</span>
                    </div>
                  </div>

                  {/* Returns row */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '0.6rem', margin: '0.8rem 0', fontSize: '0.85rem' }}>
                    <div style={{ background: '#f9fafb', borderRadius: '8px', padding: '0.5rem 0.8rem' }}>
                      <div style={{ color: 'var(--muted)', fontSize: '0.78rem' }}>Invested</div>
                      <div style={{ fontWeight: 700 }}>${Number(inv.amount).toLocaleString()}</div>
                    </div>
                    <div style={{ background: '#f9fafb', borderRadius: '8px', padding: '0.5rem 0.8rem' }}>
                      <div style={{ color: 'var(--muted)', fontSize: '0.78rem' }}>Annual Yield</div>
                      <div style={{ fontWeight: 700, color: 'var(--success)' }}>+${calcYield(inv)}</div>
                    </div>
                    <div style={{ background: '#f9fafb', borderRadius: '8px', padding: '0.5rem 0.8rem' }}>
                      <div style={{ color: 'var(--muted)', fontSize: '0.78rem' }}>Repaid to You</div>
                      <div style={{ fontWeight: 700, color: 'var(--success)' }}>${Number(inv.repaidAmount).toFixed(2)}</div>
                    </div>
                    {schedule.length > 0 && (
                      <div style={{ background: '#f9fafb', borderRadius: '8px', padding: '0.5rem 0.8rem' }}>
                        <div style={{ color: 'var(--muted)', fontSize: '0.78rem' }}>Installments</div>
                        <div style={{ fontWeight: 700 }}>{paidCount}/{schedule.length} paid</div>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div style={{ display: 'flex', gap: '0.8rem', alignItems: 'center', flexWrap: 'wrap' }}>
                    <button
                      className="btn btn-outline btn-sm"
                      onClick={() => toggleSchedule(inv)}
                    >
                      {isOpen ? 'Hide Schedule' : 'View Repayment Schedule'}
                    </button>
                    <Link href={`/loans/${loanId}`} style={{ fontSize: '0.85rem', color: 'var(--teal)' }}>
                      Audit trail →
                    </Link>
                  </div>

                  {/* Inline repayment schedule */}
                  {isOpen && (
                    <div style={{ marginTop: '1rem', overflowX: 'auto' }}>
                      {schedule.length === 0 ? (
                        <p style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>No repayment schedule generated yet.</p>
                      ) : (
                        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.82rem' }}>
                          <thead>
                            <tr style={{ borderBottom: '2px solid var(--border)' }}>
                              {['#', 'Due Date', 'Total Due', 'Your Share', 'Status', 'Paid On'].map(h => (
                                <th key={h} style={{ padding: '0.4rem 0.6rem', color: 'var(--muted)', fontWeight: 600, textAlign: 'left' }}>{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {schedule.map((r: any) => {
                              // Investor's proportional share of each installment
                              const totalFunded = inv.loan?.amount || 1;
                              const share = Number(inv.amount) / Number(totalFunded);
                              const myShare = (Number(r.totalDue) * share).toFixed(2);
                              return (
                                <tr key={r.id} style={{ borderBottom: '1px solid var(--border)' }}>
                                  <td style={{ padding: '0.4rem 0.6rem' }}>{r.installmentNumber}</td>
                                  <td style={{ padding: '0.4rem 0.6rem' }}>{r.dueDate}</td>
                                  <td style={{ padding: '0.4rem 0.6rem' }}>${Number(r.totalDue).toFixed(2)}</td>
                                  <td style={{ padding: '0.4rem 0.6rem', fontWeight: 700, color: 'var(--teal)' }}>${myShare}</td>
                                  <td style={{ padding: '0.4rem 0.6rem', color: statusColor[r.status], fontWeight: 600, textTransform: 'capitalize' }}>{r.status}</td>
                                  <td style={{ padding: '0.4rem 0.6rem', color: 'var(--muted)' }}>{r.paidDate || '—'}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}
