import Link from 'next/link';
import Navbar from '@/components/Navbar';

export default function NotFound() {
  return (
    <>
      <Navbar />
      <div className="page container" style={{ textAlign: 'center', paddingTop: '5rem' }}>
        <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🔍</div>
        <h1 style={{ fontSize: '2rem', fontWeight: 800, marginBottom: '0.5rem' }}>Page not found</h1>
        <p style={{ color: 'var(--muted)', marginBottom: '2rem' }}>That page doesn't exist or has been moved.</p>
        <Link href="/" className="btn btn-primary">Back to Home</Link>
      </div>
    </>
  );
}
