'use client';
import { useEffect, useRef } from 'react';
import Navbar from '@/components/Navbar';

export default function ApiDocsPage() {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  return (
    <>
      <Navbar />
      <div style={{ background: '#f9fafb', borderBottom: '1px solid var(--border)', padding: '1.5rem 0' }}>
        <div className="container">
          <h1 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: '0.3rem' }}>API Reference</h1>
          <p style={{ color: 'var(--muted)', fontSize: '0.95rem' }}>
            Full OpenAPI 3.0 documentation. Authenticate with a JWT token to try endpoints live.
          </p>
          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', flexWrap: 'wrap' }}>
            <a
              href="http://localhost:3001/api"
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary btn-sm"
            >
              Open Full Swagger UI ↗
            </a>
            <a
              href="http://localhost:3001/api-json"
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-outline btn-sm"
            >
              Download OpenAPI JSON ↗
            </a>
          </div>
        </div>
      </div>

      {/* Endpoint reference cards */}
      <div className="container page">
        {ENDPOINT_GROUPS.map(group => (
          <div key={group.tag} style={{ marginBottom: '2.5rem' }}>
            <h2 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ background: 'var(--teal-light)', color: 'var(--teal)', padding: '0.2rem 0.7rem', borderRadius: '6px', fontSize: '0.85rem' }}>
                {group.tag}
              </span>
              {group.description}
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              {group.endpoints.map(ep => (
                <div key={ep.path + ep.method} className="card" style={{ padding: '1rem', display: 'flex', gap: '1rem', alignItems: 'flex-start', flexWrap: 'wrap' }}>
                  <div style={{ display: 'flex', gap: '0.6rem', alignItems: 'center', flexShrink: 0 }}>
                    <span style={{
                      fontFamily: 'monospace', fontWeight: 700, fontSize: '0.78rem',
                      padding: '0.2rem 0.5rem', borderRadius: '4px', minWidth: '52px', textAlign: 'center',
                      background: METHOD_COLORS[ep.method].bg, color: METHOD_COLORS[ep.method].text,
                    }}>
                      {ep.method}
                    </span>
                    <code style={{ fontSize: '0.88rem', color: 'var(--text)', fontFamily: 'monospace' }}>{ep.path}</code>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: '0.9rem', marginBottom: '0.2rem' }}>{ep.summary}</div>
                    <div style={{ fontSize: '0.82rem', color: 'var(--muted)' }}>{ep.description}</div>
                  </div>
                  <div style={{ display: 'flex', gap: '0.4rem', flexShrink: 0 }}>
                    {ep.auth && (
                      <span style={{ fontSize: '0.72rem', background: '#fef9c3', color: '#a16207', padding: '0.15rem 0.5rem', borderRadius: '4px', fontWeight: 600 }}>
                        🔒 JWT
                      </span>
                    )}
                    {ep.public && (
                      <span style={{ fontSize: '0.72rem', background: '#dcfce7', color: '#15803d', padding: '0.15rem 0.5rem', borderRadius: '4px', fontWeight: 600 }}>
                        Public
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Quick start */}
        <div className="card" style={{ background: '#1a1a1a', color: '#e5e7eb', padding: '1.5rem', marginTop: '1rem' }}>
          <div style={{ fontWeight: 700, marginBottom: '1rem', color: '#0d7a6e', fontSize: '0.95rem' }}>Quick Start — cURL</div>
          <pre style={{ fontSize: '0.82rem', lineHeight: 1.7, overflowX: 'auto', whiteSpace: 'pre-wrap' }}>{CURL_EXAMPLE}</pre>
        </div>
      </div>
    </>
  );
}

const METHOD_COLORS: Record<string, { bg: string; text: string }> = {
  GET:    { bg: '#dbeafe', text: '#1d4ed8' },
  POST:   { bg: '#dcfce7', text: '#15803d' },
  PATCH:  { bg: '#fef9c3', text: '#a16207' },
  DELETE: { bg: '#fee2e2', text: '#dc2626' },
};

const ENDPOINT_GROUPS = [
  {
    tag: 'Auth', description: 'Register and login',
    endpoints: [
      { method: 'POST', path: '/auth/register', summary: 'Register', description: 'Create a borrower or investor account. Returns JWT token.', auth: false, public: true },
      { method: 'POST', path: '/auth/login',    summary: 'Login',    description: 'Authenticate with email + password. Returns JWT token valid 7 days.', auth: false, public: true },
    ],
  },
  {
    tag: 'Users', description: 'Profile management',
    endpoints: [
      { method: 'GET',   path: '/users/me',           summary: 'Get my profile',    description: 'Returns authenticated user profile.', auth: true, public: false },
      { method: 'PATCH', path: '/users/me',           summary: 'Update my profile', description: 'Update name/password. Password change requires passkey token if registered.', auth: true, public: false },
      { method: 'GET',   path: '/users/admin/users',  summary: 'Admin: all users',  description: 'Returns all borrowers and investors.', auth: true, public: false },
    ],
  },
  {
    tag: 'Loans', description: 'Apply for loans, browse marketplace',
    endpoints: [
      { method: 'GET',  path: '/loans',          summary: 'Browse marketplace',  description: 'All listed loans with risk grades, ESG tags, and funding progress.', auth: false, public: true },
      { method: 'GET',  path: '/loans/my/loans', summary: 'My loans (borrower)', description: 'All loans applied by the authenticated borrower.', auth: true, public: false },
      { method: 'POST', path: '/loans/apply',    summary: 'Apply for a loan',    description: 'Quantum Score engine evaluates and lists the loan instantly if approved.', auth: true, public: false },
      { method: 'GET',  path: '/loans/:id',      summary: 'Get loan by ID',      description: 'Full loan details including borrower, grade, ESG, and funding progress.', auth: false, public: true },
    ],
  },
  {
    tag: 'Investments', description: 'Fund loans, track portfolio',
    endpoints: [
      { method: 'POST', path: '/investments',           summary: 'Fund a loan',         description: 'Purchase $25 micro-note tokens. Funds held in escrow until 100% funded.', auth: true, public: false },
      { method: 'GET',  path: '/investments/my',        summary: 'My investments',       description: 'All investments with loan details and repayment progress.', auth: true, public: false },
      { method: 'GET',  path: '/investments/my/stats',  summary: 'Portfolio stats',      description: 'Total invested, repaid, active count, expected annual return.', auth: true, public: false },
    ],
  },
  {
    tag: 'Repayments', description: 'Amortization schedules, payments, risk checks',
    endpoints: [
      { method: 'GET',  path: '/repayments/:loanId/schedule',       summary: 'Get schedule',          description: 'Full amortization schedule — principal, interest, total per installment.', auth: true, public: false },
      { method: 'POST', path: '/repayments/:loanId/generate',       summary: 'Generate schedule',     description: 'Creates amortization schedule for a funded loan. Moves status to repaying.', auth: true, public: false },
      { method: 'POST', path: '/repayments/:loanId/pay/:n',         summary: 'Pay installment #n',    description: 'Marks installment paid and distributes proportionally to all token holders.', auth: true, public: false },
      { method: 'POST', path: '/repayments/:loanId/risk-check',     summary: 'AI risk trigger check', description: 'Checks if balance is below 10% threshold. Triggers dunning if at risk.', auth: true, public: false },
    ],
  },
  {
    tag: 'Notifications', description: 'Real-time alerts for repayments, funding, and risk events',
    endpoints: [
      { method: 'GET',   path: '/notifications',           summary: 'Get my notifications',     description: 'Last 50 notifications ordered newest-first.', auth: true, public: false },
      { method: 'GET',   path: '/notifications/unread/count', summary: 'Unread count',          description: 'Returns { count: number } for the bell badge.', auth: true, public: false },
      { method: 'PATCH', path: '/notifications/read/all',  summary: 'Mark all read',            description: 'Marks all notifications as read.', auth: true, public: false },
      { method: 'PATCH', path: '/notifications/:id/read',  summary: 'Mark one read',            description: 'Marks a single notification as read.', auth: true, public: false },
    ],
  },
  {
    tag: 'Audit', description: 'Immutable hash-chained transaction ledger',
    endpoints: [
      { method: 'GET', path: '/audit', summary: 'Get audit log', description: 'SHA-256 hash-chained ledger of every money movement. Filter by ?loanId=.', auth: true, public: false },
    ],
  },
  {
    tag: 'Stats', description: 'Platform-wide impact metrics',
    endpoints: [
      { method: 'GET', path: '/stats', summary: 'Platform stats', description: 'Live metrics: capital deployed, loans, investors, grade distribution.', auth: false, public: true },
    ],
  },
];

const CURL_EXAMPLE = `# 1. Register as a borrower
curl -X POST http://localhost:3001/auth/register \\
  -H "Content-Type: application/json" \\
  -d '{"email":"you@example.com","password":"secret123","name":"Your Name","role":"borrower"}'

# 2. Login and grab the token
TOKEN=$(curl -s -X POST http://localhost:3001/auth/login \\
  -H "Content-Type: application/json" \\
  -d '{"email":"you@example.com","password":"secret123"}' | python -c "import sys,json; print(json.load(sys.stdin)['token'])")

# 3. Apply for a loan
curl -X POST http://localhost:3001/loans/apply \\
  -H "Authorization: Bearer $TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"amount":5000,"termMonths":12,"businessDescription":"My business","monthlyRevenue":2000,"monthsInBusiness":12,"hasConnectedBank":true,"hasConnectedSales":false}'

# 4. Browse marketplace (no auth needed)
curl http://localhost:3001/loans

# 5. Check platform stats (no auth needed)
curl http://localhost:3001/stats`;
