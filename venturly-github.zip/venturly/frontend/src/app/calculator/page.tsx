'use client';
import { useState, useMemo } from 'react';
import Navbar from '@/components/Navbar';
import Link from 'next/link';

const RATES: Record<string, number> = { A: 8, B: 10, C: 13, D: 16, E: 20 };

export default function CalculatorPage() {
  const [mode, setMode]       = useState<'borrow' | 'invest'>('borrow');
  const [amount, setAmount]   = useState(10000);
  const [months, setMonths]   = useState(12);
  const [grade, setGrade]     = useState('B');
  const [investAmt, setInvestAmt] = useState(500);

  const rate = RATES[grade];

  const monthly = useMemo(() => {
    const r = rate / 100 / 12;
    if (r === 0) return amount / months;
    return (amount * r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1);
  }, [amount, months, rate]);

  const totalRepay    = monthly * months;
  const totalInterest = totalRepay - amount;

  const tokens        = Math.floor(investAmt / 25);
  const actualInvest  = tokens * 25;
  const annualReturn  = actualInvest * (rate / 100);
  const monthlyReturn = annualReturn / 12;

  const schedule = useMemo(() => {
    const r = rate / 100 / 12;
    let balance = amount;
    return Array.from({ length: Math.min(months, 6) }, (_, i) => {
      const interest  = balance * r;
      const principal = monthly - interest;
      balance -= principal;
      return { n: i + 1, principal, interest, total: monthly, balance: Math.max(0, balance) };
    });
  }, [amount, months, rate, monthly]);

  return (
    <>
      <Navbar />
      <div className="page container" style={{ maxWidth: 820 }}>
        <h1 className="page-title">Loan & Investment Calculator</h1>
        <p className="page-sub">Estimate repayments as a borrower or returns as an investor.</p>

        <div className="tabs">
          <div className={`tab ${mode === 'borrow' ? 'active' : ''}`} onClick={() => setMode('borrow')}>🏦 Borrower</div>
          <div className={`tab ${mode === 'invest' ? 'active' : ''}`} onClick={() => setMode('invest')}>📈 Investor</div>
        </div>

        {mode === 'borrow' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
            <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1.2rem' }}>
              <h3 style={{ fontWeight: 700 }}>Loan Parameters</h3>

              <div className="form-group" style={{ marginBottom: 0 }}>
                <label>Loan Amount: <strong style={{ color: 'var(--teal)' }}>${amount.toLocaleString()}</strong></label>
                <input type="range" min={500} max={50000} step={500} value={amount}
                  onChange={e => setAmount(+e.target.value)}
                  style={{ width: '100%', accentColor: 'var(--teal)', marginTop: '0.4rem' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--muted)' }}>
                  <span>$500</span><span>$50,000</span>
                </div>
              </div>

              <div className="form-group" style={{ marginBottom: 0 }}>
                <label>Term: <strong style={{ color: 'var(--teal)' }}>{months} months</strong></label>
                <input type="range" min={3} max={36} step={3} value={months}
                  onChange={e => setMonths(+e.target.value)}
                  style={{ width: '100%', accentColor: 'var(--teal)', marginTop: '0.4rem' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--muted)' }}>
                  <span>3 mo</span><span>36 mo</span>
                </div>
              </div>

              <div className="form-group" style={{ marginBottom: 0 }}>
                <label>Risk Grade</label>
                <div style={{ display: 'flex', gap: '0.4rem', marginTop: '0.4rem' }}>
                  {Object.entries(RATES).map(([g, r]) => (
                    <button key={g} onClick={() => setGrade(g)}
                      className={`btn btn-sm ${grade === g ? 'btn-primary' : 'btn-outline'}`}
                      style={{ flex: 1, flexDirection: 'column', padding: '0.4rem 0.2rem' }}>
                      <span style={{ fontWeight: 800 }}>{g}</span>
                      <span style={{ fontSize: '0.68rem' }}>{r}%</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div className="card" style={{ background: 'var(--teal-light)', border: '1px solid var(--teal)', textAlign: 'center' }}>
                <div style={{ fontSize: '0.82rem', color: 'var(--muted)', marginBottom: '0.3rem' }}>Monthly Payment</div>
                <div style={{ fontSize: '2.8rem', fontWeight: 800, color: 'var(--teal)' }}>${monthly.toFixed(2)}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>for {months} months at {rate}% APR</div>
              </div>
              <div className="stats-row" style={{ margin: 0 }}>
                <div className="stat-card">
                  <div className="stat-value" style={{ fontSize: '1.3rem' }}>${totalRepay.toFixed(0)}</div>
                  <div className="stat-label">Total Repayment</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value" style={{ fontSize: '1.3rem', color: '#dc2626' }}>${totalInterest.toFixed(0)}</div>
                  <div className="stat-label">Total Interest</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value" style={{ fontSize: '1.3rem' }}>{Math.ceil(amount / 25)}</div>
                  <div className="stat-label">Tokens Issued</div>
                </div>
              </div>
            </div>

            <div className="card" style={{ gridColumn: '1 / -1', overflowX: 'auto' }}>
              <h3 style={{ fontWeight: 700, marginBottom: '1rem' }}>Amortization Preview (first 6 months)</h3>
              <table className="repay-table">
                <thead>
                  <tr>{['#', 'Principal', 'Interest', 'Monthly', 'Balance'].map(h => <th key={h}>{h}</th>)}</tr>
                </thead>
                <tbody>
                  {schedule.map(r => (
                    <tr key={r.n}>
                      <td>{r.n}</td>
                      <td style={{ color: 'var(--teal)', fontWeight: 600 }}>${r.principal.toFixed(2)}</td>
                      <td style={{ color: '#dc2626' }}>${r.interest.toFixed(2)}</td>
                      <td style={{ fontWeight: 700 }}>${r.total.toFixed(2)}</td>
                      <td style={{ color: 'var(--muted)' }}>${r.balance.toFixed(2)}</td>
                    </tr>
                  ))}
                  {months > 6 && (
                    <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--muted)', fontSize: '0.82rem', padding: '0.6rem' }}>
                      … {months - 6} more installments
                    </td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {mode === 'invest' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
            <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1.2rem' }}>
              <h3 style={{ fontWeight: 700 }}>Investment Parameters</h3>

              <div className="form-group" style={{ marginBottom: 0 }}>
                <label>Investment: <strong style={{ color: 'var(--teal)' }}>${actualInvest} ({tokens} tokens)</strong></label>
                <input type="range" min={25} max={10000} step={25} value={investAmt}
                  onChange={e => setInvestAmt(+e.target.value)}
                  style={{ width: '100%', accentColor: 'var(--teal)', marginTop: '0.4rem' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--muted)' }}>
                  <span>$25</span><span>$10,000</span>
                </div>
              </div>

              <div className="form-group" style={{ marginBottom: 0 }}>
                <label>Risk Grade</label>
                <div style={{ display: 'flex', gap: '0.4rem', marginTop: '0.4rem' }}>
                  {Object.entries(RATES).map(([g, r]) => (
                    <button key={g} onClick={() => setGrade(g)}
                      className={`btn btn-sm ${grade === g ? 'btn-primary' : 'btn-outline'}`}
                      style={{ flex: 1, flexDirection: 'column', padding: '0.4rem 0.2rem' }}>
                      <span style={{ fontWeight: 800 }}>{g}</span>
                      <span style={{ fontSize: '0.68rem' }}>{r}%</span>
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ background: '#f9fafb', borderRadius: '8px', padding: '0.8rem', fontSize: '0.82rem' }}>
                <strong>Diversification tip:</strong> Spread ${actualInvest} across{' '}
                <strong style={{ color: 'var(--teal)' }}>{tokens}</strong> different loans at $25 each to minimise risk.
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div className="card" style={{ background: 'var(--teal-light)', border: '1px solid var(--teal)', textAlign: 'center' }}>
                <div style={{ fontSize: '0.82rem', color: 'var(--muted)', marginBottom: '0.3rem' }}>Annual Return</div>
                <div style={{ fontSize: '2.8rem', fontWeight: 800, color: 'var(--teal)' }}>+${annualReturn.toFixed(2)}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>{rate}% APR on ${actualInvest}</div>
              </div>
              <div className="stats-row" style={{ margin: 0 }}>
                <div className="stat-card">
                  <div className="stat-value" style={{ fontSize: '1.3rem' }}>${monthlyReturn.toFixed(2)}</div>
                  <div className="stat-label">Monthly Return</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value" style={{ fontSize: '1.3rem', color: 'var(--success)' }}>
                    ${(actualInvest + annualReturn).toFixed(0)}
                  </div>
                  <div className="stat-label">After 1 Year</div>
                </div>
              </div>
            </div>

            <div className="card" style={{ gridColumn: '1 / -1' }}>
              <h3 style={{ fontWeight: 700, marginBottom: '1rem' }}>Return Comparison — ${actualInvest} invested</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '0.8rem' }}>
                {[
                  { label: 'Savings Account', rate: 0.5,  color: '#9ca3af' },
                  { label: 'Grade A',          rate: 8,   color: '#15803d' },
                  { label: 'Grade B',          rate: 10,  color: '#1d4ed8' },
                  { label: 'Grade C',          rate: 13,  color: '#a16207' },
                  { label: 'Grade D',          rate: 16,  color: '#c2410c' },
                  { label: 'Grade E',          rate: 20,  color: '#b91c1c' },
                ].map(item => (
                  <div key={item.label} style={{
                    textAlign: 'center', padding: '0.8rem', borderRadius: '8px',
                    background: grade === item.label.replace('Grade ', '') ? 'var(--teal-light)' : '#f9fafb',
                    border: grade === item.label.replace('Grade ', '') ? '2px solid var(--teal)' : '1px solid var(--border)',
                  }}>
                    <div style={{ fontWeight: 800, color: item.color, fontSize: '1.2rem' }}>
                      +${(actualInvest * item.rate / 100).toFixed(0)}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--muted)', marginTop: '0.2rem' }}>{item.label}</div>
                    <div style={{ fontSize: '0.72rem', color: item.color, fontWeight: 600 }}>{item.rate}% APR</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div style={{ marginTop: '2rem', display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
          <Link href="/marketplace" className="btn btn-primary">Browse Loans</Link>
          <Link href="/register?role=borrower" className="btn btn-outline">Apply for a Loan</Link>
          <Link href="/register?role=investor" className="btn btn-outline">Start Investing</Link>
        </div>
      </div>
    </>
  );
}
