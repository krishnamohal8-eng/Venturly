'use client';
import { useState } from 'react';
import Link from 'next/link';
import api from '@/lib/api';
import { getUser } from '@/lib/auth';
import { Toast } from './Toast';
import PaymentModal from './PaymentModal';

interface Loan {
  id: string;
  amount: number;
  fundedTokens: number;
  totalTokens: number;
  riskGrade: string;
  quantumScore: number;
  interestRatePercent: number;
  termMonths: number;
  businessDescription: string;
  status: string;
  esgCategory?: string;
  esgScore?: number;
  borrower: { name: string };
}

export default function LoanCard({ loan, onFunded }: { loan: Loan; onFunded?: () => void }) {
  const [tokens, setTokens] = useState(1);
  const [loading, setLoading] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const user = getUser();

  const pct       = Math.round((loan.fundedTokens / loan.totalTokens) * 100);
  const remaining = loan.totalTokens - loan.fundedTokens;

  const invest = async () => {
    if (!user)                  { setToast({ msg: 'Please login as an investor first.', type: 'error' }); return; }
    if (user.role !== 'investor') { setToast({ msg: 'Only investors can fund loans.', type: 'error' }); return; }
    if (tokens < 1 || tokens > remaining) { setToast({ msg: `Enter between 1 and ${remaining} tokens.`, type: 'error' }); return; }

    setLoading(true);
    try {
      await api.post('/investments', { loanId: loan.id, tokens });
      setToast({ msg: `Invested $${tokens * 25} in ${loan.borrower?.name}'s business!`, type: 'success' });
      onFunded?.();
    } catch (e: any) {
      setToast({ msg: e.response?.data?.message || 'Investment failed.', type: 'error' });
    } finally { setLoading(false); }
  };

  return (
    <div className="card loan-card">
      {/* Header */}
      <div className="loan-card-header">
        <div style={{ flex: 1, minWidth: 0 }}>
          <Link href={`/loans/${loan.id}`} className="loan-card-title"
            style={{ color: 'var(--teal)', display: 'block', marginBottom: '0.2rem' }}>
            {loan.businessDescription?.slice(0, 58) || 'Small Business Loan'}
            {loan.businessDescription?.length > 58 ? '…' : ''}
          </Link>
          <div className="loan-card-meta">by {loan.borrower?.name}</div>
        </div>
        <span className={`badge badge-${loan.riskGrade}`}>Grade {loan.riskGrade}</span>
      </div>

      {/* ESG tag */}
      {loan.esgCategory && (
        <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
          <span style={{
            fontSize: '0.75rem', background: '#dcfce7', color: '#15803d',
            padding: '0.15rem 0.6rem', borderRadius: '999px', fontWeight: 600,
          }}>
            🌱 {loan.esgCategory}
          </span>
          {loan.esgScore && (
            <span style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>ESG {loan.esgScore}/100</span>
          )}
        </div>
      )}

      {/* Stats grid */}
      <div className="loan-card-stats">
        <div className="loan-stat">Amount: <span>${Number(loan.amount).toLocaleString()}</span></div>
        <div className="loan-stat">Rate: <span>{loan.interestRatePercent}% APR</span></div>
        <div className="loan-stat">Term: <span>{loan.termMonths} mo</span></div>
        <div className="loan-stat">Score: <span>{loan.quantumScore}/100</span></div>
      </div>

      {/* Funding progress */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', marginBottom: '0.35rem' }}>
          <span style={{ fontWeight: 600, color: pct === 100 ? 'var(--success)' : 'var(--text)' }}>{pct}% funded</span>
          <span style={{ color: 'var(--muted)' }}>{remaining} tokens left · ${remaining * 25}</span>
        </div>
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${pct}%`, background: pct === 100 ? 'var(--success)' : 'var(--teal)' }} />
        </div>
      </div>

      {/* Invest controls */}
      {loan.status === 'listed' && remaining > 0 && user?.role === 'investor' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
          <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
            <input
              type="number" min={1} max={remaining} value={tokens}
              onChange={e => setTokens(Math.max(1, Math.min(remaining, Number(e.target.value))))}
              style={{ width: '72px', padding: '0.4rem 0.6rem', border: '1px solid var(--border)', borderRadius: '6px', fontSize: '0.9rem' }}
            />
            <span style={{ fontSize: '0.82rem', color: 'var(--muted)' }}>
              × $25 = <strong>${tokens * 25}</strong>
            </span>
          </div>
          <button
            className="btn btn-primary"
            onClick={() => {
              if (!user) { setToast({ msg: 'Please login as an investor first.', type: 'error' }); return; }
              setShowPayment(true);
            }}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}
          >
            💳 Pay ${tokens * 25} — Choose Method
          </button>
        </div>
      )}

      {showPayment && (
        <PaymentModal
          loanId={loan.id}
          tokens={tokens}
          onSuccess={(result) => {
            setShowPayment(false);
            setToast({ msg: `Investment of $${tokens * 25} confirmed!`, type: 'success' });
            onFunded?.();
          }}
          onClose={() => setShowPayment(false)}
        />
      )}

      {loan.status === 'funded' && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <span className="badge badge-funded">✓ Fully Funded</span>
        </div>
      )}

      {loan.status === 'repaying' && (
        <span style={{ fontSize: '0.82rem', color: 'var(--success)', fontWeight: 600 }}>● Repaying investors</span>
      )}

      {loan.status === 'completed' && (
        <span style={{ fontSize: '0.82rem', color: 'var(--success)', fontWeight: 600 }}>✓ Loan completed</span>
      )}

      <Link href={`/loans/${loan.id}`} style={{ fontSize: '0.82rem', color: 'var(--teal)' }}>
        View details & audit trail →
      </Link>

      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
