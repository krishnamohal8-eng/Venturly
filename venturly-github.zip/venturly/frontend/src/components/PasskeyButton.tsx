'use client';
import { useState } from 'react';
import { startRegistration, startAuthentication } from '@simplewebauthn/browser';
import api from '@/lib/api';
import { setAuth } from '@/lib/auth';
import { Toast } from './Toast';

// ── PASSKEY LOGIN BUTTON ──────────────────────────────────────────────────────
interface PasskeyLoginProps {
  email: string;
  onSuccess: (user: any) => void;
  onError: (msg: string) => void;
}

export function PasskeyLoginButton({ email, onSuccess, onError }: PasskeyLoginProps) {
  const [loading, setLoading] = useState(false);

  const login = async () => {
    if (!email) { onError('Enter your email first'); return; }
    setLoading(true);
    try {
      // Step 1: get challenge from server
      const { data } = await api.post('/passkeys/authenticate/options', { email });
      const { options, userId } = data;

      // Step 2: browser prompts biometric (fingerprint/face/PIN)
      const authResponse = await startAuthentication({ optionsJSON: options });

      // Step 3: verify with server → get JWT
      const { data: result } = await api.post('/passkeys/authenticate/verify', {
        userId,
        response: authResponse,
      });

      setAuth(result.token, result.user);
      onSuccess(result.user);
    } catch (e: any) {
      if (e?.name === 'NotAllowedError') {
        onError('Passkey authentication was cancelled.');
      } else {
        onError(e?.response?.data?.message || e?.message || 'Passkey login failed.');
      }
    } finally { setLoading(false); }
  };

  return (
    <button
      onClick={login}
      disabled={loading}
      style={{
        width: '100%', padding: '0.75rem', borderRadius: '8px',
        background: loading ? '#e5e7eb' : '#fff',
        border: '2px solid var(--border)', cursor: loading ? 'not-allowed' : 'pointer',
        fontSize: '0.95rem', fontWeight: 600, color: 'var(--text)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.6rem',
        transition: 'all 0.2s',
      }}
      onMouseEnter={e => { if (!loading) (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--teal)'; }}
      onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border)'; }}
    >
      {loading ? (
        <>
          <Spinner />
          Verifying biometric…
        </>
      ) : (
        <>
          <PasskeyIcon />
          Sign in with Passkey
        </>
      )}
    </button>
  );
}

// ── PASSKEY REGISTER BUTTON ───────────────────────────────────────────────────
interface PasskeyRegisterProps {
  onSuccess: (deviceName: string) => void;
  onError: (msg: string) => void;
}

export function PasskeyRegisterButton({ onSuccess, onError }: PasskeyRegisterProps) {
  const [loading, setLoading] = useState(false);
  const [deviceName, setDeviceName] = useState('');
  const [showForm, setShowForm] = useState(false);

  const register = async () => {
    setLoading(true);
    try {
      // Step 1: get registration options
      const { data: options } = await api.get('/passkeys/register/options');

      // Step 2: browser prompts to create passkey (biometric/PIN)
      const regResponse = await startRegistration({ optionsJSON: options });

      // Step 3: verify with server
      const { data: result } = await api.post('/passkeys/register/verify', {
        response: regResponse,
        deviceName: deviceName || 'My Device',
      });

      onSuccess(result.deviceName);
      setShowForm(false);
      setDeviceName('');
    } catch (e: any) {
      if (e?.name === 'NotAllowedError') {
        onError('Passkey creation was cancelled.');
      } else if (e?.name === 'InvalidStateError') {
        onError('A passkey for this device is already registered.');
      } else {
        onError(e?.response?.data?.message || e?.message || 'Passkey registration failed.');
      }
    } finally { setLoading(false); }
  };

  if (!showForm) {
    return (
      <button
        onClick={() => setShowForm(true)}
        className="btn btn-outline"
        style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.6rem' }}
      >
        <PasskeyIcon />
        Add Passkey (Fingerprint / Face ID)
      </button>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
      <input
        placeholder="Device name (e.g. MacBook Touch ID)"
        value={deviceName}
        onChange={e => setDeviceName(e.target.value)}
        style={{ padding: '0.6rem 0.9rem', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '0.9rem' }}
      />
      <div style={{ display: 'flex', gap: '0.5rem' }}>
        <button
          onClick={register}
          disabled={loading}
          className="btn btn-primary"
          style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}
        >
          {loading ? <><Spinner /> Creating…</> : <><PasskeyIcon /> Create Passkey</>}
        </button>
        <button onClick={() => setShowForm(false)} className="btn btn-outline">Cancel</button>
      </div>
      <p style={{ fontSize: '0.78rem', color: 'var(--muted)', textAlign: 'center' }}>
        Your device will prompt for fingerprint, face, or PIN
      </p>
    </div>
  );
}

// ── ICONS ─────────────────────────────────────────────────────────────────────
function PasskeyIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="8" cy="8" r="4"/>
      <path d="M16 8h6M19 5v6"/>
      <path d="M2 20v-2a4 4 0 0 1 4-4h4"/>
    </svg>
  );
}

function Spinner() {
  return (
    <span style={{
      width: 16, height: 16, border: '2px solid currentColor',
      borderTopColor: 'transparent', borderRadius: '50%',
      display: 'inline-block', animation: 'spin 0.7s linear infinite',
    }} />
  );
}
