'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import api from '@/lib/api';

export default function LiveStats() {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    api.get('/stats').then(r => setStats(r.data)).catch(() => {});
  }, []);

  // Fallback to static numbers if API not yet seeded
  const capital = stats ? `$${Number(stats.totalCapitalDeployed).toLocaleString()}` : '$0';
  const loans   = stats ? stats.totalLoans : 0;
  const investors = stats ? stats.totalInvestors : 0;
  const repaid  = stats ? `$${Number(stats.totalRepaid).toLocaleString()}` : '$0';

  return (
    <div style={{ marginTop: '3rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
        <h2 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Live Platform Stats</h2>
        <Link href="/stats" style={{ fontSize: '0.85rem', color: 'var(--teal)' }}>Full impact report →</Link>
      </div>
      <div className="stats-row">
        {[
          { value: capital,   label: 'Capital Deployed' },
          { value: loans,     label: 'Total Loans' },
          { value: investors, label: 'Active Investors' },
          { value: repaid,    label: 'Repaid to Investors' },
          { value: '$5.2T',   label: 'Global SMB Gap (World Bank)' },
          { value: '$25',     label: 'Min. Investment' },
          { value: '48hrs',   label: 'Decision Speed' },
          { value: '330M',    label: 'SMBs Globally' },
        ].map(s => (
          <div className="stat-card" key={s.label}>
            <div className="stat-value">{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
