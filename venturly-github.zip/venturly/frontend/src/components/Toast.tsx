'use client';
import { useEffect, useState } from 'react';

export type ToastType = 'success' | 'error' | 'info';

interface ToastProps {
  message: string;
  type?: ToastType;
  duration?: number;
  onClose: () => void;
}

export function Toast({ message, type = 'success', duration = 3500, onClose }: ToastProps) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => { setVisible(false); setTimeout(onClose, 300); }, duration);
    return () => clearTimeout(t);
  }, [duration, onClose]);

  const colors: Record<ToastType, { bg: string; border: string; icon: string }> = {
    success: { bg: '#dcfce7', border: '#16a34a', icon: '✓' },
    error:   { bg: '#fee2e2', border: '#dc2626', icon: '✕' },
    info:    { bg: '#dbeafe', border: '#1d4ed8', icon: 'ℹ' },
  };
  const c = colors[type];

  return (
    <div style={{
      position: 'fixed', bottom: '1.5rem', right: '1.5rem', zIndex: 9999,
      background: c.bg, border: `1px solid ${c.border}`, borderRadius: '10px',
      padding: '0.8rem 1.2rem', display: 'flex', alignItems: 'center', gap: '0.7rem',
      boxShadow: '0 4px 20px rgba(0,0,0,0.12)', maxWidth: '360px',
      opacity: visible ? 1 : 0, transform: visible ? 'translateY(0)' : 'translateY(12px)',
      transition: 'opacity 0.3s, transform 0.3s',
    }}>
      <span style={{ fontWeight: 800, color: c.border, fontSize: '1rem' }}>{c.icon}</span>
      <span style={{ fontSize: '0.9rem', flex: 1 }}>{message}</span>
      <button onClick={() => { setVisible(false); setTimeout(onClose, 300); }}
        style={{ background: 'none', border: 'none', cursor: 'pointer', color: c.border, fontSize: '1rem', lineHeight: 1 }}>
        ×
      </button>
    </div>
  );
}

// Simple hook for managing toasts
export function useToast() {
  const [toasts, setToasts] = useState<{ id: number; message: string; type: ToastType }[]>([]);
  let counter = 0;

  const show = (message: string, type: ToastType = 'success') => {
    const id = ++counter;
    setToasts(prev => [...prev, { id, message, type }]);
  };

  const remove = (id: number) => setToasts(prev => prev.filter(t => t.id !== id));

  const ToastContainer = () => (
    <>
      {toasts.map(t => (
        <Toast key={t.id} message={t.message} type={t.type} onClose={() => remove(t.id)} />
      ))}
    </>
  );

  return { show, ToastContainer };
}
