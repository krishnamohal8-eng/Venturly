'use client';
import { useState, useCallback } from 'react';
import { startAuthentication } from '@simplewebauthn/browser';
import api from '@/lib/api';

export interface PaymentContext {
  action: string;   // 'invest'
  amount: number;   // USD
  loanId: string;
  method: string;   // 'google_pay' | 'paypal' | etc.
}

interface ChallengeResult {
  paymentToken: string | undefined;
  requiresPasskey: boolean;
}

/**
 * Hook — call requestPasskeyForPayment() before any payment action.
 * Returns a paymentToken to include in x-payment-token header.
 * If user has no passkeys, returns undefined (payment proceeds without biometric).
 */
export function usePaymentPasskey() {
  const [state, setState] = useState<
    'idle' | 'prompting' | 'verifying' | 'approved' | 'error'
  >('idle');
  const [error, setError] = useState('');

  const requestPasskeyForPayment = useCallback(
    async (context: PaymentContext): Promise<ChallengeResult> => {
      setState('prompting');
      setError('');

      try {
        // Step 1: get challenge from server
        const { data } = await api.post('/passkeys/payment/challenge', context);

        // No passkeys registered — bypass
        if (!data.requiresPasskey) {
          setState('approved');
          return { paymentToken: data.paymentToken, requiresPasskey: false };
        }

        // Step 2: browser prompts biometric
        setState('verifying');
        const authResponse = await startAuthentication({ optionsJSON: data.options });

        // Step 3: verify with server → get payment token
        const { data: result } = await api.post('/passkeys/payment/verify', {
          response: authResponse,
          ...context,
        });

        setState('approved');
        return { paymentToken: result.paymentToken, requiresPasskey: true };

      } catch (e: any) {
        const msg = e?.name === 'NotAllowedError'
          ? 'Biometric cancelled. Payment not authorised.'
          : e?.response?.data?.message || e?.message || 'Biometric verification failed.';
        setState('error');
        setError(msg);
        throw new Error(msg);
      }
    },
    []
  );

  const reset = () => { setState('idle'); setError(''); };

  return { state, error, requestPasskeyForPayment, reset };
}

/**
 * Visual overlay shown while biometric is being verified.
 */
export function PasskeyPaymentOverlay({
  state,
  amount,
  method,
  onCancel,
}: {
  state: 'idle' | 'prompting' | 'verifying' | 'approved' | 'error';
  amount: number;
  method: string;
  onCancel: () => void;
}) {
  if (state === 'idle') return null;

  const METHOD_LABELS: Record<string, string> = {
    google_pay:    'Google Pay',
    apple_pay:     'Apple Pay',
    stripe_card:   'Card',
    paypal:        'PayPal',
    razorpay:      'UPI / Razorpay',
    bank_transfer: 'Bank Transfer',
  };

  const steps = [
    { key: 'prompting', icon: '🔑', label: 'Requesting biometric…' },
    { key: 'verifying', icon: '👆', label: 'Verifying fingerprint / face…' },
    { key: 'approved',  icon: '✅', label: 'Biometric confirmed!' },
    { key: 'error',     icon: '❌', label: 'Verification failed' },
  ];

  const current = steps.find(s => s.key === state) || steps[0];

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 2000, padding: '1rem',
    }}>
      <div style={{
        background: '#fff', borderRadius: '20px', padding: '2.5rem',
        textAlign: 'center', maxWidth: '340px', width: '100%',
        boxShadow: '0 25px 60px rgba(0,0,0,0.3)',
      }}>
        <div style={{ fontSize: '3.5rem', marginBottom: '1rem' }}>{current.icon}</div>

        <div style={{ fontWeight: 800, fontSize: '1.1rem', marginBottom: '0.4rem' }}>
          {state === 'approved' ? 'Payment Authorised' : 'Biometric Required'}
        </div>

        <div style={{ color: 'var(--muted)', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
          {current.label}
        </div>

        {/* Amount + method */}
        <div style={{
          background: 'var(--teal-light)', borderRadius: '10px', padding: '0.8rem',
          marginBottom: '1.5rem', fontSize: '0.9rem',
        }}>
          <div style={{ fontWeight: 700, color: 'var(--teal)', fontSize: '1.3rem' }}>${amount}</div>
          <div style={{ color: 'var(--muted)' }}>via {METHOD_LABELS[method] || method}</div>
        </div>

        {/* Progress dots */}
        {(state === 'prompting' || state === 'verifying') && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: '0.4rem', marginBottom: '1.5rem' }}>
            {[0, 1, 2].map(i => (
              <div key={i} style={{
                width: 8, height: 8, borderRadius: '50%',
                background: 'var(--teal)',
                animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite`,
              }} />
            ))}
          </div>
        )}

        {state === 'approved' && (
          <div style={{ color: 'var(--success)', fontWeight: 600, fontSize: '0.9rem' }}>
            Processing payment…
          </div>
        )}

        {state !== 'approved' && (
          <button onClick={onCancel} style={{
            background: 'none', border: 'none', color: 'var(--muted)',
            cursor: 'pointer', fontSize: '0.85rem', textDecoration: 'underline',
          }}>
            Cancel
          </button>
        )}
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.3; transform: scale(0.8); }
          50% { opacity: 1; transform: scale(1.2); }
        }
      `}</style>
    </div>
  );
}
