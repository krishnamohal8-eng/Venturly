'use client';
import { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import api from '@/lib/api';
import { Toast } from './Toast';
import { usePaymentPasskey, PasskeyPaymentOverlay } from './PaymentPasskeyChallenge';

type PaymentMethod = 'google_pay' | 'apple_pay' | 'stripe_card' | 'paypal' | 'razorpay' | 'bank_transfer';

interface PaymentModalProps {
  loanId: string;
  tokens: number;
  onSuccess: (result: any) => void;
  onClose: () => void;
}

const STRIPE_PK = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || 'pk_test_placeholder';

const PAYMENT_METHODS: { id: PaymentMethod; label: string; icon: string; desc: string; badge?: string }[] = [
  { id: 'google_pay',    label: 'Google Pay',    icon: '🟢', desc: 'Pay with your Google account',         badge: 'Popular' },
  { id: 'apple_pay',     label: 'Apple Pay',     icon: '🍎', desc: 'Touch ID / Face ID on Apple devices',  badge: 'iOS/Mac' },
  { id: 'stripe_card',   label: 'Credit / Debit Card', icon: '💳', desc: 'Visa, Mastercard, Amex, Discover' },
  { id: 'paypal',        label: 'PayPal',        icon: '🅿️', desc: 'Pay with your PayPal balance or card' },
  { id: 'razorpay',      label: 'UPI / Razorpay', icon: '🇮🇳', desc: 'UPI, NetBanking, Wallets (India)',   badge: 'India' },
  { id: 'bank_transfer', label: 'Bank Transfer', icon: '🏦', desc: 'ACH / Wire transfer (1-3 days)' },
];

export default function PaymentModal({ loanId, tokens, onSuccess, onClose }: PaymentModalProps) {
  const [method, setMethod] = useState<PaymentMethod>('google_pay');
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [bankDetails, setBankDetails] = useState<any>(null);
  const [cardForm, setCardForm] = useState({ number: '', expiry: '', cvc: '', name: '' });
  const [paypalClientId, setPaypalClientId] = useState('');
  const [paypalOrderId, setPaypalOrderId] = useState('');
  const { state: passkeyState, error: passkeyError, requestPasskeyForPayment, reset: resetPasskey } = usePaymentPasskey();

  const amount = tokens * 25;

  // Helper: get passkey token then call payment fn with it
  const withPasskey = async (fn: (token: string | undefined) => Promise<void>) => {
    try {
      const { paymentToken } = await requestPasskeyForPayment({
        action: 'invest',
        amount,
        loanId,
        method,
      });
      await fn(paymentToken);
    } catch (e: any) {
      setToast({ msg: e.message || 'Biometric failed.', type: 'error' });
      resetPasskey();
    }
  };

  // ── STRIPE / GOOGLE PAY / APPLE PAY / CARD ────────────────────────────────
  const handleStripePayment = async () => {
    setLoading(true);
    await withPasskey(async (paymentToken) => {
      try {
        const headers = paymentToken ? { 'x-payment-token': paymentToken } : {};
        const { data } = await api.post('/payments/stripe/intent', { loanId, tokens, method }, { headers });

        if (!data.clientSecret.includes('test')) {
          const stripe = await loadStripe(STRIPE_PK);
          if (stripe) {
            const { error } = await stripe.confirmCardPayment(data.clientSecret, {
              payment_method: { card: { token: 'tok_visa' }, billing_details: { name: cardForm.name } },
            });
            if (error) throw new Error(error.message);
          }
        }

        const { data: result } = await api.post('/payments/stripe/confirm', {
          paymentIntentId: data.paymentIntentId, loanId, tokens, method,
        }, { headers });

        onSuccess(result);
      } finally { setLoading(false); }
    });
    setLoading(false);
  };

  // ── GOOGLE PAY ────────────────────────────────────────────────────────────
  const handleGooglePay = async () => {
    setLoading(true);
    await withPasskey(async (paymentToken) => {
      try {
        const headers = paymentToken ? { 'x-payment-token': paymentToken } : {};
        const { data: intentData } = await api.post('/payments/stripe/intent', { loanId, tokens, method: 'google_pay' }, { headers });

        if ((window as any).google?.payments?.api) {
          const client = new (window as any).google.payments.api.PaymentsClient({ environment: intentData.googlePay.environment });
          await client.loadPaymentData({
            apiVersion: 2, apiVersionMinor: 0,
            allowedPaymentMethods: [{
              type: 'CARD',
              parameters: { allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'], allowedCardNetworks: ['VISA', 'MASTERCARD'] },
              tokenizationSpecification: { type: 'PAYMENT_GATEWAY', parameters: { gateway: 'stripe', 'stripe:publishableKey': STRIPE_PK } },
            }],
            merchantInfo: { merchantId: intentData.googlePay.merchantId, merchantName: 'Venturly' },
            transactionInfo: { countryCode: 'US', currencyCode: 'USD', totalPrice: intentData.googlePay.totalPrice, totalPriceStatus: 'FINAL' },
          });
        }

        const { data: result } = await api.post('/payments/stripe/confirm', {
          paymentIntentId: intentData.paymentIntentId, loanId, tokens, method: 'google_pay',
        }, { headers });
        onSuccess(result);
      } catch (e: any) {
        if (e?.statusCode !== 'CANCELED') throw e;
      } finally { setLoading(false); }
    });
    setLoading(false);
  };

  // ── PAYPAL ────────────────────────────────────────────────────────────────
  const initPayPal = async () => {
    setLoading(true);
    try {
      const { data } = await api.post('/payments/paypal/order', { loanId, tokens });
      setPaypalClientId(data.clientId);
      setPaypalOrderId(data.orderId);
    } catch (e: any) {
      setToast({ msg: e?.response?.data?.message || 'PayPal init failed.', type: 'error' });
    } finally { setLoading(false); }
  };

  useEffect(() => { if (method === 'paypal') initPayPal(); }, [method]);

  // ── RAZORPAY ──────────────────────────────────────────────────────────────
  const handleRazorpay = async () => {
    setLoading(true);
    await withPasskey(async (paymentToken) => {
      try {
        const headers = paymentToken ? { 'x-payment-token': paymentToken } : {};
        const { data } = await api.post('/payments/razorpay/order', { loanId, tokens }, { headers });

        if ((window as any).Razorpay) {
          const rzp = new (window as any).Razorpay({
            key: data.keyId, amount: data.amountInr, currency: data.currency,
            name: data.name, description: data.description, order_id: data.orderId, theme: data.theme,
            handler: async (response: any) => {
              const { data: result } = await api.post('/payments/razorpay/verify', {
                loanId, tokens,
                razorpayOrderId: response.razorpay_order_id,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpaySignature: response.razorpay_signature,
              }, { headers });
              onSuccess(result);
            },
          });
          rzp.open();
        } else {
          const { data: result } = await api.post('/payments/razorpay/verify', {
            loanId, tokens,
            razorpayOrderId: data.orderId,
            razorpayPaymentId: `pay_test_${Date.now()}`,
            razorpaySignature: 'test_signature',
          }, { headers });
          onSuccess(result);
        }
      } finally { setLoading(false); }
    });
    setLoading(false);
  };

  // ── BANK TRANSFER ─────────────────────────────────────────────────────────
  const handleBankTransfer = async () => {
    setLoading(true);
    await withPasskey(async (paymentToken) => {
      try {
        const headers = paymentToken ? { 'x-payment-token': paymentToken } : {};
        const { data } = await api.post('/payments/bank-transfer/initiate', { loanId, tokens }, { headers });
        setBankDetails(data);
      } finally { setLoading(false); }
    });
    setLoading(false);
  };

  const handlePay = () => {
    if (method === 'google_pay')    return handleGooglePay();
    if (method === 'apple_pay')     return handleStripePayment();
    if (method === 'stripe_card')   return handleStripePayment();
    if (method === 'razorpay')      return handleRazorpay();
    if (method === 'bank_transfer') return handleBankTransfer();
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 1000, padding: '1rem',
    }}>
      <div style={{
        background: '#fff', borderRadius: '16px', width: '100%', maxWidth: '480px',
        maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
      }}>
        {/* Header */}
        <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontWeight: 800, fontSize: '1.1rem' }}>Complete Investment</div>
            <div style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>{tokens} token{tokens !== 1 ? 's' : ''} × $25 = <strong>${amount}</strong></div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: '1.4rem', cursor: 'pointer', color: 'var(--muted)' }}>×</button>
        </div>

        <div style={{ padding: '1.5rem' }}>
          {/* Payment method selector */}
          <div style={{ marginBottom: '1.2rem' }}>
            <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--muted)', marginBottom: '0.6rem' }}>SELECT PAYMENT METHOD</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
              {PAYMENT_METHODS.map(pm => (
                <button
                  key={pm.id}
                  onClick={() => setMethod(pm.id)}
                  style={{
                    padding: '0.7rem', borderRadius: '10px', cursor: 'pointer', textAlign: 'left',
                    border: `2px solid ${method === pm.id ? 'var(--teal)' : 'var(--border)'}`,
                    background: method === pm.id ? 'var(--teal-light)' : '#fff',
                    transition: 'all 0.15s', position: 'relative',
                  }}
                >
                  {pm.badge && (
                    <span style={{ position: 'absolute', top: '0.3rem', right: '0.3rem', fontSize: '0.6rem', background: 'var(--teal)', color: '#fff', padding: '0.1rem 0.4rem', borderRadius: '999px', fontWeight: 700 }}>
                      {pm.badge}
                    </span>
                  )}
                  <div style={{ fontSize: '1.2rem', marginBottom: '0.2rem' }}>{pm.icon}</div>
                  <div style={{ fontWeight: 700, fontSize: '0.82rem' }}>{pm.label}</div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--muted)', marginTop: '0.1rem' }}>{pm.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Card form for stripe_card */}
          {method === 'stripe_card' && (
            <div style={{ marginBottom: '1rem', display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              <input placeholder="Cardholder name" value={cardForm.name} onChange={e => setCardForm({ ...cardForm, name: e.target.value })}
                style={{ padding: '0.65rem 0.9rem', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '0.9rem' }} />
              <input placeholder="Card number" value={cardForm.number} onChange={e => setCardForm({ ...cardForm, number: e.target.value })}
                style={{ padding: '0.65rem 0.9rem', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '0.9rem' }} />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                <input placeholder="MM/YY" value={cardForm.expiry} onChange={e => setCardForm({ ...cardForm, expiry: e.target.value })}
                  style={{ padding: '0.65rem 0.9rem', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '0.9rem' }} />
                <input placeholder="CVC" value={cardForm.cvc} onChange={e => setCardForm({ ...cardForm, cvc: e.target.value })}
                  style={{ padding: '0.65rem 0.9rem', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '0.9rem' }} />
              </div>
            </div>
          )}

          {/* PayPal buttons */}
          {method === 'paypal' && paypalClientId && (
            <div style={{ marginBottom: '1rem' }}>
              <PayPalScriptProvider options={{ clientId: paypalClientId, currency: 'USD' }}>
                <PayPalButtons
                  style={{ layout: 'vertical', color: 'blue', shape: 'rect', label: 'pay' }}
                  createOrder={() => Promise.resolve(paypalOrderId)}
                  onApprove={async (data) => {
                    const { data: result } = await api.post('/payments/paypal/capture', {
                      orderId: data.orderID, loanId, tokens,
                    });
                    onSuccess(result);
                  }}
                  onError={() => setToast({ msg: 'PayPal payment failed.', type: 'error' })}
                />
              </PayPalScriptProvider>
            </div>
          )}

          {/* Bank transfer details */}
          {method === 'bank_transfer' && bankDetails && (
            <div style={{ marginBottom: '1rem', background: '#f9fafb', borderRadius: '10px', padding: '1rem', fontSize: '0.85rem' }}>
              <div style={{ fontWeight: 700, marginBottom: '0.6rem' }}>Bank Transfer Instructions</div>
              {Object.entries(bankDetails.instructions).map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.3rem 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ color: 'var(--muted)', textTransform: 'capitalize' }}>{k.replace(/([A-Z])/g, ' $1')}</span>
                  <strong>{String(v)}</strong>
                </div>
              ))}
              <div style={{ marginTop: '0.6rem', color: 'var(--muted)', fontSize: '0.78rem' }}>
                ⏱ {bankDetails.estimatedSettlement}
              </div>
            </div>
          )}

          {/* Pay button */}
          {method !== 'paypal' && (
            <button
              onClick={handlePay}
              disabled={loading}
              className="btn btn-primary"
              style={{ width: '100%', padding: '0.85rem', fontSize: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}
            >
              {loading ? (
                <><Spinner /> Processing…</>
              ) : (
                <>{PAYMENT_METHODS.find(p => p.id === method)?.icon} Pay ${amount} with {PAYMENT_METHODS.find(p => p.id === method)?.label}</>
              )}
            </button>
          )}

          {/* Security badges */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', marginTop: '1rem', fontSize: '0.75rem', color: 'var(--muted)' }}>
            <span>🔒 256-bit SSL</span>
            <span>🛡️ PCI DSS Compliant</span>
            <span>✓ Funds in Escrow</span>
          </div>
        </div>
      </div>

      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}

      <PasskeyPaymentOverlay
        state={passkeyState}
        amount={amount}
        method={method}
        onCancel={() => { resetPasskey(); setLoading(false); }}
      />
    </div>
  );
}

function Spinner() {
  return (
    <span style={{ width: 18, height: 18, border: '2px solid #fff', borderTopColor: 'transparent', borderRadius: '50%', display: 'inline-block', animation: 'spin 0.7s linear infinite' }} />
  );
}
