'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { getUser, clearAuth, AuthUser } from '@/lib/auth';
import NotificationBell from './NotificationBell';

export default function Navbar() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const router = useRouter();

  useEffect(() => { setUser(getUser()); }, []);

  const logout = () => {
    clearAuth();
    setUser(null);
    router.push('/');
  };

  return (
    <nav>
      <div className="container nav-inner">
        <Link href="/" className="nav-logo">Venturly</Link>

        {/* Desktop nav */}
        <div className="nav-links nav-desktop">
          <Link href="/marketplace">Marketplace</Link>
          <Link href="/calculator">Calculator</Link>
          <Link href="/stats">Impact</Link>
          <Link href="/api-docs">API</Link>
          {!user ? (
            <>
              <Link href="/login">Login</Link>
              <Link href="/register" className="btn btn-primary btn-sm">Get Started</Link>
            </>
          ) : (
            <>
              {user.role === 'borrower' && <Link href="/dashboard/borrower">My Loans</Link>}
              {user.role === 'investor' && <Link href="/dashboard/investor">Portfolio</Link>}
              <Link href="/admin" style={{ color: 'var(--muted)', fontSize: '0.9rem' }}>Admin</Link>
              <NotificationBell />
              <a href="/profile" style={{ color: 'var(--muted)', fontSize: '0.9rem' }}>
                <span style={{
                  width: 30, height: 30, borderRadius: '50%', background: 'var(--teal)',
                  color: '#fff', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  fontWeight: 800, fontSize: '0.85rem',
                }}>
                  {user.name.charAt(0).toUpperCase()}
                </span>
              </a>
              <button className="btn btn-outline btn-sm" onClick={logout}>Logout</button>
            </>
          )}
        </div>

        {/* Mobile hamburger */}
        <button
          className="nav-hamburger"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Menu"
          style={{ display: 'none', background: 'none', border: 'none', cursor: 'pointer', padding: '0.3rem' }}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {menuOpen
              ? <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>
              : <><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></>
            }
          </svg>
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{ background: '#fff', borderTop: '1px solid var(--border)', padding: '1rem' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
            <Link href="/marketplace" onClick={() => setMenuOpen(false)}>Marketplace</Link>
            <Link href="/stats" onClick={() => setMenuOpen(false)}>Impact</Link>
            <Link href="/api-docs" onClick={() => setMenuOpen(false)}>API</Link>
            {!user ? (
              <>
                <Link href="/login" onClick={() => setMenuOpen(false)}>Login</Link>
                <Link href="/register" className="btn btn-primary" onClick={() => setMenuOpen(false)}>Get Started</Link>
              </>
            ) : (
              <>
                {user.role === 'borrower' && <Link href="/dashboard/borrower" onClick={() => setMenuOpen(false)}>My Loans</Link>}
                {user.role === 'investor' && <Link href="/dashboard/investor" onClick={() => setMenuOpen(false)}>Portfolio</Link>}
                <Link href="/profile" onClick={() => setMenuOpen(false)}>Profile</Link>
                <button className="btn btn-outline" onClick={() => { logout(); setMenuOpen(false); }}>Logout</button>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
