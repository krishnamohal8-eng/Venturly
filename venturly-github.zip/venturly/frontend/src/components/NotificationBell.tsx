'use client';
import { useEffect, useState, useRef } from 'react';
import api from '@/lib/api';
import { getUser } from '@/lib/auth';

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  loanId?: string;
  read: boolean;
  createdAt: string;
}

const TYPE_ICONS: Record<string, string> = {
  LOAN_FUNDED:        '🎉',
  REPAYMENT_RECEIVED: '💰',
  LOAN_COMPLETED:     '✅',
  LOAN_LATE:          '⚠️',
  RISK_ALERT:         '🚨',
  INVESTMENT_MADE:    '📈',
};

export default function NotificationBell() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const user = getUser();

  useEffect(() => {
    if (!user) return;
    fetchUnreadCount();
    // Poll every 30 seconds
    const interval = setInterval(fetchUnreadCount, 30000);
    return () => clearInterval(interval);
  }, []);

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const fetchUnreadCount = async () => {
    try {
      const { data } = await api.get('/notifications/unread/count');
      setUnread(data.count);
    } catch { /* ignore */ }
  };

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/notifications');
      setNotifications(data);
      setUnread(0);
      // Mark all read
      await api.patch('/notifications/read/all');
    } catch { /* ignore */ }
    finally { setLoading(false); }
  };

  const toggle = () => {
    if (!open) fetchNotifications();
    setOpen(!open);
  };

  if (!user) return null;

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      {/* Bell button */}
      <button
        onClick={toggle}
        style={{
          background: 'none', border: 'none', cursor: 'pointer',
          position: 'relative', padding: '0.3rem', display: 'flex', alignItems: 'center',
        }}
        aria-label="Notifications"
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--muted)' }}>
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        {unread > 0 && (
          <span style={{
            position: 'absolute', top: 0, right: 0,
            background: 'var(--danger)', color: '#fff',
            borderRadius: '999px', fontSize: '0.65rem', fontWeight: 800,
            minWidth: '16px', height: '16px', display: 'flex',
            alignItems: 'center', justifyContent: 'center', padding: '0 3px',
          }}>
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>

      {/* Dropdown */}
      {open && (
        <div style={{
          position: 'absolute', right: 0, top: '110%',
          width: '340px', maxHeight: '420px', overflowY: 'auto',
          background: '#fff', border: '1px solid var(--border)',
          borderRadius: '12px', boxShadow: '0 8px 30px rgba(0,0,0,0.12)',
          zIndex: 500,
        }}>
          <div style={{ padding: '0.8rem 1rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 700, fontSize: '0.9rem' }}>Notifications</span>
            {notifications.length > 0 && (
              <button
                onClick={() => { api.patch('/notifications/read/all'); setNotifications(n => n.map(x => ({ ...x, read: true }))); }}
                style={{ background: 'none', border: 'none', color: 'var(--teal)', fontSize: '0.78rem', cursor: 'pointer', fontWeight: 600 }}
              >
                Mark all read
              </button>
            )}
          </div>

          {loading ? (
            <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--muted)', fontSize: '0.85rem' }}>Loading…</div>
          ) : notifications.length === 0 ? (
            <div style={{ padding: '2rem', textAlign: 'center' }}>
              <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>🔔</div>
              <div style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>No notifications yet</div>
            </div>
          ) : (
            notifications.map(n => (
              <div
                key={n.id}
                onClick={() => {
                  if (n.loanId) window.location.href = `/loans/${n.loanId}`;
                  api.patch(`/notifications/${n.id}/read`).catch(() => {});
                }}
                style={{
                  padding: '0.8rem 1rem', borderBottom: '1px solid var(--border)',
                  cursor: n.loanId ? 'pointer' : 'default',
                  background: n.read ? '#fff' : 'var(--teal-light)',
                  transition: 'background 0.15s',
                  display: 'flex', gap: '0.7rem', alignItems: 'flex-start',
                }}
              >
                <span style={{ fontSize: '1.2rem', flexShrink: 0 }}>
                  {TYPE_ICONS[n.type] || '🔔'}
                </span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: n.read ? 500 : 700, fontSize: '0.85rem', marginBottom: '0.15rem' }}>
                    {n.title}
                  </div>
                  <div style={{ fontSize: '0.78rem', color: 'var(--muted)', lineHeight: 1.4 }}>
                    {n.message}
                  </div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--muted)', marginTop: '0.2rem' }}>
                    {new Date(n.createdAt).toLocaleString()}
                  </div>
                </div>
                {!n.read && (
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--teal)', flexShrink: 0, marginTop: '0.3rem' }} />
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
