import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { StatsService } from './stats.service';

@ApiTags('Stats')
@Controller('stats')
export class StatsController {
  constructor(private statsService: StatsService) {}

  @Get()
  @ApiOperation({
    summary: 'Platform impact stats',
    description: `Returns live platform-wide metrics. Public endpoint — no auth required.\n\n` +
      `Used to power the homepage live stats and the /stats impact dashboard.`,
  })
  @ApiResponse({
    status: 200,
    description: 'Platform stats object.',
    schema: {
      example: {
        totalLoans: 12,
        listedLoans: 8,
        fundedLoans: 3,
        completedLoans: 1,
        totalBorrowers: 9,
        totalInvestors: 5,
        totalInvestments: 24,
        totalCapitalDeployed: 45000,
        totalRepaid: 12500,
        paidInstallments: 18,
        gradeDistribution: { A: 2, B: 5, C: 4, D: 1 },
      },
    },
  })
  getPlatformStats() {
    return this.statsService.getPlatformStats();
  }
}
