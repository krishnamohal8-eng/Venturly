import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Loan } from '../loans/loan.entity';
import { Investment } from '../investments/investment.entity';
import { User } from '../users/user.entity';
import { Repayment } from '../repayments/repayment.entity';

@Injectable()
export class StatsService {
  constructor(
    @InjectRepository(Loan)       private loanRepo: Repository<Loan>,
    @InjectRepository(Investment) private invRepo: Repository<Investment>,
    @InjectRepository(User)       private userRepo: Repository<User>,
    @InjectRepository(Repayment)  private repayRepo: Repository<Repayment>,
  ) {}

  async getPlatformStats() {
    const [
      totalLoans,
      listedLoans,
      fundedLoans,
      completedLoans,
      totalBorrowers,
      totalInvestors,
      totalInvestments,
      paidRepayments,
    ] = await Promise.all([
      this.loanRepo.count(),
      this.loanRepo.count({ where: { status: 'listed' } }),
      this.loanRepo.count({ where: { status: 'funded' } }),
      this.loanRepo.count({ where: { status: 'completed' } }),
      this.userRepo.count({ where: { role: 'borrower' } }),
      this.userRepo.count({ where: { role: 'investor' } }),
      this.invRepo.count(),
      this.repayRepo.count({ where: { status: 'paid' } }),
    ]);

    const fundedLoansData = await this.loanRepo
      .createQueryBuilder('l')
      .where('l.status IN (:...statuses)', { statuses: ['funded', 'repaying', 'completed'] })
      .getMany();
    const totalCapitalDeployed = fundedLoansData.reduce((s, l) => s + Number(l.amount), 0);

    const paidData = await this.repayRepo.find({ where: { status: 'paid' } });
    const totalRepaid = paidData.reduce((s, r) => s + Number(r.paidAmount), 0);

    const allLoans = await this.loanRepo.find();
    const gradeDistribution = allLoans.reduce((acc: Record<string, number>, l) => {
      if (l.riskGrade) acc[l.riskGrade] = (acc[l.riskGrade] || 0) + 1;
      return acc;
    }, {});

    return {
      totalLoans, listedLoans, fundedLoans, completedLoans,
      totalBorrowers, totalInvestors, totalInvestments,
      totalCapitalDeployed, totalRepaid,
      paidInstallments: paidRepayments,
      gradeDistribution,
    };
  }
}
