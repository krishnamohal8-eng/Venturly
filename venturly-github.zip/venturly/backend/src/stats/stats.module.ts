import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Loan } from '../loans/loan.entity';
import { Investment } from '../investments/investment.entity';
import { User } from '../users/user.entity';
import { Repayment } from '../repayments/repayment.entity';
import { StatsController } from './stats.controller';
import { StatsService } from './stats.service';

@Module({
  imports: [TypeOrmModule.forFeature([Loan, Investment, User, Repayment])],
  providers: [StatsService],
  controllers: [StatsController],
})
export class StatsModule {}
