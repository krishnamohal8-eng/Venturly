import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuditLog, AuditAction } from './audit.entity';
import * as crypto from 'crypto';

@Injectable()
export class AuditService {
  constructor(@InjectRepository(AuditLog) private repo: Repository<AuditLog>) {}

  async log(action: AuditAction, opts: {
    loanId?: string;
    userId?: string;
    amount?: number;
    metadata?: Record<string, any>;
  }) {
    const last = await this.repo.findOne({ order: { createdAt: 'DESC' }, where: {} });
    const previousHash = last?.hash ?? '0000000000000000';

    const payload = JSON.stringify({ action, ...opts, previousHash, ts: Date.now() });
    const hash = crypto.createHash('sha256').update(payload).digest('hex').slice(0, 16);

    const entry = this.repo.create({
      action,
      loanId: opts.loanId,
      userId: opts.userId,
      amount: opts.amount,
      metadataRaw: opts.metadata ? JSON.stringify(opts.metadata) : null,
      previousHash,
      hash,
    });
    return this.repo.save(entry);
  }

  async findAll(loanId?: string) {
    const rows = loanId
      ? await this.repo.find({ where: { loanId }, order: { createdAt: 'DESC' } })
      : await this.repo.find({ order: { createdAt: 'DESC' }, take: 100 });

    // Parse metadataRaw back to object for the API response
    return rows.map(r => ({
      ...r,
      metadata: r.metadataRaw ? JSON.parse(r.metadataRaw) : null,
    }));
  }
}
