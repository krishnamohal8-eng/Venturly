import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { AuditService } from './audit.service';

@ApiTags('Audit')
@Controller('audit')
@UseGuards(AuthGuard('jwt'))
@ApiBearerAuth('JWT')
export class AuditController {
  constructor(private auditService: AuditService) {}

  @Get()
  @ApiOperation({
    summary: 'Get audit log',
    description: `Returns the immutable hash-chained audit ledger.\n\n` +
      `Every money movement on the platform is logged here with a SHA-256 hash linking each entry to the previous one — simulating a Hyperledger-style immutable trail.\n\n` +
      `**Actions logged:**\n` +
      `- \`LOAN_LISTED\` — loan approved and listed on marketplace\n` +
      `- \`INVESTMENT_MADE\` — investor purchased tokens\n` +
      `- \`LOAN_FUNDED\` — loan reached 100% funding, schedule generated\n` +
      `- \`REPAYMENT_PAID\` — installment paid and distributed to investors\n` +
      `- \`REPAYMENT_LATE\` — dunning sequence triggered for overdue installment\n` +
      `- \`RISK_ALERT\` — AI risk trigger fired for low bank balance`,
  })
  @ApiQuery({ name: 'loanId', required: false, description: 'Filter by loan UUID. Omit to get the last 100 platform-wide entries.' })
  @ApiResponse({
    status: 200,
    description: 'Array of audit log entries ordered newest-first.',
    schema: {
      example: [{
        id: 'uuid',
        action: 'REPAYMENT_PAID',
        loanId: 'uuid',
        userId: null,
        amount: 85.29,
        metadata: { installmentNumber: 1, investorsDistributed: 2 },
        previousHash: '7d5987f7a5e4',
        hash: '965db4e837e2',
        createdAt: '2026-04-04T18:25:00.000Z',
      }],
    },
  })
  findAll(@Query('loanId') loanId?: string) {
    return this.auditService.findAll(loanId);
  }
}
