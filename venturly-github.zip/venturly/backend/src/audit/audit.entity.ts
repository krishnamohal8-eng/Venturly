import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

export enum AuditAction {
  LOAN_APPLIED    = 'LOAN_APPLIED',
  LOAN_LISTED     = 'LOAN_LISTED',
  LOAN_FUNDED     = 'LOAN_FUNDED',
  INVESTMENT_MADE = 'INVESTMENT_MADE',
  REPAYMENT_PAID  = 'REPAYMENT_PAID',
  REPAYMENT_LATE  = 'REPAYMENT_LATE',
  RISK_ALERT      = 'RISK_ALERT',
}

@Entity()
export class AuditLog {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // varchar instead of enum — SQLite compatible
  @Column({ type: 'varchar' })
  action: string;

  @Column({ nullable: true })
  loanId: string;

  @Column({ nullable: true })
  userId: string;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  amount: number;

  // text instead of jsonb — SQLite compatible (store as JSON string)
  @Column({ type: 'text', nullable: true })
  metadataRaw: string;

  @Column({ nullable: true })
  previousHash: string;

  @Column()
  hash: string;

  @CreateDateColumn()
  createdAt: Date;

  // Virtual getter/setter so the rest of the code still uses .metadata
  get metadata(): Record<string, any> {
    return this.metadataRaw ? JSON.parse(this.metadataRaw) : null;
  }
  set metadata(val: Record<string, any>) {
    this.metadataRaw = val ? JSON.stringify(val) : null;
  }
}
