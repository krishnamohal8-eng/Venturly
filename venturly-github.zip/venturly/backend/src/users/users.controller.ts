import { Controller, Get, Patch, Body, UseGuards, Request, Headers } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody, ApiHeader } from '@nestjs/swagger';
import { ApiProperty } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { IsOptional, IsString, MinLength } from 'class-validator';
import { UsersService } from './users.service';
import { PasskeysService } from '../passkeys/passkeys.service';

export class UpdateProfileDto {
  @ApiProperty({ example: 'Maya Patel', required: false })
  @IsOptional() @IsString() name?: string;

  @ApiProperty({ example: 'newpassword123', required: false, minLength: 6 })
  @IsOptional() @IsString() @MinLength(6) newPassword?: string;
}

@ApiTags('Users')
@Controller('users')
@UseGuards(AuthGuard('jwt'))
@ApiBearerAuth('JWT')
export class UsersController {
  constructor(
    private usersService: UsersService,
    private passkeysService: PasskeysService,
  ) {}

  @Get('me')
  @ApiOperation({ summary: 'Get current user profile' })
  @ApiResponse({ status: 200, description: 'User profile (no sensitive fields).' })
  getMe(@Request() req) {
    return this.usersService.findById(req.user.id);
  }

  @Patch('me')
  @ApiHeader({ name: 'x-payment-token', description: 'Passkey token required when changing password', required: false })
  @ApiOperation({
    summary: 'Update profile',
    description:
      'Update display name and/or password.\n\n' +
      'If changing password and user has passkeys registered, ' +
      'a passkey token (`x-payment-token`) from `POST /passkeys/payment/challenge` is required.',
  })
  @ApiBody({ type: UpdateProfileDto })
  @ApiResponse({ status: 200, description: 'Updated user profile.' })
  async updateMe(
    @Request() req,
    @Body() dto: UpdateProfileDto,
    @Headers('x-payment-token') paymentToken?: string,
  ) {
    // Password change requires passkey verification if user has passkeys
    if (dto.newPassword) {
      const passkeys = await this.passkeysService.listPasskeys(req.user.id);
      if (passkeys.length > 0) {
        if (!paymentToken) {
          // Return challenge instead of error — frontend can handle this
          const challenge = await this.passkeysService.getPaymentChallengeOptions(req.user.id, {
            action: 'change_password',
            amount: 0,
            loanId: 'profile',
            method: 'profile_update',
          });
          return { requiresPasskey: true, challenge };
        }
        this.passkeysService.verifyPaymentToken(paymentToken, req.user.id, 'profile');
      }
    }
    return this.usersService.updateProfile(req.user.id, dto);
  }

  @Get('admin/users')
  @ApiOperation({
    summary: 'Admin: list all users',
    description: 'Returns all borrowers and investors. In production, restrict to admin role.',
  })
  @ApiResponse({ status: 200, description: 'All users grouped by role.' })
  getAdminStats() {
    return this.usersService.getAdminStats();
  }
}
