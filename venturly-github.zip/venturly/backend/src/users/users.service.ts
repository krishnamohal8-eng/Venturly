import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './user.entity';
import * as bcrypt from 'bcryptjs';

@Injectable()
export class UsersService {
  constructor(@InjectRepository(User) private repo: Repository<User>) {}

  findByEmail(email: string) {
    return this.repo.findOne({ where: { email } });
  }

  findById(id: string) {
    return this.repo.findOne({ where: { id } });
  }

  create(data: Partial<User>) {
    const user = this.repo.create(data);
    return this.repo.save(user);
  }

  async updateProfile(id: string, data: { name?: string; newPassword?: string }) {
    const user = await this.repo.findOne({ where: { id } });
    if (!user) return null;
    if (data.name) user.name = data.name;
    if (data.newPassword) user.passwordHash = await bcrypt.hash(data.newPassword, 10);
    return this.repo.save(user);
  }

  async getAdminStats() {
    const [borrowers, investors] = await Promise.all([
      this.repo.find({ where: { role: 'borrower' }, select: ['id', 'name', 'email', 'kycVerified', 'createdAt'] }),
      this.repo.find({ where: { role: 'investor' }, select: ['id', 'name', 'email', 'kycVerified', 'createdAt'] }),
    ]);
    return {
      totalUsers: borrowers.length + investors.length,
      borrowers,
      investors,
    };
  }
}
