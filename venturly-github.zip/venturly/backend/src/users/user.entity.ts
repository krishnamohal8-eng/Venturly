import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';
import { Exclude } from 'class-transformer';

export enum UserRole {
  BORROWER = 'borrower',
  INVESTOR = 'investor',
}

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  email: string;

  // Never serialised in API responses
  @Exclude()
  @Column()
  passwordHash: string;

  @Column()
  name: string;

  @Column({ type: 'varchar', default: 'borrower' })
  role: string;

  @Column({ default: false })
  kycVerified: boolean;

  @Exclude()
  @Column({ nullable: true })
  plaidAccessToken: string;

  @Column({ nullable: true })
  phone: string;

  @CreateDateColumn()
  createdAt: Date;
}
