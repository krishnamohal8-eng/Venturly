import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { Passkey } from './passkey.entity';
import { User } from '../users/user.entity';
import { PasskeysService } from './passkeys.service';
import { PasskeysController } from './passkeys.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([Passkey, User]),
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'venturly_secret',
      signOptions: { expiresIn: '7d' },
    }),
  ],
  providers: [PasskeysService],
  controllers: [PasskeysController],
  exports: [PasskeysService],
})
export class PasskeysModule {}
