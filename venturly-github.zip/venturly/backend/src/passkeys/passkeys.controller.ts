import { Controller, Post, Get, Delete, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody, ApiParam } from '@nestjs/swagger';
import { ApiProperty } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { IsEmail, IsNumber, IsOptional, IsString, Min } from 'class-validator';
import { PasskeysService } from './passkeys.service';

class StartAuthDto {
  @ApiProperty({ example: 'maya@demo.com' })
  @IsEmail() email: string;
}

class VerifyAuthDto {
  @ApiProperty({ description: 'User ID returned from start-authentication' })
  @IsString() userId: string;

  @ApiProperty({ description: 'WebAuthn authentication response from the browser' })
  response: any;
}

class VerifyRegistrationDto {
  @ApiProperty({ description: 'WebAuthn registration response from the browser' })
  response: any;

  @ApiProperty({ example: 'MacBook Touch ID', required: false })
  @IsOptional() @IsString() deviceName?: string;
}

class PaymentChallengeDto {
  @ApiProperty({ example: 'invest', description: 'Payment action being authorised' })
  @IsString() action: string;

  @ApiProperty({ example: 100 })
  @IsNumber() @Min(1) amount: number;

  @ApiProperty({ example: 'uuid-of-loan' })
  @IsString() loanId: string;

  @ApiProperty({ example: 'google_pay', description: 'Payment method being used' })
  @IsString() method: string;
}

class VerifyPaymentChallengeDto {
  @ApiProperty({ description: 'WebAuthn response from the browser biometric prompt' })
  response: any;

  @ApiProperty({ example: 'invest' })
  @IsString() action: string;

  @ApiProperty({ example: 100 })
  @IsNumber() @Min(1) amount: number;

  @ApiProperty({ example: 'uuid-of-loan' })
  @IsString() loanId: string;

  @ApiProperty({ example: 'google_pay' })
  @IsString() method: string;
}

@ApiTags('Passkeys')
@Controller('passkeys')
export class PasskeysController {
  constructor(private passkeysService: PasskeysService) {}

  // ── REGISTRATION (requires existing JWT login first) ──────────────────────

  @Get('register/options')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiOperation({
    summary: 'Get passkey registration options',
    description:
      'Step 1 of passkey registration. Returns WebAuthn options to pass to ' +
      '`startRegistration()` from `@simplewebauthn/browser`. ' +
      'User must be logged in with password first to add a passkey.',
  })
  @ApiResponse({ status: 200, description: 'WebAuthn PublicKeyCredentialCreationOptions' })
  getRegistrationOptions(@Request() req) {
    return this.passkeysService.getRegistrationOptions(req.user.id);
  }

  @Post('register/verify')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiOperation({
    summary: 'Verify passkey registration',
    description:
      'Step 2 of passkey registration. Pass the response from `startRegistration()` here. ' +
      'Saves the passkey credential to the database.',
  })
  @ApiBody({ type: VerifyRegistrationDto })
  @ApiResponse({ status: 201, description: '{ verified: true, deviceName: "..." }' })
  verifyRegistration(@Request() req, @Body() dto: VerifyRegistrationDto) {
    return this.passkeysService.verifyRegistration(req.user.id, dto.response, dto.deviceName);
  }

  // ── AUTHENTICATION (no JWT needed — this IS the login) ────────────────────

  @Post('authenticate/options')
  @ApiOperation({
    summary: 'Get passkey authentication options',
    description:
      'Step 1 of passwordless login. Provide email to get WebAuthn challenge. ' +
      'Pass the returned `options` to `startAuthentication()` from `@simplewebauthn/browser`. ' +
      'Also returns `userId` needed for the verify step.',
  })
  @ApiBody({ type: StartAuthDto })
  @ApiResponse({ status: 200, description: '{ options: WebAuthnOptions, userId: string }' })
  getAuthOptions(@Body() dto: StartAuthDto) {
    return this.passkeysService.getAuthenticationOptions(dto.email);
  }

  @Post('authenticate/verify')
  @ApiOperation({
    summary: 'Verify passkey and login',
    description:
      'Step 2 of passwordless login. Pass the response from `startAuthentication()` here. ' +
      'Returns a JWT token on success — same format as `POST /auth/login`.',
  })
  @ApiBody({ type: VerifyAuthDto })
  @ApiResponse({ status: 201, description: '{ token, user } — same as /auth/login response' })
  @ApiResponse({ status: 401, description: 'Passkey verification failed' })
  verifyAuth(@Body() dto: VerifyAuthDto) {
    return this.passkeysService.verifyAuthentication(dto.userId, dto.response);
  }

  // ── MANAGEMENT ────────────────────────────────────────────────────────────

  @Get()
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'List my passkeys', description: 'Returns all registered passkeys for the authenticated user.' })
  @ApiResponse({ status: 200, description: 'Array of passkey objects (no private key data).' })
  listPasskeys(@Request() req) {
    return this.passkeysService.listPasskeys(req.user.id);
  }

  @Delete(':id')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Delete a passkey', description: 'Removes a registered passkey by ID.' })
  @ApiParam({ name: 'id', description: 'Passkey UUID' })
  @ApiResponse({ status: 200, description: '{ deleted: true }' })
  deletePasskey(@Request() req, @Param('id') id: string) {
    return this.passkeysService.deletePasskey(req.user.id, id);
  }

  // ── PAYMENT PASSKEY CHALLENGE ─────────────────────────────────────────────

  @Post('payment/challenge')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiOperation({
    summary: 'Get biometric challenge for payment',
    description:
      '**Step 1 of passkey-secured payment.** Called before any payment action.\n\n' +
      'Returns a WebAuthn challenge to pass to `startAuthentication()` in the browser.\n\n' +
      'If the user has no passkeys registered, returns `{ requiresPasskey: false, paymentToken }` ' +
      'so payment can proceed without biometrics.\n\n' +
      '**Used by:** Google Pay, Apple Pay, Stripe Card, PayPal, Razorpay, Bank Transfer.',
  })
  @ApiBody({ type: PaymentChallengeDto })
  @ApiResponse({
    status: 201,
    description: 'Challenge options or bypass token.',
    schema: {
      example: {
        requiresPasskey: true,
        options: { challenge: 'base64url...', allowCredentials: [] },
        userId: 'uuid',
        context: { action: 'invest', amount: 100, loanId: 'uuid', method: 'google_pay' },
      },
    },
  })
  getPaymentChallenge(@Request() req, @Body() dto: PaymentChallengeDto) {
    return this.passkeysService.getPaymentChallengeOptions(req.user.id, dto);
  }

  @Post('payment/verify')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiOperation({
    summary: 'Verify biometric and get payment token',
    description:
      '**Step 2 of passkey-secured payment.** Pass the WebAuthn response from the browser.\n\n' +
      'On success returns a `paymentToken` (JWT, valid 5 minutes) that must be included ' +
      'in the `x-payment-token` header of the actual payment request.\n\n' +
      'This token binds the biometric confirmation to a specific loan, amount, and method — ' +
      'preventing token reuse across different payments.',
  })
  @ApiBody({ type: VerifyPaymentChallengeDto })
  @ApiResponse({
    status: 201,
    description: 'Biometric verified. Returns paymentToken.',
    schema: {
      example: {
        verified: true,
        paymentToken: 'eyJhbGciOiJIUzI1NiJ9...',
        message: 'Biometric confirmed. Payment authorised for 5 minutes.',
      },
    },
  })
  verifyPaymentChallenge(@Request() req, @Body() dto: VerifyPaymentChallengeDto) {
    return this.passkeysService.verifyPaymentChallenge(req.user.id, dto.response, {
      action: dto.action,
      amount: dto.amount,
      loanId: dto.loanId,
      method: dto.method,
    });
  }
}
