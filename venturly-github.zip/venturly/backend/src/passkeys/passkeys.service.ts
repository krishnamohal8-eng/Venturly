import { Injectable, UnauthorizedException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} from '@simplewebauthn/server';
import { Passkey } from './passkey.entity';
import { User } from '../users/user.entity';
import { JwtService } from '@nestjs/jwt';

// In-memory challenge store (use Redis in production)
const challengeStore = new Map<string, string>();

const RP_NAME = 'Venturly';
const RP_ID   = process.env.RP_ID || 'localhost';
const ORIGIN  = process.env.ORIGIN || 'http://localhost:3000';

@Injectable()
export class PasskeysService {
  constructor(
    @InjectRepository(Passkey) private passkeyRepo: Repository<Passkey>,
    @InjectRepository(User)    private userRepo: Repository<User>,
    private jwtService: JwtService,
  ) {}

  // ── REGISTRATION ──────────────────────────────────────────────────────────

  async getRegistrationOptions(userId: string) {
    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) throw new BadRequestException('User not found');

    const existingPasskeys = await this.passkeyRepo.find({
      where: { user: { id: userId } },
    });

    const options = await generateRegistrationOptions({
      rpName:                  RP_NAME,
      rpID:                    RP_ID,
      userID:                  Buffer.from(userId),
      userName:                user.email,
      userDisplayName:         user.name,
      attestationType:         'none',
      excludeCredentials:      existingPasskeys.map(pk => ({
        id:         pk.credentialId,
        transports: (pk.transports?.split(',') || []) as any,
      })),
      authenticatorSelection: {
        residentKey:        'preferred',
        userVerification:   'preferred',
        authenticatorAttachment: 'platform', // device biometrics (fingerprint/face)
      },
    });

    // Store challenge temporarily
    challengeStore.set(`reg:${userId}`, options.challenge);

    return options;
  }

  async verifyRegistration(userId: string, response: any, deviceName?: string) {
    const challenge = challengeStore.get(`reg:${userId}`);
    if (!challenge) throw new BadRequestException('No registration challenge found. Please restart.');

    let verification: any;
    try {
      verification = await verifyRegistrationResponse({
        response,
        expectedChallenge: challenge,
        expectedOrigin:    ORIGIN,
        expectedRPID:      RP_ID,
      });
    } catch (e: any) {
      throw new BadRequestException(`Passkey verification failed: ${e.message}`);
    }

    challengeStore.delete(`reg:${userId}`);

    if (!verification.verified || !verification.registrationInfo) {
      throw new BadRequestException('Passkey registration not verified');
    }

    const { credential } = verification.registrationInfo;

    // Save passkey to database
    const passkey = this.passkeyRepo.create({
      user:         { id: userId } as any,
      credentialId: Buffer.from(credential.id).toString('base64url'),
      publicKey:    Buffer.from(credential.publicKey).toString('base64url'),
      counter:      credential.counter,
      deviceName:   deviceName || 'My Device',
      transports:   response.response?.transports?.join(',') || '',
    });

    await this.passkeyRepo.save(passkey);
    return { verified: true, deviceName: passkey.deviceName };
  }

  // ── AUTHENTICATION ────────────────────────────────────────────────────────

  async getAuthenticationOptions(email: string) {
    const user = await this.userRepo.findOne({ where: { email } });
    if (!user) throw new UnauthorizedException('No account found with that email');

    const passkeys = await this.passkeyRepo.find({
      where: { user: { id: user.id } },
    });

    if (passkeys.length === 0) {
      throw new UnauthorizedException('No passkeys registered for this account');
    }

    const options = await generateAuthenticationOptions({
      rpID:              RP_ID,
      userVerification:  'preferred',
      allowCredentials:  passkeys.map(pk => ({
        id:         pk.credentialId,
        transports: (pk.transports?.split(',').filter(Boolean) || []) as any,
      })),
    });

    challengeStore.set(`auth:${user.id}`, options.challenge);
    return { options, userId: user.id };
  }

  async verifyAuthentication(userId: string, response: any) {
    const challenge = challengeStore.get(`auth:${userId}`);
    if (!challenge) throw new UnauthorizedException('No authentication challenge found');

    const credentialId = response.id;
    const passkey = await this.passkeyRepo.findOne({
      where: { credentialId },
      relations: ['user'],
    });

    if (!passkey || passkey.user.id !== userId) {
      throw new UnauthorizedException('Passkey not found');
    }

    let verification: any;
    try {
      verification = await verifyAuthenticationResponse({
        response,
        expectedChallenge:  challenge,
        expectedOrigin:     ORIGIN,
        expectedRPID:       RP_ID,
        credential: {
          id:         passkey.credentialId,
          publicKey:  Buffer.from(passkey.publicKey, 'base64url'),
          counter:    passkey.counter,
          transports: (passkey.transports?.split(',').filter(Boolean) || []) as any,
        },
      });
    } catch (e: any) {
      throw new UnauthorizedException(`Authentication failed: ${e.message}`);
    }

    challengeStore.delete(`auth:${userId}`);

    if (!verification.verified) {
      throw new UnauthorizedException('Passkey authentication not verified');
    }

    // Update counter (replay attack protection)
    passkey.counter = verification.authenticationInfo.newCounter;
    await this.passkeyRepo.save(passkey);

    // Issue JWT
    const user = await this.userRepo.findOne({ where: { id: userId } });
    const token = this.jwtService.sign({ sub: user!.id, role: user!.role });

    return {
      token,
      user: { id: user!.id, email: user!.email, name: user!.name, role: user!.role },
    };
  }

  // ── PAYMENT PASSKEY CHALLENGE ─────────────────────────────────────────────
  // Used to gate every payment action with a biometric confirmation.
  // Flow: get-payment-challenge → browser biometric → verify-payment-challenge
  // The returned `paymentToken` is a short-lived signed JWT passed to payment endpoints.

  async getPaymentChallengeOptions(userId: string, context: {
    action: string;   // e.g. 'invest', 'confirm_payment'
    amount: number;
    loanId: string;
    method: string;
  }) {
    const passkeys = await this.passkeyRepo.find({ where: { user: { id: userId } } });

    if (passkeys.length === 0) {
      // No passkeys registered — return a bypass token so payment still works
      const bypassToken = this.jwtService.sign(
        { sub: userId, type: 'payment_passkey', action: context.action, ...context, passkey: false },
        { expiresIn: '5m' }
      );
      return { requiresPasskey: false, paymentToken: bypassToken };
    }

    const options = await generateAuthenticationOptions({
      rpID:             RP_ID,
      userVerification: 'required', // REQUIRED for payments (not just preferred)
      allowCredentials: passkeys.map(pk => ({
        id:         pk.credentialId,
        transports: (pk.transports?.split(',').filter(Boolean) || []) as any,
      })),
    });

    // Store challenge keyed by userId + action to prevent cross-action replay
    const challengeKey = `pay:${userId}:${context.action}`;
    challengeStore.set(challengeKey, options.challenge);

    return {
      requiresPasskey: true,
      options,
      userId,
      context,
    };
  }

  async verifyPaymentChallenge(userId: string, response: any, context: {
    action: string;
    amount: number;
    loanId: string;
    method: string;
  }) {
    const challengeKey = `pay:${userId}:${context.action}`;
    const challenge = challengeStore.get(challengeKey);
    if (!challenge) throw new UnauthorizedException('Payment challenge expired. Please retry.');

    const credentialId = response.id;
    const passkey = await this.passkeyRepo.findOne({
      where: { credentialId },
      relations: ['user'],
    });

    if (!passkey || passkey.user.id !== userId) {
      throw new UnauthorizedException('Passkey not recognised');
    }

    let verification: any;
    try {
      verification = await verifyAuthenticationResponse({
        response,
        expectedChallenge:  challenge,
        expectedOrigin:     ORIGIN,
        expectedRPID:       RP_ID,
        credential: {
          id:         passkey.credentialId,
          publicKey:  Buffer.from(passkey.publicKey, 'base64url'),
          counter:    passkey.counter,
          transports: (passkey.transports?.split(',').filter(Boolean) || []) as any,
        },
      });
    } catch (e: any) {
      throw new UnauthorizedException(`Biometric verification failed: ${e.message}`);
    }

    challengeStore.delete(challengeKey);

    if (!verification.verified) {
      throw new UnauthorizedException('Biometric not verified');
    }

    // Update counter
    passkey.counter = verification.authenticationInfo.newCounter;
    await this.passkeyRepo.save(passkey);

    // Issue a short-lived payment token (5 min) — must be passed to payment endpoints
    const paymentToken = this.jwtService.sign(
      {
        sub:     userId,
        type:    'payment_passkey',
        action:  context.action,
        loanId:  context.loanId,
        amount:  context.amount,
        method:  context.method,
        passkey: true,
      },
      { expiresIn: '5m' }
    );

    return {
      verified: true,
      paymentToken,
      message: 'Biometric confirmed. Payment authorised for 5 minutes.',
    };
  }

  // Validates a paymentToken issued by verifyPaymentChallenge
  verifyPaymentToken(token: string, expectedUserId: string, expectedLoanId: string) {
    try {
      const payload = this.jwtService.verify(token) as any;
      if (payload.type !== 'payment_passkey') throw new Error('Wrong token type');
      if (payload.sub !== expectedUserId)     throw new Error('Token user mismatch');
      if (payload.loanId !== expectedLoanId)  throw new Error('Token loan mismatch');
      return payload;
    } catch (e: any) {
      throw new UnauthorizedException(`Invalid payment token: ${e.message}`);
    }
  }

  // ── MANAGEMENT ────────────────────────────────────────────────────────────

  async listPasskeys(userId: string) {
    return this.passkeyRepo.find({
      where: { user: { id: userId } },
      select: ['id', 'deviceName', 'transports', 'createdAt', 'counter'],
      order: { createdAt: 'DESC' },
    });
  }

  async deletePasskey(userId: string, passkeyId: string) {
    const pk = await this.passkeyRepo.findOne({
      where: { id: passkeyId },
      relations: ['user'],
    });
    if (!pk || pk.user.id !== userId) throw new BadRequestException('Passkey not found');
    await this.passkeyRepo.remove(pk);
    return { deleted: true };
  }
}
