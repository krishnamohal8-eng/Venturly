import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { User } from '../users/user.entity';

@Entity()
export class Passkey {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  user: User;

  // WebAuthn credential ID (base64url encoded)
  @Column({ unique: true })
  credentialId: string;

  // Public key (base64url encoded)
  @Column({ type: 'text' })
  publicKey: string;

  // Signature counter — detects cloned authenticators
  @Column({ type: 'int', default: 0 })
  counter: number;

  // Device name shown in UI
  @Column({ nullable: true })
  deviceName: string;

  // Transports: usb, nfc, ble, internal (fingerprint/face)
  @Column({ nullable: true })
  transports: string;

  @CreateDateColumn()
  createdAt: Date;
}
