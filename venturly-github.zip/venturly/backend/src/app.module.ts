import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { LoansModule } from './loans/loans.module';
import { InvestmentsModule } from './investments/investments.module';
import { RepaymentsModule } from './repayments/repayments.module';
import { AuditModule } from './audit/audit.module';
import { StatsModule } from './stats/stats.module';
import { PaymentsModule } from './payments/payments.module';
import { PasskeysModule } from './passkeys/passkeys.module';
import { NotificationsModule } from './notifications/notifications.module';
import { User } from './users/user.entity';
import { Loan } from './loans/loan.entity';
import { Investment } from './investments/investment.entity';
import { Repayment } from './repayments/repayment.entity';
import { AuditLog } from './audit/audit.entity';
import { Passkey } from './passkeys/passkey.entity';
import { Notification } from './notifications/notification.entity';

// Use PostgreSQL in production (Railway), SQLite locally
const isProduction = process.env.NODE_ENV === 'production';

@Module({
  imports: [
    TypeOrmModule.forRoot(
      isProduction
        ? {
            type: 'postgres',
            url: process.env.DATABASE_URL,
            entities: [User, Loan, Investment, Repayment, AuditLog, Passkey, Notification],
            synchronize: true,
            ssl: { rejectUnauthorized: false },
          }
        : {
            type: 'better-sqlite3',
            database: process.env.DATABASE_URL || 'venturly.sqlite',
            entities: [User, Loan, Investment, Repayment, AuditLog, Passkey, Notification],
            synchronize: true,
          } as any
    ),
    ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]),
    AuthModule,
    UsersModule,
    LoansModule,
    InvestmentsModule,
    RepaymentsModule,
    AuditModule,
    StatsModule,
    PaymentsModule,
    PasskeysModule,
    NotificationsModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: ThrottlerGuard },
  ],
})
export class AppModule {}
