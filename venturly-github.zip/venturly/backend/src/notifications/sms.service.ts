import { Injectable, Logger } from '@nestjs/common';

/**
 * SMS Service via Twilio.
 * Falls back to console logging in TEST mode (no Twilio credentials needed).
 */
@Injectable()
export class SmsService {
  private readonly logger = new Logger(SmsService.name);
  private client: any;
  private from: string;
  private isReal: boolean;

  constructor() {
    const sid    = process.env.TWILIO_ACCOUNT_SID;
    const token  = process.env.TWILIO_AUTH_TOKEN;
    this.from    = process.env.TWILIO_FROM_NUMBER || '+15005550006'; // Twilio test number
    this.isReal  = !!(sid && token && !sid.includes('placeholder'));

    if (this.isReal) {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const twilio = require('twilio');
      this.client  = twilio(sid, token);
    }
  }

  async send(to: string, body: string): Promise<void> {
    if (!to) return;

    if (!this.isReal) {
      this.logger.log(`[SMS TEST] To: ${to} | ${body}`);
      return;
    }

    try {
      await this.client.messages.create({ from: this.from, to, body });
      this.logger.log(`SMS sent to ${to}`);
    } catch (e: any) {
      this.logger.error(`SMS failed to ${to}: ${e.message}`);
    }
  }

  // Convenience methods for each event type
  async sendLoanFunded(phone: string, amount: number) {
    await this.send(phone, `Venturly: Your $${amount.toLocaleString()} loan is fully funded! Capital will be released shortly.`);
  }

  async sendRepaymentReceived(phone: string, amount: number, installment: number) {
    await this.send(phone, `Venturly: Repayment #${installment} of $${amount.toFixed(2)} received and distributed to your portfolio.`);
  }

  async sendRiskAlert(phone: string, balance: number, threshold: number) {
    await this.send(phone, `Venturly ALERT: Your bank balance ($${balance}) is below the safety threshold ($${threshold.toFixed(0)}). Please top up to avoid late fees.`);
  }

  async sendLoanCompleted(phone: string) {
    await this.send(phone, `Venturly: Congratulations! Your loan has been fully repaid.`);
  }

  async sendInvestmentConfirmed(phone: string, amount: number, method: string) {
    await this.send(phone, `Venturly: Investment of $${amount} confirmed via ${method}. Your tokens are now active.`);
  }
}
