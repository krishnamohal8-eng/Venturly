import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { User } from '../users/user.entity';

export enum NotificationType {
  LOAN_FUNDED       = 'LOAN_FUNDED',
  REPAYMENT_RECEIVED = 'REPAYMENT_RECEIVED',
  LOAN_COMPLETED    = 'LOAN_COMPLETED',
  LOAN_LATE         = 'LOAN_LATE',
  RISK_ALERT        = 'RISK_ALERT',
  INVESTMENT_MADE   = 'INVESTMENT_MADE',
}

@Entity()
export class Notification {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  user: User;

  @Column({ type: 'varchar' })
  type: string;

  @Column()
  title: string;

  @Column()
  message: string;

  @Column({ nullable: true })
  loanId: string;

  @Column({ default: false })
  read: boolean;

  @CreateDateColumn()
  createdAt: Date;
}
