import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Notification, NotificationType } from './notification.entity';

@Injectable()
export class NotificationsService {
  constructor(@InjectRepository(Notification) private repo: Repository<Notification>) {}

  async create(userId: string, type: NotificationType, title: string, message: string, loanId?: string) {
    const n = this.repo.create({ user: { id: userId } as any, type, title, message, loanId });
    return this.repo.save(n);
  }

  async findForUser(userId: string) {
    return this.repo.find({
      where: { user: { id: userId } },
      order: { createdAt: 'DESC' },
      take: 50,
    });
  }

  async markRead(userId: string, notificationId: string) {
    await this.repo.update({ id: notificationId, user: { id: userId } as any }, { read: true });
    return { ok: true };
  }

  async markAllRead(userId: string) {
    await this.repo.update({ user: { id: userId } as any, read: false }, { read: true });
    return { ok: true };
  }

  async getUnreadCount(userId: string) {
    const count = await this.repo.count({ where: { user: { id: userId } as any, read: false } });
    return { count };
  }

  // Called by repayments service when a payment is distributed
  async notifyInvestorsOfRepayment(
    investorIds: string[],
    loanId: string,
    installmentNumber: number,
    totalAmount: number,
  ) {
    for (const investorId of investorIds) {
      await this.create(
        investorId,
        NotificationType.REPAYMENT_RECEIVED,
        '💰 Repayment received',
        `Installment #${installmentNumber} of $${totalAmount.toFixed(2)} has been distributed to your portfolio.`,
        loanId,
      );
    }
  }

  async notifyLoanFunded(borrowerId: string, loanId: string, amount: number) {
    await this.create(
      borrowerId,
      NotificationType.LOAN_FUNDED,
      '🎉 Your loan is fully funded!',
      `Your $${amount.toLocaleString()} loan has been fully funded. Capital will be released shortly.`,
      loanId,
    );
  }

  async notifyLoanCompleted(borrowerId: string, investorIds: string[], loanId: string) {
    await this.create(
      borrowerId,
      NotificationType.LOAN_COMPLETED,
      '✅ Loan fully repaid',
      'Congratulations! You have fully repaid your loan.',
      loanId,
    );
    for (const investorId of investorIds) {
      await this.create(
        investorId,
        NotificationType.LOAN_COMPLETED,
        '✅ Loan completed',
        'A loan in your portfolio has been fully repaid.',
        loanId,
      );
    }
  }

  async notifyRiskAlert(borrowerId: string, loanId: string, balance: number, threshold: number) {
    await this.create(
      borrowerId,
      NotificationType.RISK_ALERT,
      '⚠️ Low balance alert',
      `Your bank balance ($${balance}) is below the safety threshold ($${threshold.toFixed(0)}). Please top up to avoid late payment flags.`,
      loanId,
    );
  }
}
