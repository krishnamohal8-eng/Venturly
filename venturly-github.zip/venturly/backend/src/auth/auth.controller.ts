import { Controller, Post, Body, HttpCode } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBody } from '@nestjs/swagger';
import { AuthService } from './auth.service';
import { IsEmail, IsIn, IsString, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class RegisterDto {
  @ApiProperty({ example: 'maya@demo.com' })
  @IsEmail() email: string;

  @ApiProperty({ example: 'password123', minLength: 6 })
  @IsString() @MinLength(6) password: string;

  @ApiProperty({ example: 'Maya Patel' })
  @IsString() name: string;

  @ApiProperty({ enum: ['borrower', 'investor'], example: 'borrower' })
  @IsIn(['borrower', 'investor']) role: string;
}

export class LoginDto {
  @ApiProperty({ example: 'maya@demo.com' })
  @IsEmail() email: string;

  @ApiProperty({ example: 'password123' })
  @IsString() password: string;
}

@ApiTags('Auth')
@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('register')
  @ApiOperation({ summary: 'Register a new account', description: 'Creates a borrower or investor account and returns a JWT token.' })
  @ApiBody({ type: RegisterDto })
  @ApiResponse({ status: 201, description: 'Account created. Returns JWT + user object.' })
  @ApiResponse({ status: 409, description: 'Email already registered.' })
  register(@Body() dto: RegisterDto) {
    return this.authService.register(dto.email, dto.password, dto.name, dto.role);
  }

  @Post('login')
  @HttpCode(200)
  @ApiOperation({ summary: 'Login', description: 'Authenticate with email + password. Returns a JWT token valid for 7 days.' })
  @ApiBody({ type: LoginDto })
  @ApiResponse({ status: 200, description: 'Login successful. Returns JWT + user object.' })
  @ApiResponse({ status: 401, description: 'Invalid credentials.' })
  login(@Body() dto: LoginDto) {
    return this.authService.login(dto.email, dto.password);
  }
}
