import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ScheduleModule } from '@nestjs/schedule';
import { Repayment } from './repayment.entity';
import { Loan } from '../loans/loan.entity';
import { Investment } from '../investments/investment.entity';
import { RepaymentsService } from './repayments.service';
import { RepaymentsController } from './repayments.controller';
import { DunningService } from './dunning.service';
import { AuditModule } from '../audit/audit.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Repayment, Loan, Investment]),
    AuditModule,
    NotificationsModule,
    ScheduleModule.forRoot(),
  ],
  providers: [RepaymentsService, DunningService],
  controllers: [RepaymentsController],
  exports: [RepaymentsService],
})
export class RepaymentsModule {}
