import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Repayment } from './repayment.entity';
import { Loan } from '../loans/loan.entity';
import { Investment } from '../investments/investment.entity';
import { AuditService } from '../audit/audit.service';
import { AuditAction } from '../audit/audit.entity';
import { NotificationsService } from '../notifications/notifications.service';
import { SmsService } from '../notifications/sms.service';
import { NotificationType } from '../notifications/notification.entity';

@Injectable()
export class RepaymentsService {
  constructor(
    @InjectRepository(Repayment)  private repayRepo: Repository<Repayment>,
    @InjectRepository(Loan)       private loanRepo: Repository<Loan>,
    @InjectRepository(Investment) private invRepo: Repository<Investment>,
    private auditService: AuditService,
    private notificationsService: NotificationsService,
    private smsService: SmsService,
  ) {}

  async generateSchedule(loanId: string) {
    const loan = await this.loanRepo.findOne({ where: { id: loanId } });
    if (!loan) throw new NotFoundException('Loan not found');

    const principal   = Number(loan.amount);
    const monthlyRate = Number(loan.interestRatePercent) / 100 / 12;
    const n           = loan.termMonths;

    const monthlyPayment = monthlyRate === 0
      ? principal / n
      : (principal * monthlyRate * Math.pow(1 + monthlyRate, n)) /
        (Math.pow(1 + monthlyRate, n) - 1);

    let balance = principal;
    const schedules: Partial<Repayment>[] = [];

    for (let i = 1; i <= n; i++) {
      const interestDue  = balance * monthlyRate;
      const principalDue = monthlyPayment - interestDue;
      balance -= principalDue;

      const dueDate = new Date();
      dueDate.setMonth(dueDate.getMonth() + i);

      schedules.push({
        loan: { id: loanId } as any,
        installmentNumber: i,
        principalDue: Math.round(principalDue * 100) / 100,
        interestDue:  Math.round(interestDue  * 100) / 100,
        totalDue:     Math.round(monthlyPayment * 100) / 100,
        dueDate:      dueDate.toISOString().split('T')[0],
        status:       'scheduled',
      });
    }

    const saved = await this.repayRepo.save(schedules as Repayment[]);

    loan.status = 'repaying';
    await this.loanRepo.save(loan);

    await this.auditService.log(AuditAction.LOAN_FUNDED, {
      loanId,
      amount: principal,
      metadata: { termMonths: n, monthlyPayment: Math.round(monthlyPayment * 100) / 100 },
    });

    // Notify borrower via in-app + SMS
    const loanWithBorrower = await this.loanRepo.findOne({ where: { id: loanId }, relations: ['borrower'] });
    if (loanWithBorrower?.borrower) {
      await this.notificationsService.notifyLoanFunded(loanWithBorrower.borrower.id, loanId, principal);
      if ((loanWithBorrower.borrower as any).phone) {
        await this.smsService.sendLoanFunded((loanWithBorrower.borrower as any).phone, principal);
      }
    }

    return saved;
  }

  getSchedule(loanId: string) {
    return this.repayRepo.find({
      where: { loan: { id: loanId } },
      order: { installmentNumber: 'ASC' },
    });
  }

  async payInstallment(loanId: string, installmentNumber: number) {
    const repayment = await this.repayRepo.findOne({
      where: { loan: { id: loanId }, installmentNumber },
      relations: ['loan'],
    });
    if (!repayment) throw new NotFoundException('Installment not found');
    if (repayment.status === 'paid') throw new BadRequestException('Already paid');

    repayment.paidAmount = repayment.totalDue;
    repayment.paidDate   = new Date().toISOString().split('T')[0];
    repayment.status     = 'paid';
    await this.repayRepo.save(repayment);

    // Distribute proportionally to all investors
    const investments  = await this.invRepo.find({ where: { loan: { id: loanId } } });
    const totalFunded  = investments.reduce((s, i) => s + Number(i.amount), 0);

    for (const inv of investments) {
      const share = Number(inv.amount) / totalFunded;
      inv.repaidAmount = Number(inv.repaidAmount) + Number(repayment.totalDue) * share;
      await this.invRepo.save(inv);
    }

    // Mark loan completed when all installments paid
    const remaining = await this.repayRepo.count({
      where: { loan: { id: loanId }, status: 'scheduled' },
    });
    if (remaining === 0) {
      await this.loanRepo.update(loanId, { status: 'completed' });
      const loan = await this.loanRepo.findOne({ where: { id: loanId }, relations: ['borrower'] });
      const investorIds = investments.map(i => (i as any).investor?.id).filter(Boolean);
      if (loan?.borrower?.id) {
        await this.notificationsService.notifyLoanCompleted(loan.borrower.id, investorIds, loanId);
      }
    }

    // Notify investors of repayment
    const investorIds = investments.map(i => (i as any).investor?.id).filter(Boolean);
    await this.notificationsService.notifyInvestorsOfRepayment(
      investorIds, loanId, installmentNumber, Number(repayment.totalDue),
    );

    // SMS investors
    const investmentsWithUsers = await this.invRepo.find({
      where: { loan: { id: loanId } },
      relations: ['investor'],
    });
    for (const inv of investmentsWithUsers) {
      if ((inv.investor as any)?.phone) {
        await this.smsService.sendRepaymentReceived(
          (inv.investor as any).phone,
          Number(repayment.totalDue),
          installmentNumber,
        );
      }
    }

    await this.auditService.log(AuditAction.REPAYMENT_PAID, {
      loanId,
      amount: Number(repayment.totalDue),
      metadata: { installmentNumber, investorsDistributed: investments.length },
    });

    return repayment;
  }

  async triggerRiskAlert(loanId: string, currentBalance: number) {
    const loan = await this.loanRepo.findOne({ where: { id: loanId } });
    if (!loan) throw new NotFoundException('Loan not found');

    const threshold = Number(loan.amount) * 0.1;
    const isAtRisk  = currentBalance < threshold;

    await this.auditService.log(AuditAction.RISK_ALERT, {
      loanId,
      metadata: { currentBalance, threshold, isAtRisk, triggeredAt: new Date().toISOString() },
    });

    if (isAtRisk && loan.borrower) {
      await this.notificationsService.notifyRiskAlert(
        (loan as any).borrower?.id || loanId,
        loanId, currentBalance, threshold,
      );
    }

    return {
      isAtRisk, threshold, currentBalance,
      message: isAtRisk
        ? 'ALERT: Balance below threshold. Collections module notified.'
        : 'Balance healthy. No action required.',
    };
  }
}
