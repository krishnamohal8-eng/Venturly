import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { Loan } from '../loans/loan.entity';

export enum RepaymentStatus {
  SCHEDULED = 'scheduled',
  PAID      = 'paid',
  LATE      = 'late',
  DEFAULTED = 'defaulted',
}

@Entity()
export class Repayment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Loan)
  loan: Loan;

  @Column({ type: 'int' })
  installmentNumber: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  principalDue: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  interestDue: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  totalDue: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  paidAmount: number;

  // varchar instead of enum — SQLite compatible
  @Column({ type: 'varchar', default: 'scheduled' })
  status: string;

  @Column({ type: 'varchar' })
  dueDate: string;

  @Column({ type: 'varchar', nullable: true })
  paidDate: string;

  @CreateDateColumn()
  createdAt: Date;
}
