import { Controller, Get, Post, Param, Body, UseGuards, ParseIntPipe } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam, ApiBody } from '@nestjs/swagger';
import { ApiProperty } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { RepaymentsService } from './repayments.service';
import { IsNumber, Min } from 'class-validator';

export class RiskAlertDto {
  @ApiProperty({ example: 400, description: 'Current bank balance of the borrower in USD' })
  @IsNumber() @Min(0) currentBalance: number;
}

@ApiTags('Repayments')
@Controller('repayments')
@UseGuards(AuthGuard('jwt'))
@ApiBearerAuth('JWT')
export class RepaymentsController {
  constructor(private repaymentsService: RepaymentsService) {}

  @Get(':loanId/schedule')
  @ApiOperation({
    summary: 'Get repayment schedule',
    description: 'Returns the full amortization schedule for a loan — principal, interest, and total due per installment.',
  })
  @ApiParam({ name: 'loanId', description: 'Loan UUID' })
  @ApiResponse({ status: 200, description: 'Array of installment objects ordered by installment number.' })
  getSchedule(@Param('loanId') loanId: string) {
    return this.repaymentsService.getSchedule(loanId);
  }

  @Post(':loanId/generate')
  @ApiOperation({
    summary: 'Generate repayment schedule',
    description: `Generates the amortization schedule for a fully-funded loan using the standard amortization formula.\n\n` +
      `- Moves loan status from \`funded\` → \`repaying\`\n` +
      `- Logs a \`LOAN_FUNDED\` entry to the audit ledger\n` +
      `- Should be called once after the loan reaches 100% funding`,
  })
  @ApiParam({ name: 'loanId', description: 'Loan UUID' })
  @ApiResponse({ status: 201, description: 'Schedule generated. Returns array of installment objects.' })
  @ApiResponse({ status: 404, description: 'Loan not found.' })
  generate(@Param('loanId') loanId: string) {
    return this.repaymentsService.generateSchedule(loanId);
  }

  @Post(':loanId/pay/:installment')
  @ApiOperation({
    summary: 'Pay an installment',
    description: `Marks an installment as paid and distributes the repayment proportionally to all token holders.\n\n` +
      `- Repayment is split by each investor's token share\n` +
      `- If all installments are paid, loan status moves to \`completed\`\n` +
      `- Logs a \`REPAYMENT_PAID\` entry to the audit ledger`,
  })
  @ApiParam({ name: 'loanId', description: 'Loan UUID' })
  @ApiParam({ name: 'installment', description: 'Installment number (1-indexed)', type: Number })
  @ApiResponse({ status: 201, description: 'Installment paid. Returns updated repayment object.' })
  @ApiResponse({ status: 400, description: 'Already paid.' })
  @ApiResponse({ status: 404, description: 'Installment not found.' })
  pay(
    @Param('loanId') loanId: string,
    @Param('installment', ParseIntPipe) installment: number,
  ) {
    return this.repaymentsService.payInstallment(loanId, installment);
  }

  @Post(':loanId/risk-check')
  @ApiOperation({
    summary: 'Run AI risk trigger check',
    description: `Simulates the AI risk monitoring system. Checks if the borrower's bank balance is below the safety threshold (10% of loan amount).\n\n` +
      `In production this runs automatically via a daily cron job checking live Plaid balances.\n\n` +
      `- If at risk: triggers the collections/dunning module and logs a \`RISK_ALERT\` audit entry\n` +
      `- If healthy: no action taken`,
  })
  @ApiParam({ name: 'loanId', description: 'Loan UUID' })
  @ApiBody({ type: RiskAlertDto })
  @ApiResponse({
    status: 201,
    description: 'Risk check result.',
    schema: {
      example: {
        isAtRisk: true,
        threshold: 500,
        currentBalance: 200,
        message: 'ALERT: Balance below threshold. Collections module notified.',
      },
    },
  })
  riskCheck(@Param('loanId') loanId: string, @Body() dto: RiskAlertDto) {
    return this.repaymentsService.triggerRiskAlert(loanId, dto.currentBalance);
  }
}
