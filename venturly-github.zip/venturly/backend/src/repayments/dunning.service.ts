import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, LessThan } from 'typeorm';
import { Repayment } from './repayment.entity';
import { AuditService } from '../audit/audit.service';
import { AuditAction } from '../audit/audit.entity';

@Injectable()
export class DunningService {
  private readonly logger = new Logger(DunningService.name);

  constructor(
    @InjectRepository(Repayment) private repayRepo: Repository<Repayment>,
    private auditService: AuditService,
  ) {}

  @Cron(CronExpression.EVERY_DAY_AT_8AM)
  async checkOverdueInstallments() {
    const today = new Date().toISOString().split('T')[0];

    const overdue = await this.repayRepo.find({
      where: { status: 'scheduled', dueDate: LessThan(today) as any },
      relations: ['loan'],
    });

    if (overdue.length === 0) {
      this.logger.log('Dunning check: no overdue installments.');
      return;
    }

    this.logger.warn(`Dunning: ${overdue.length} overdue installment(s) found.`);

    for (const r of overdue) {
      r.status = 'late';
      await this.repayRepo.save(r);
      await this.auditService.log(AuditAction.REPAYMENT_LATE, {
        loanId: r.loan?.id,
        amount: Number(r.totalDue),
        metadata: {
          installmentNumber: r.installmentNumber,
          dueDate: r.dueDate,
          action: 'DUNNING_SEQUENCE_TRIGGERED',
        },
      });
    }
  }
}
