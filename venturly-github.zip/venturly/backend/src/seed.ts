/**
 * Seed script — populates the DB with demo borrowers, investors, and loans.
 * Run: npm run seed
 */
import 'reflect-metadata';
import { DataSource } from 'typeorm';
import * as bcrypt from 'bcryptjs';
import { User } from './users/user.entity';
import { Loan } from './loans/loan.entity';
import { Investment } from './investments/investment.entity';
import { AuditLog } from './audit/audit.entity';
import { Repayment } from './repayments/repayment.entity';

const ds = new DataSource({
  type: 'better-sqlite3',
  database: 'venturly.sqlite',
  entities: [User, Loan, Investment, AuditLog, Repayment],
  synchronize: true,
} as any);

async function seed() {
  await ds.initialize();
  console.log('🌱 Seeding database...');

  const userRepo = ds.getRepository(User);
  const loanRepo = ds.getRepository(Loan);
  const invRepo  = ds.getRepository(Investment);

  // Skip if already seeded
  const existing = await userRepo.count();
  if (existing > 0) {
    console.log('✅ Already seeded — skipping.');
    await ds.destroy();
    return;
  }

  const hash = await bcrypt.hash('password123', 10);

  const borrowers = await userRepo.save([
    { email: 'maya@demo.com',   passwordHash: hash, name: 'Maya Patel',    role: 'borrower', kycVerified: true },
    { email: 'carlos@demo.com', passwordHash: hash, name: 'Carlos Rivera', role: 'borrower', kycVerified: true },
    { email: 'priya@demo.com',  passwordHash: hash, name: 'Priya Singh',   role: 'borrower', kycVerified: true },
  ]);

  const investors = await userRepo.save([
    { email: 'alex@demo.com',  passwordHash: hash, name: 'Alex Chen',     role: 'investor', kycVerified: true },
    { email: 'sarah@demo.com', passwordHash: hash, name: 'Sarah Johnson', role: 'investor', kycVerified: true },
  ]);

  const loans = await loanRepo.save([
    {
      borrower: borrowers[0], amount: 5000, termMonths: 12,
      interestRatePercent: 10, riskGrade: 'B', quantumScore: 72,
      totalTokens: 200, fundedTokens: 120, status: 'listed',
      monthlyRevenue: 3500, esgScore: 82, esgCategory: 'Women-Owned',
      businessDescription: 'Handmade jewellery e-commerce store expanding to wholesale. Need capital for inventory.',
    },
    {
      borrower: borrowers[1], amount: 10000, termMonths: 18,
      interestRatePercent: 13, riskGrade: 'C', quantumScore: 58,
      totalTokens: 400, fundedTokens: 80, status: 'listed',
      monthlyRevenue: 5200, esgScore: 58, esgCategory: null,
      businessDescription: 'Food truck business adding a second vehicle to serve downtown events.',
    },
    {
      borrower: borrowers[2], amount: 3000, termMonths: 6,
      interestRatePercent: 8, riskGrade: 'A', quantumScore: 88,
      totalTokens: 120, fundedTokens: 120, status: 'funded',
      monthlyRevenue: 8000, esgScore: 95, esgCategory: 'Green Business',
      businessDescription: 'Solar panel installation startup serving rural households.',
    },
  ]);

  await invRepo.save([
    { investor: investors[0], loan: loans[2], tokens: 60, amount: 1500, repaidAmount: 0 },
    { investor: investors[1], loan: loans[2], tokens: 60, amount: 1500, repaidAmount: 0 },
    { investor: investors[0], loan: loans[0], tokens: 80, amount: 2000, repaidAmount: 0 },
    { investor: investors[1], loan: loans[1], tokens: 80, amount: 2000, repaidAmount: 0 },
  ]);

  console.log('✅ Seed complete!');
  console.log('');
  console.log('Demo accounts (password: password123)');
  console.log('  Borrowers : maya@demo.com · carlos@demo.com · priya@demo.com');
  console.log('  Investors : alex@demo.com · sarah@demo.com');
  await ds.destroy();
}

seed().catch(e => { console.error(e); process.exit(1); });
