import { Controller, Get, Post, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam, ApiBody, ApiQuery } from '@nestjs/swagger';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { LoansService } from './loans.service';
import { IsBoolean, IsInt, IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class ApplyLoanDto {
  @ApiProperty({ example: 5000, description: 'Loan amount in USD (min $500, max $50,000)' })
  @IsNumber() @Min(500) amount: number;

  @ApiProperty({ example: 12, description: 'Loan term in months' })
  @IsInt() @Min(1) termMonths: number;

  @ApiProperty({ example: 'Handmade jewellery store expanding to wholesale' })
  @IsString() businessDescription: string;

  @ApiProperty({ example: 3500, description: 'Average monthly revenue in USD' })
  @IsNumber() @Min(0) monthlyRevenue: number;

  @ApiProperty({ example: 18, description: 'How many months the business has been operating' })
  @IsInt() @Min(0) monthsInBusiness: number;

  @ApiProperty({ example: true, description: 'Whether bank account is connected via Plaid (+10 score)' })
  @IsBoolean() hasConnectedBank: boolean;

  @ApiProperty({ example: false, description: 'Whether sales platform (Shopify/Amazon) is connected (+10 score)' })
  @IsBoolean() hasConnectedSales: boolean;

  @ApiPropertyOptional({ example: 'Women-Owned', description: 'ESG impact category (+10 score bonus)', enum: ['Women-Owned','Minority-Owned','Green Business','Rural Business','Social Enterprise'] })
  @IsOptional() @IsString() esgCategory?: string;
}

@ApiTags('Loans')
@Controller('loans')
export class LoansController {
  constructor(private loansService: LoansService) {}

  @Get()
  @ApiOperation({
    summary: 'Browse marketplace loans',
    description: 'Returns paginated listed loans. Supports filtering by grade, ESG, search, and sorting.',
  })
  @ApiQuery({ name: 'page',   required: false, type: Number, description: 'Page number (default: 1)' })
  @ApiQuery({ name: 'limit',  required: false, type: Number, description: 'Items per page (default: 20, max: 100)' })
  @ApiQuery({ name: 'grade',  required: false, type: String, description: 'Filter by risk grade: A, B, C, D, E' })
  @ApiQuery({ name: 'esg',    required: false, type: Boolean, description: 'If true, only return ESG-tagged loans' })
  @ApiQuery({ name: 'search', required: false, type: String, description: 'Search in business description' })
  @ApiQuery({ name: 'sort',   required: false, enum: ['newest','amount_asc','amount_desc','rate_desc','score_desc'], description: 'Sort order' })
  @ApiResponse({ status: 200, description: 'Paginated loans with meta: { total, page, limit, pages }' })
  findAll(
    @Query('page')   page?: string,
    @Query('limit')  limit?: string,
    @Query('grade')  grade?: string,
    @Query('esg')    esg?: string,
    @Query('search') search?: string,
    @Query('sort')   sort?: string,
  ) {
    return this.loansService.findAll({
      page:  page  ? parseInt(page)  : 1,
      limit: limit ? Math.min(parseInt(limit), 100) : 20,
      grade,
      esg:   esg === 'true',
      search,
      sort:  sort as any,
    });
  }

  @Get('my/loans')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: "Get my loans (borrower)", description: 'Returns all loans applied by the authenticated borrower.' })
  @ApiResponse({ status: 200, description: 'Array of loans.' })
  @ApiResponse({ status: 401, description: 'Unauthorized.' })
  myLoans(@Request() req) {
    return this.loansService.findByBorrower(req.user.id);
  }

  @Post('apply')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiOperation({
    summary: 'Apply for a loan (borrower)',
    description: `Submits a loan application. The **Quantum Score engine** instantly evaluates the business using:\n\n` +
      `- Revenue-to-loan ratio (40 pts)\n- Months in business (20 pts)\n- Bank connected via Plaid (10 pts)\n` +
      `- Sales platform connected (10 pts)\n- Base score (20 pts)\n- ESG category bonus (+10 pts)\n\n` +
      `Minimum score of 40 required for approval. Approved loans are immediately listed on the marketplace.`,
  })
  @ApiBody({ type: ApplyLoanDto })
  @ApiResponse({ status: 201, description: 'Loan approved and listed. Returns loan object with risk grade and token count.' })
  @ApiResponse({ status: 400, description: 'Loan rejected — Quantum Score below 40.' })
  @ApiResponse({ status: 401, description: 'Unauthorized.' })
  apply(@Request() req, @Body() dto: ApplyLoanDto) {
    return this.loansService.applyForLoan(req.user.id, dto);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get loan by ID', description: 'Returns full loan details including borrower info, risk grade, ESG data, and funding progress.' })
  @ApiParam({ name: 'id', description: 'Loan UUID' })
  @ApiResponse({ status: 200, description: 'Loan object.' })
  @ApiResponse({ status: 404, description: 'Loan not found.' })
  findOne(@Param('id') id: string) {
    return this.loansService.findOne(id);
  }
}
