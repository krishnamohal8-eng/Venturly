import { Injectable } from '@nestjs/common';
import { RiskGrade } from './loan.entity';

export interface BusinessData {
  monthlyRevenue: number;
  monthsInBusiness: number;
  loanAmount: number;
  hasConnectedBank: boolean;
  hasConnectedSales: boolean;
}

export interface ScoreResult {
  score: number;       // 0-100
  grade: RiskGrade;
  interestRate: number;
  approved: boolean;
}

/**
 * Quantum Score Engine
 * Simulates AI underwriting using real-time business data signals.
 * In production: replace with ML model ingesting 500+ data points.
 */
@Injectable()
export class QuantumScoreService {
  calculate(data: BusinessData): ScoreResult {
    let score = 0;

    // Revenue-to-loan ratio (40 pts)
    const revenueRatio = (data.monthlyRevenue * 12) / data.loanAmount;
    score += Math.min(40, revenueRatio * 10);

    // Business maturity (20 pts)
    score += Math.min(20, data.monthsInBusiness * 0.5);

    // Data connectivity bonus (20 pts) — rewards digital-first businesses
    if (data.hasConnectedBank) score += 10;
    if (data.hasConnectedSales) score += 10;

    // Base score (20 pts)
    score += 20;

    score = Math.round(Math.min(100, score));

    const grade = this.toGrade(score);
    const interestRate = this.toRate(grade);

    return {
      score,
      grade,
      interestRate,
      approved: score >= 40, // minimum threshold
    };
  }

  private toGrade(score: number): RiskGrade {
    if (score >= 80) return RiskGrade.A;
    if (score >= 65) return RiskGrade.B;
    if (score >= 50) return RiskGrade.C;
    if (score >= 40) return RiskGrade.D;
    return RiskGrade.E;
  }

  private toRate(grade: RiskGrade): number {
    const rates = { A: 8, B: 10, C: 13, D: 16, E: 20 };
    return rates[grade];
  }
}
