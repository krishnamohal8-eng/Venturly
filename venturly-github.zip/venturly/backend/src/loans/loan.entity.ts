import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { User } from '../users/user.entity';

export enum LoanStatus {
  PENDING   = 'pending',
  LISTED    = 'listed',
  FUNDED    = 'funded',
  REPAYING  = 'repaying',
  COMPLETED = 'completed',
  DEFAULTED = 'defaulted',
}

export enum RiskGrade {
  A = 'A', B = 'B', C = 'C', D = 'D', E = 'E',
}

@Entity()
export class Loan {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User)
  borrower: User;

  @Column('decimal', { precision: 10, scale: 2 })
  amount: number;

  @Column({ type: 'varchar', default: 'pending' })
  status: string;

  @Column({ type: 'varchar', nullable: true })
  riskGrade: string;

  @Column({ type: 'int', nullable: true })
  quantumScore: number;

  @Column({ type: 'int', default: 0 })
  totalTokens: number;

  @Column({ type: 'int', default: 0 })
  fundedTokens: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 12.0 })
  interestRatePercent: number;

  @Column({ type: 'int', default: 12 })
  termMonths: number;

  @Column({ nullable: true })
  businessDescription: string;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  monthlyRevenue: number;

  @Column({ type: 'int', nullable: true })
  esgScore: number;

  @Column({ nullable: true })
  esgCategory: string;

  @CreateDateColumn()
  createdAt: Date;
}
