import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Loan } from './loan.entity';
import { LoansService } from './loans.service';
import { LoansController } from './loans.controller';
import { QuantumScoreService } from './quantum-score.service';
import { AuditModule } from '../audit/audit.module';

@Module({
  imports: [TypeOrmModule.forFeature([Loan]), AuditModule],
  providers: [LoansService, QuantumScoreService],
  controllers: [LoansController],
  exports: [LoansService],
})
export class LoansModule {}
