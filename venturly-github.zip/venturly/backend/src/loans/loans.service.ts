import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like } from 'typeorm';
import { Loan } from './loan.entity';
import { QuantumScoreService } from './quantum-score.service';
import { AuditService } from '../audit/audit.service';
import { AuditAction } from '../audit/audit.entity';

export interface LoanQuery {
  page?: number;
  limit?: number;
  grade?: string;
  esg?: boolean;
  search?: string;
  sort?: 'newest' | 'amount_asc' | 'amount_desc' | 'rate_desc' | 'score_desc';
}

@Injectable()
export class LoansService {
  constructor(
    @InjectRepository(Loan) private repo: Repository<Loan>,
    private scorer: QuantumScoreService,
    private auditService: AuditService,
  ) {}

  async applyForLoan(borrowerId: string, dto: {
    amount: number;
    termMonths: number;
    businessDescription: string;
    monthlyRevenue: number;
    monthsInBusiness: number;
    hasConnectedBank: boolean;
    hasConnectedSales: boolean;
    esgCategory?: string;
  }) {
    const result = this.scorer.calculate({
      monthlyRevenue:    dto.monthlyRevenue,
      monthsInBusiness:  dto.monthsInBusiness,
      loanAmount:        dto.amount,
      hasConnectedBank:  dto.hasConnectedBank,
      hasConnectedSales: dto.hasConnectedSales,
    });

    if (!result.approved) {
      throw new BadRequestException(
        `Loan not approved. Quantum Score: ${result.score}. Minimum required: 40.`
      );
    }

    const totalTokens = Math.ceil(dto.amount / 25);
    const esgScore    = dto.esgCategory ? Math.min(100, result.score + 10) : result.score;

    const loan = this.repo.create({
      borrower:           { id: borrowerId } as any,
      amount:             dto.amount,
      termMonths:         dto.termMonths,
      businessDescription: dto.businessDescription,
      monthlyRevenue:     dto.monthlyRevenue,
      riskGrade:          result.grade,
      quantumScore:       result.score,
      interestRatePercent: result.interestRate,
      totalTokens,
      fundedTokens:       0,
      status:             'listed',
      esgScore,
      esgCategory:        dto.esgCategory || null,
    });

    const saved = await this.repo.save(loan);

    await this.auditService.log(AuditAction.LOAN_LISTED, {
      loanId: saved.id,
      userId: borrowerId,
      amount: dto.amount,
      metadata: { riskGrade: result.grade, quantumScore: result.score, totalTokens },
    });

    return saved;
  }

  async findAll(query: LoanQuery = {}) {
    const { page = 1, limit = 20, grade, esg, search, sort = 'newest' } = query;
    const skip = (page - 1) * limit;

    let qb = this.repo.createQueryBuilder('loan')
      .leftJoinAndSelect('loan.borrower', 'borrower')
      .where('loan.status = :status', { status: 'listed' });

    if (grade)  qb = qb.andWhere('loan.riskGrade = :grade', { grade });
    if (esg)    qb = qb.andWhere('loan.esgCategory IS NOT NULL');
    if (search) qb = qb.andWhere('loan.businessDescription LIKE :search', { search: `%${search}%` });

    switch (sort) {
      case 'amount_asc':  qb = qb.orderBy('loan.amount', 'ASC'); break;
      case 'amount_desc': qb = qb.orderBy('loan.amount', 'DESC'); break;
      case 'rate_desc':   qb = qb.orderBy('loan.interestRatePercent', 'DESC'); break;
      case 'score_desc':  qb = qb.orderBy('loan.quantumScore', 'DESC'); break;
      default:            qb = qb.orderBy('loan.createdAt', 'DESC');
    }

    const [data, total] = await qb.skip(skip).take(limit).getManyAndCount();

    return {
      data,
      meta: { total, page, limit, pages: Math.ceil(total / limit) },
    };
  }

  findOne(id: string) {
    return this.repo.findOne({ where: { id }, relations: ['borrower'] });
  }

  findByBorrower(borrowerId: string) {
    return this.repo.find({
      where: { borrower: { id: borrowerId } },
      order: { createdAt: 'DESC' },
    });
  }
  async addFundedTokens(loanId: string, tokens: number) {
    const loan = await this.repo.findOne({ where: { id: loanId } });
    if (!loan) throw new NotFoundException('Loan not found');

    const remaining = loan.totalTokens - loan.fundedTokens;
    if (tokens > remaining) throw new BadRequestException('Not enough tokens available');

    loan.fundedTokens += tokens;
    if (loan.fundedTokens >= loan.totalTokens) {
      loan.status = 'funded';
    }

    return this.repo.save(loan);
  }
}
