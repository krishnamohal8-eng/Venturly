import 'reflect-metadata';
import { NestFactory, Reflector } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe, ClassSerializerInterceptor } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { rawBody: true });

  app.enableCors();
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  app.useGlobalInterceptors(new ClassSerializerInterceptor(app.get(Reflector)));

  // ── Swagger / OpenAPI ──────────────────────────────────────────────────────
  const config = new DocumentBuilder()
    .setTitle('Venturly API')
    .setDescription(
      `**Venturly** — The Intelligent Bridge for Small Business Capital.\n\n` +
      `AI-powered P2P micro-lending marketplace. Borrowers get capital in 48 hours. ` +
      `Investors earn fixed-income returns from $25 micro-notes.\n\n` +
      `### Authentication\n` +
      `All protected endpoints require a Bearer JWT token.\n` +
      `Get one via \`POST /auth/login\` or \`POST /auth/register\`.`
    )
    .setVersion('1.0')
    .setContact('Venture Coachers', '', 'team@venturly.io')
    .setLicense('MIT', '')
    .addBearerAuth(
      { type: 'http', scheme: 'bearer', bearerFormat: 'JWT', description: 'Paste your JWT token here' },
      'JWT'
    )
    .addTag('Auth',          'Register and login')
    .addTag('Passkeys',      'Passwordless login with device biometrics (WebAuthn)')
    .addTag('Users',         'Profile management')
    .addTag('Loans',         'Apply for loans, browse marketplace')
    .addTag('Investments',   'Fund loans, track portfolio')
    .addTag('Payments',      'Google Pay + Stripe + PayPal + Razorpay + Bank Transfer')
    .addTag('Repayments',    'Amortization schedules, pay installments, risk checks')
    .addTag('Notifications', 'Real-time alerts for repayments, funding, and risk events')
    .addTag('Audit',         'Immutable hash-chained transaction ledger')
    .addTag('Stats',         'Platform-wide impact metrics')
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document, {
    swaggerOptions: {
      persistAuthorization: true,
      tagsSorter: 'alpha',
      operationsSorter: 'alpha',
      docExpansion: 'list',
      filter: true,
      showRequestDuration: true,
    },
    customSiteTitle: 'Venturly API Docs',
    customCss: `
      .swagger-ui .topbar { background: #0d7a6e; }
      .swagger-ui .topbar .download-url-wrapper { display: none; }
      .swagger-ui .info .title { color: #0d7a6e; }
    `,
  });

  // ── Health ─────────────────────────────────────────────────────────────────
  const httpAdapter = app.getHttpAdapter();
  httpAdapter.get('/health', (_req: any, res: any) =>
    res.json({ status: 'ok', ts: new Date().toISOString(), version: '1.0' })
  );

  const port = process.env.PORT || 3001;
  await app.listen(port);
  console.log(`Venturly API  → http://localhost:${port}`);
  console.log(`Swagger docs  → http://localhost:${port}/api`);
}
bootstrap();
