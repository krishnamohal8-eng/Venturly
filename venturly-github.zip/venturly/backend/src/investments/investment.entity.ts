import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { User } from '../users/user.entity';
import { Loan } from '../loans/loan.entity';

@Entity()
export class Investment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User)
  investor: User;

  @ManyToOne(() => Loan)
  loan: Loan;

  // Number of $25 tokens purchased
  @Column({ type: 'int' })
  tokens: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount: number; // tokens * 25

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  repaidAmount: number;

  @CreateDateColumn()
  createdAt: Date;
}
