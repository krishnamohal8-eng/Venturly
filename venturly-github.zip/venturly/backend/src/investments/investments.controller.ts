import { Controller, Post, Get, Body, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { ApiProperty } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { InvestmentsService } from './investments.service';
import { IsInt, IsUUID, Min } from 'class-validator';

export class InvestDto {
  @ApiProperty({ example: 'uuid-of-loan', description: 'The loan UUID to invest in' })
  @IsUUID() loanId: string;

  @ApiProperty({ example: 4, description: 'Number of $25 micro-note tokens to purchase (min 1)' })
  @IsInt() @Min(1) tokens: number;
}

@ApiTags('Investments')
@Controller('investments')
@UseGuards(AuthGuard('jwt'))
@ApiBearerAuth('JWT')
export class InvestmentsController {
  constructor(private investmentsService: InvestmentsService) {}

  @Post()
  @ApiOperation({
    summary: 'Fund a loan (investor)',
    description: `Purchase micro-note tokens in a listed loan. Each token = **$25**.\n\n` +
      `- Funds are held in escrow until the loan is 100% funded\n` +
      `- Once fully funded, capital is released to the borrower\n` +
      `- Repayments are distributed proportionally to all token holders\n` +
      `- Every investment is logged to the immutable audit ledger`,
  })
  @ApiBody({ type: InvestDto })
  @ApiResponse({ status: 201, description: 'Investment created. Returns investment object + updated loan.' })
  @ApiResponse({ status: 400, description: 'Not enough tokens available or invalid amount.' })
  @ApiResponse({ status: 401, description: 'Unauthorized.' })
  invest(@Request() req, @Body() dto: InvestDto) {
    return this.investmentsService.invest(req.user.id, dto.loanId, dto.tokens);
  }

  @Get('my')
  @ApiOperation({
    summary: 'Get my investments',
    description: 'Returns all investments made by the authenticated investor, including loan details and repayment progress.',
  })
  @ApiResponse({ status: 200, description: 'Array of investment objects with nested loan and borrower data.' })
  myInvestments(@Request() req) {
    return this.investmentsService.findByInvestor(req.user.id);
  }

  @Get('my/stats')
  @ApiOperation({
    summary: 'Get portfolio stats',
    description: 'Returns aggregated portfolio metrics: total invested, total repaid, active investment count, and expected annual return.',
  })
  @ApiResponse({
    status: 200,
    description: 'Portfolio stats object.',
    schema: {
      example: {
        totalInvested: 2500,
        totalRepaid: 312.50,
        activeInvestments: 3,
        expectedReturn: 300,
      },
    },
  })
  myStats(@Request() req) {
    return this.investmentsService.getPortfolioStats(req.user.id);
  }
}
