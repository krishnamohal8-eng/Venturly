import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Investment } from './investment.entity';
import { LoansService } from '../loans/loans.service';
import { AuditService } from '../audit/audit.service';
import { AuditAction } from '../audit/audit.entity';

@Injectable()
export class InvestmentsService {
  constructor(
    @InjectRepository(Investment) private repo: Repository<Investment>,
    private loansService: LoansService,
    private auditService: AuditService,
  ) {}

  async invest(investorId: string, loanId: string, tokens: number) {
    if (tokens < 1) throw new BadRequestException('Minimum 1 token ($25)');

    const loan = await this.loansService.addFundedTokens(loanId, tokens);

    const investment = this.repo.create({
      investor:     { id: investorId } as any,
      loan:         { id: loanId } as any,
      tokens,
      amount:       tokens * 25,
      repaidAmount: 0,
    });

    const saved = await this.repo.save(investment);

    await this.auditService.log(AuditAction.INVESTMENT_MADE, {
      loanId,
      userId: investorId,
      amount: tokens * 25,
      metadata: { tokens, loanStatus: loan.status },
    });

    return { investment: saved, loan };
  }

  findByInvestor(investorId: string) {
    return this.repo.find({
      where: { investor: { id: investorId } },
      relations: ['loan', 'loan.borrower'],
      order: { createdAt: 'DESC' },
    });
  }

  async getPortfolioStats(investorId: string) {
    const investments    = await this.findByInvestor(investorId);
    const totalInvested  = investments.reduce((s, i) => s + Number(i.amount), 0);
    const totalRepaid    = investments.reduce((s, i) => s + Number(i.repaidAmount), 0);
    return {
      totalInvested,
      totalRepaid,
      activeInvestments: investments.length,
      expectedReturn:    totalInvested * 0.12,
    };
  }
}
