import { Controller, Post, Body, Headers, RawBodyRequest, Req, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody, ApiHeader } from '@nestjs/swagger';
import { ApiProperty } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { IsInt, IsString, IsUUID, Min, IsIn, IsOptional } from 'class-validator';
import { PaymentsService, PaymentMethod } from './payments.service';
import { PasskeysService } from '../passkeys/passkeys.service';

// ── DTOs ──────────────────────────────────────────────────────────────────────

export class StripeIntentDto {
  @ApiProperty({ example: 'uuid-of-loan' })
  @IsUUID() loanId: string;

  @ApiProperty({ example: 4 })
  @IsInt() @Min(1) tokens: number;

  @ApiProperty({ enum: ['google_pay','apple_pay','stripe_card','bank_transfer'], example: 'google_pay' })
  @IsIn(['google_pay','apple_pay','stripe_card','bank_transfer']) method: PaymentMethod;
}

export class StripeConfirmDto {
  @ApiProperty({ example: 'pi_3xxx' })
  @IsString() paymentIntentId: string;

  @ApiProperty({ example: 'uuid-of-loan' })
  @IsUUID() loanId: string;

  @ApiProperty({ example: 4 })
  @IsInt() @Min(1) tokens: number;

  @ApiProperty({ enum: ['google_pay','apple_pay','stripe_card','bank_transfer'] })
  @IsIn(['google_pay','apple_pay','stripe_card','bank_transfer']) method: PaymentMethod;
}

export class PayPalOrderDto {
  @ApiProperty({ example: 'uuid-of-loan' })
  @IsUUID() loanId: string;

  @ApiProperty({ example: 4 })
  @IsInt() @Min(1) tokens: number;
}

export class PayPalCaptureDto {
  @ApiProperty({ example: 'PAYPAL_ORDER_ID' })
  @IsString() orderId: string;

  @ApiProperty({ example: 'uuid-of-loan' })
  @IsUUID() loanId: string;

  @ApiProperty({ example: 4 })
  @IsInt() @Min(1) tokens: number;
}

export class RazorpayOrderDto {
  @ApiProperty({ example: 'uuid-of-loan' })
  @IsUUID() loanId: string;

  @ApiProperty({ example: 4 })
  @IsInt() @Min(1) tokens: number;
}

export class RazorpayVerifyDto {
  @ApiProperty({ example: 'uuid-of-loan' })
  @IsUUID() loanId: string;

  @ApiProperty({ example: 4 })
  @IsInt() @Min(1) tokens: number;

  @ApiProperty() @IsString() razorpayOrderId: string;
  @ApiProperty() @IsString() razorpayPaymentId: string;
  @ApiProperty() @IsString() razorpaySignature: string;
}

export class BankTransferDto {
  @ApiProperty({ example: 'uuid-of-loan' })
  @IsUUID() loanId: string;

  @ApiProperty({ example: 4 })
  @IsInt() @Min(1) tokens: number;
}

// ── CONTROLLER ────────────────────────────────────────────────────────────────

@ApiTags('Payments')
@Controller('payments')
export class PaymentsController {
  constructor(
    private paymentsService: PaymentsService,
    private passkeysService: PasskeysService,
  ) {}

  // Helper: validate payment token if provided (optional — degrades gracefully if no passkey)
  private validatePaymentToken(token: string | undefined, userId: string, loanId: string) {
    if (!token) return; // no passkey registered — allowed
    this.passkeysService.verifyPaymentToken(token, userId, loanId);
  }

  // ── STRIPE: Google Pay / Apple Pay / Card ──────────────────────────────────

  @Post('stripe/intent')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiHeader({ name: 'x-payment-token', description: 'Passkey payment token from POST /passkeys/payment/verify', required: false })
  @ApiOperation({
    summary: 'Create Stripe PaymentIntent',
    description:
      'Creates a Stripe PaymentIntent for **Google Pay**, **Apple Pay**, or **Card** payments.\n\n' +
      '**Passkey flow:** Call `POST /passkeys/payment/challenge` first, verify biometric, ' +
      'then pass the returned `paymentToken` in the `x-payment-token` header.\n\n' +
      'If no passkey is registered, the header is optional.',
  })
  @ApiBody({ type: StripeIntentDto })
  @ApiResponse({ status: 201, description: 'PaymentIntent created with provider config.' })
  createStripeIntent(
    @Request() req,
    @Body() dto: StripeIntentDto,
    @Headers('x-payment-token') paymentToken?: string,
  ) {
    this.validatePaymentToken(paymentToken, req.user.id, dto.loanId);
    return this.paymentsService.createStripeIntent(req.user.id, dto.loanId, dto.tokens, dto.method);
  }

  @Post('stripe/confirm')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiHeader({ name: 'x-payment-token', description: 'Passkey payment token', required: false })
  @ApiOperation({
    summary: 'Confirm Stripe payment & record investment',
    description: 'Verifies payment token (biometric), confirms with Stripe, records investment.',
  })
  @ApiBody({ type: StripeConfirmDto })
  @ApiResponse({ status: 201, description: 'Investment recorded.' })
  confirmStripe(
    @Request() req,
    @Body() dto: StripeConfirmDto,
    @Headers('x-payment-token') paymentToken?: string,
  ) {
    this.validatePaymentToken(paymentToken, req.user.id, dto.loanId);
    return this.paymentsService.confirmStripePayment(req.user.id, dto.paymentIntentId, dto.loanId, dto.tokens, dto.method);
  }

  // ── PAYPAL ─────────────────────────────────────────────────────────────────

  @Post('paypal/order')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiHeader({ name: 'x-payment-token', description: 'Passkey payment token', required: false })
  @ApiOperation({
    summary: 'Create PayPal order',
    description: 'Step 1 of PayPal checkout. Requires passkey token if user has passkeys registered.',
  })
  @ApiBody({ type: PayPalOrderDto })
  @ApiResponse({ status: 201, description: 'PayPal order created.' })
  createPayPalOrder(
    @Request() req,
    @Body() dto: PayPalOrderDto,
    @Headers('x-payment-token') paymentToken?: string,
  ) {
    this.validatePaymentToken(paymentToken, req.user.id, dto.loanId);
    return this.paymentsService.createPayPalOrder(req.user.id, dto.loanId, dto.tokens);
  }

  @Post('paypal/capture')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiHeader({ name: 'x-payment-token', description: 'Passkey payment token', required: false })
  @ApiOperation({ summary: 'Capture PayPal payment & record investment' })
  @ApiBody({ type: PayPalCaptureDto })
  @ApiResponse({ status: 201, description: 'Investment recorded.' })
  capturePayPal(
    @Request() req,
    @Body() dto: PayPalCaptureDto,
    @Headers('x-payment-token') paymentToken?: string,
  ) {
    this.validatePaymentToken(paymentToken, req.user.id, dto.loanId);
    return this.paymentsService.capturePayPalOrder(req.user.id, dto.orderId, dto.loanId, dto.tokens);
  }

  // ── RAZORPAY (UPI / India) ─────────────────────────────────────────────────

  @Post('razorpay/order')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiHeader({ name: 'x-payment-token', description: 'Passkey payment token', required: false })
  @ApiOperation({ summary: 'Create Razorpay order (UPI / India)', description: 'Requires passkey biometric if registered.' })
  @ApiBody({ type: RazorpayOrderDto })
  @ApiResponse({ status: 201, description: 'Razorpay order created.' })
  createRazorpayOrder(
    @Request() req,
    @Body() dto: RazorpayOrderDto,
    @Headers('x-payment-token') paymentToken?: string,
  ) {
    this.validatePaymentToken(paymentToken, req.user.id, dto.loanId);
    return this.paymentsService.createRazorpayOrder(req.user.id, dto.loanId, dto.tokens);
  }

  @Post('razorpay/verify')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiHeader({ name: 'x-payment-token', description: 'Passkey payment token', required: false })
  @ApiOperation({ summary: 'Verify Razorpay payment & record investment' })
  @ApiBody({ type: RazorpayVerifyDto })
  @ApiResponse({ status: 201, description: 'Investment recorded.' })
  verifyRazorpay(
    @Request() req,
    @Body() dto: RazorpayVerifyDto,
    @Headers('x-payment-token') paymentToken?: string,
  ) {
    this.validatePaymentToken(paymentToken, req.user.id, dto.loanId);
    return this.paymentsService.verifyRazorpayPayment(
      req.user.id, dto.loanId, dto.tokens,
      dto.razorpayOrderId, dto.razorpayPaymentId, dto.razorpaySignature,
    );
  }

  @Post('bank-transfer/initiate')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth('JWT')
  @ApiHeader({ name: 'x-payment-token', description: 'Passkey payment token', required: false })
  @ApiOperation({ summary: 'Initiate bank transfer (ACH)', description: 'Requires passkey biometric if registered.' })
  @ApiBody({ type: BankTransferDto })
  @ApiResponse({ status: 201, description: 'Bank transfer instructions.' })
  initiateBankTransfer(
    @Request() req,
    @Body() dto: BankTransferDto,
    @Headers('x-payment-token') paymentToken?: string,
  ) {
    this.validatePaymentToken(paymentToken, req.user.id, dto.loanId);
    return this.paymentsService.initiateBankTransfer(req.user.id, dto.loanId, dto.tokens);
  }

  // ── STRIPE WEBHOOK ─────────────────────────────────────────────────────────

  @Post('webhook')
  @ApiOperation({
    summary: 'Stripe webhook',
    description: 'Configure in Stripe dashboard: `https://your-domain.com/payments/webhook`',
  })
  webhook(@Req() req: RawBodyRequest<any>, @Headers('stripe-signature') sig: string) {
    return this.paymentsService.handleWebhook(req.rawBody, sig);
  }
}
