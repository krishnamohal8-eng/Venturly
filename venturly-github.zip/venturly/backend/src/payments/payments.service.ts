import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Investment } from '../investments/investment.entity';
import { Loan } from '../loans/loan.entity';
import { LoansService } from '../loans/loans.service';
import { AuditService } from '../audit/audit.service';
import { AuditAction } from '../audit/audit.entity';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const StripeLib   = require('stripe');
// eslint-disable-next-line @typescript-eslint/no-var-requires
const Razorpay    = require('razorpay');
// eslint-disable-next-line @typescript-eslint/no-var-requires
const paypalHttp  = require('@paypal/paypal-js');

export type PaymentMethod =
  | 'google_pay'
  | 'apple_pay'
  | 'stripe_card'
  | 'paypal'
  | 'razorpay'
  | 'bank_transfer';

@Injectable()
export class PaymentsService {
  private stripe: any;
  private razorpay: any;

  constructor(
    @InjectRepository(Investment) private invRepo: Repository<Investment>,
    @InjectRepository(Loan)       private loanRepo: Repository<Loan>,
    private loansService: LoansService,
    private auditService: AuditService,
  ) {
    this.stripe = new StripeLib(
      process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder',
      { apiVersion: '2024-06-20' }
    );

    this.razorpay = new Razorpay({
      key_id:     process.env.RAZORPAY_KEY_ID     || 'rzp_test_placeholder',
      key_secret: process.env.RAZORPAY_KEY_SECRET || 'placeholder_secret',
    });
  }

  // ── STRIPE (Google Pay / Apple Pay / Card) ────────────────────────────────

  async createStripeIntent(investorId: string, loanId: string, tokens: number, method: PaymentMethod) {
    if (tokens < 1) throw new BadRequestException('Minimum 1 token ($25)');

    const loan = await this.loanRepo.findOne({ where: { id: loanId } });
    if (!loan) throw new NotFoundException('Loan not found');

    const remaining = loan.totalTokens - loan.fundedTokens;
    if (tokens > remaining) throw new BadRequestException(`Only ${remaining} tokens available`);

    const amountUsd   = tokens * 25;
    const amountCents = amountUsd * 100;

    // Determine Stripe payment method types
    const methodTypes: string[] = {
      google_pay:  ['card'],
      apple_pay:   ['card'],
      stripe_card: ['card'],
      bank_transfer: ['us_bank_account'],
    }[method] || ['card'];

    let clientSecret    = `pi_test_${Date.now()}_secret_test`;
    let paymentIntentId = `pi_test_${Date.now()}`;

    const isRealStripe = process.env.STRIPE_SECRET_KEY &&
      !process.env.STRIPE_SECRET_KEY.includes('placeholder');

    if (isRealStripe) {
      const intent = await this.stripe.paymentIntents.create({
        amount:               amountCents,
        currency:             'usd',
        payment_method_types: methodTypes,
        metadata: { investorId, loanId, tokens: String(tokens), method, platform: 'venturly' },
        description: `Venturly: ${tokens} token(s) in loan ${loanId.slice(0, 8)}`,
      });
      clientSecret    = intent.client_secret;
      paymentIntentId = intent.id;
    }

    return {
      provider:       'stripe',
      method,
      clientSecret,
      paymentIntentId,
      amountUsd,
      amountCents,
      tokens,
      loanId,
      publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || 'pk_test_placeholder',
      // Google Pay config
      googlePay: {
        environment:      process.env.GOOGLE_PAY_ENV || 'TEST',
        merchantId:       process.env.GOOGLE_PAY_MERCHANT_ID || 'BCR2DN4TR4XXXXXXXXX',
        merchantName:     'Venturly',
        countryCode:      'US',
        currencyCode:     'USD',
        totalPrice:       amountUsd.toFixed(2),
        totalPriceStatus: 'FINAL',
        gateway:          'stripe',
        gatewayMerchantId: process.env.STRIPE_PUBLISHABLE_KEY || 'pk_test_placeholder',
      },
    };
  }

  // ── PAYPAL ────────────────────────────────────────────────────────────────

  async createPayPalOrder(investorId: string, loanId: string, tokens: number) {
    if (tokens < 1) throw new BadRequestException('Minimum 1 token ($25)');

    const loan = await this.loanRepo.findOne({ where: { id: loanId } });
    if (!loan) throw new NotFoundException('Loan not found');

    const remaining = loan.totalTokens - loan.fundedTokens;
    if (tokens > remaining) throw new BadRequestException(`Only ${remaining} tokens available`);

    const amountUsd = tokens * 25;

    // In test mode return a simulated order
    const isRealPayPal = process.env.PAYPAL_CLIENT_ID &&
      !process.env.PAYPAL_CLIENT_ID.includes('placeholder');

    let orderId = `PAYPAL_TEST_${Date.now()}`;

    if (isRealPayPal) {
      const accessToken = await this.getPayPalAccessToken();
      const response = await fetch(
        `${process.env.PAYPAL_BASE_URL || 'https://api-m.sandbox.paypal.com'}/v2/checkout/orders`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            intent: 'CAPTURE',
            purchase_units: [{
              amount: { currency_code: 'USD', value: amountUsd.toFixed(2) },
              description: `Venturly: ${tokens} micro-note token(s)`,
              custom_id: `${investorId}:${loanId}:${tokens}`,
            }],
          }),
        }
      );
      const order = await response.json() as any;
      orderId = order.id;
    }

    return {
      provider:   'paypal',
      method:     'paypal',
      orderId,
      amountUsd,
      tokens,
      loanId,
      clientId:   process.env.PAYPAL_CLIENT_ID || 'AZDxjDScFpQtjWTOUtWKbyN_bDt4OgqaF4eYXlewfBP4-8aqX3PvV8zVD26Az0OFaujNKdoHbmhanT7IgAcJLTjzpL4zL8fIcTmplaceholder',
      currency:   'USD',
    };
  }

  async capturePayPalOrder(investorId: string, orderId: string, loanId: string, tokens: number) {
    const isRealPayPal = process.env.PAYPAL_CLIENT_ID &&
      !process.env.PAYPAL_CLIENT_ID.includes('placeholder');

    if (isRealPayPal) {
      const accessToken = await this.getPayPalAccessToken();
      const response = await fetch(
        `${process.env.PAYPAL_BASE_URL || 'https://api-m.sandbox.paypal.com'}/v2/checkout/orders/${orderId}/capture`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      const capture = await response.json() as any;
      if (capture.status !== 'COMPLETED') {
        throw new BadRequestException('PayPal payment not completed');
      }
    }

    return this.recordInvestment(investorId, loanId, tokens, 'paypal', orderId);
  }

  private async getPayPalAccessToken(): Promise<string> {
    const credentials = Buffer.from(
      `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
    ).toString('base64');

    const response = await fetch(
      `${process.env.PAYPAL_BASE_URL || 'https://api-m.sandbox.paypal.com'}/v1/oauth2/token`,
      {
        method: 'POST',
        headers: {
          Authorization: `Basic ${credentials}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'grant_type=client_credentials',
      }
    );
    const data = await response.json() as any;
    return data.access_token;
  }

  // ── RAZORPAY (UPI / India) ────────────────────────────────────────────────

  async createRazorpayOrder(investorId: string, loanId: string, tokens: number) {
    if (tokens < 1) throw new BadRequestException('Minimum 1 token ($25)');

    const loan = await this.loanRepo.findOne({ where: { id: loanId } });
    if (!loan) throw new NotFoundException('Loan not found');

    const remaining = loan.totalTokens - loan.fundedTokens;
    if (tokens > remaining) throw new BadRequestException(`Only ${remaining} tokens available`);

    const amountUsd  = tokens * 25;
    const amountInr  = Math.round(amountUsd * 83 * 100); // USD → INR paise (approx)

    const isRealRazorpay = process.env.RAZORPAY_KEY_ID &&
      !process.env.RAZORPAY_KEY_ID.includes('placeholder');

    let orderId   = `rzp_test_order_${Date.now()}`;
    let currency  = 'INR';

    if (isRealRazorpay) {
      const order = await this.razorpay.orders.create({
        amount:   amountInr,
        currency: 'INR',
        receipt:  `venturly_${loanId.slice(0, 8)}_${tokens}`,
        notes:    { investorId, loanId, tokens: String(tokens) },
      });
      orderId = order.id;
    }

    return {
      provider:   'razorpay',
      method:     'razorpay',
      orderId,
      amountInr,
      amountUsd,
      currency,
      tokens,
      loanId,
      keyId:      process.env.RAZORPAY_KEY_ID || 'rzp_test_placeholder',
      name:       'Venturly',
      description: `${tokens} micro-note token(s)`,
      prefill: { name: '', email: '', contact: '' },
      theme:  { color: '#0d7a6e' },
    };
  }

  async verifyRazorpayPayment(
    investorId: string,
    loanId: string,
    tokens: number,
    razorpayOrderId: string,
    razorpayPaymentId: string,
    razorpaySignature: string,
  ) {
    const isRealRazorpay = process.env.RAZORPAY_KEY_ID &&
      !process.env.RAZORPAY_KEY_ID.includes('placeholder');

    if (isRealRazorpay) {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const crypto = require('crypto');
      const body   = `${razorpayOrderId}|${razorpayPaymentId}`;
      const expectedSig = crypto
        .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
        .update(body)
        .digest('hex');

      if (expectedSig !== razorpaySignature) {
        throw new BadRequestException('Invalid Razorpay signature');
      }
    }

    return this.recordInvestment(investorId, loanId, tokens, 'razorpay', razorpayPaymentId);
  }

  // ── CONFIRM (Stripe / Google Pay / Apple Pay / Card / ACH) ───────────────

  async confirmStripePayment(
    investorId: string,
    paymentIntentId: string,
    loanId: string,
    tokens: number,
    method: PaymentMethod,
  ) {
    const isRealStripe = process.env.STRIPE_SECRET_KEY &&
      !process.env.STRIPE_SECRET_KEY.includes('placeholder');

    if (isRealStripe) {
      const intent = await this.stripe.paymentIntents.retrieve(paymentIntentId);
      if (intent.status !== 'succeeded') {
        throw new BadRequestException('Payment not confirmed by Stripe');
      }
    }

    return this.recordInvestment(investorId, loanId, tokens, method, paymentIntentId);
  }

  // ── BANK TRANSFER (ACH) ───────────────────────────────────────────────────

  async initiateBankTransfer(investorId: string, loanId: string, tokens: number) {
    const loan = await this.loanRepo.findOne({ where: { id: loanId } });
    if (!loan) throw new NotFoundException('Loan not found');

    const amountUsd = tokens * 25;

    // In production: create Stripe ACH payment intent or Plaid transfer
    const referenceId = `ACH_${Date.now()}_${investorId.slice(0, 6)}`;

    return {
      provider:    'bank_transfer',
      method:      'bank_transfer',
      referenceId,
      amountUsd,
      tokens,
      loanId,
      instructions: {
        bankName:      'Venturly Escrow Bank',
        accountName:   'Venturly FBO Account',
        accountNumber: '****4242',
        routingNumber: '****0021',
        memo:          referenceId,
        note:          'Funds held in escrow until loan is fully funded.',
      },
      status: 'pending',
      estimatedSettlement: '1-3 business days',
    };
  }

  // ── STRIPE WEBHOOK ────────────────────────────────────────────────────────

  async handleWebhook(rawBody: Buffer, signature: string) {
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!webhookSecret) return { received: true };

    let event: any;
    try {
      event = this.stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
    } catch {
      throw new BadRequestException('Invalid webhook signature');
    }

    if (event.type === 'payment_intent.succeeded') {
      const intent = event.data.object as any;
      const { investorId, loanId, tokens, method } = intent.metadata;
      if (investorId && loanId && tokens) {
        await this.recordInvestment(investorId, loanId, parseInt(tokens), method || 'stripe_card', intent.id);
      }
    }

    return { received: true };
  }

  // ── SHARED: record investment after any payment ───────────────────────────

  async recordInvestment(
    investorId: string,
    loanId: string,
    tokens: number,
    method: string,
    transactionId: string,
  ) {
    const loan = await this.loansService.addFundedTokens(loanId, tokens);

    const investment = this.invRepo.create({
      investor:     { id: investorId } as any,
      loan:         { id: loanId } as any,
      tokens,
      amount:       tokens * 25,
      repaidAmount: 0,
    });
    const saved = await this.invRepo.save(investment);

    await this.auditService.log(AuditAction.INVESTMENT_MADE, {
      loanId,
      userId: investorId,
      amount: tokens * 25,
      metadata: { tokens, transactionId, paymentMethod: method, loanStatus: loan.status },
    });

    return { investment: saved, loan, transactionId, method };
  }
}
