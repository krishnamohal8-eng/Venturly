import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { PaymentsController } from './payments.controller';
import { PaymentsService } from './payments.service';
import { Investment } from '../investments/investment.entity';
import { Loan } from '../loans/loan.entity';
import { AuditModule } from '../audit/audit.module';
import { LoansModule } from '../loans/loans.module';
import { PasskeysModule } from '../passkeys/passkeys.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Investment, Loan]),
    AuditModule,
    LoansModule,
    PasskeysModule,
  ],
  providers: [PaymentsService],
  controllers: [PaymentsController],
})
export class PaymentsModule {}
